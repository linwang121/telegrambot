import sqlite3
import os
import json
import time
import re
import uuid
import random
from datetime import datetime, timedelta
import logging
import sys
import telegram
from telegram.error import TimedOut, NetworkError
import asyncio
import string
import random
from telegram.constants import ChatMemberStatus
from telegram.ext import Application, CommandHandler, ContextTypes, CallbackQueryHandler, ChatMemberHandler, MessageHandler, filters
from telegram import Update, ReplyKeyboardMarkup, InlineKeyboardButton, InlineKeyboardMarkup, ForceReply
import pymysql
from pymysql.cursors import DictCursor
import config

# 设置控制台输出编码为UTF-8
if sys.platform == 'win32':
    import codecs
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer)
    sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer)
    os.system('chcp 65001')  # 设置控制台代码页为UTF-8

# 设置日志记录
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bot_debug.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# 从配置文件获取机器人Token
BOT_TOKEN = config.get_bot_token()

# 从配置文件获取超级管理员ID列表
SUPER_ADMIN_IDS = config.get_super_admin_ids()

def get_db_connection():
    """获取MySQL数据库连接（使用字典游标，fetchone()/fetchall() 返回 dict）"""
    db_conf = config.get_db_config()
    # 拷一份，避免修改原配置
    db_conf = dict(db_conf)
    # 确保使用 DictCursor，这样 cursor.fetchone() 返回的是字典
    db_conf.setdefault("cursorclass", DictCursor)
    return pymysql.connect(**db_conf)

def migrate_db():
    """迁移数据库，添加新的字段"""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        # 检查reports表中是否存在staff_confirmed字段
        cursor.execute("SHOW COLUMNS FROM `reports` LIKE 'staff_confirmed'")
        if not cursor.fetchone():
            # 如果不存在，添加该字段
            cursor.execute("ALTER TABLE `reports` ADD COLUMN `staff_confirmed` BOOLEAN DEFAULT 0")
            logger.info("成功添加staff_confirmed字段到reports表")
        conn.commit()
    except Exception as e:
        logger.error(f"数据库迁移失败: {str(e)}")
    finally:
        conn.close()

def init_db():
    """初始化数据库，创建必要的表"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # 创建群组表
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS `groups` (
        `group_id` BIGINT PRIMARY KEY,
        `group_name` VARCHAR(255),
        `group_code` VARCHAR(50),
        `deposit_amount` VARCHAR(50),
        `group_full_name` VARCHAR(255),
        `settlement_type` VARCHAR(50),
        `is_active` BOOLEAN DEFAULT 0,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `used_deposit` DECIMAL(10,2) DEFAULT 0.00
    )
    ''')
    
    # 创建管理员表
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS `admins` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `user_id` BIGINT NOT NULL,
        `group_id` BIGINT,
        `username` VARCHAR(255),
        `added_by` BIGINT,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (`group_id`) REFERENCES `groups`(`group_id`) ON DELETE CASCADE,
        UNIQUE(`user_id`, `group_id`)
    )
    ''')
    
    # 创建报备表（替代原来的JSON文件存储）
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS `reports` (
        `report_id` VARCHAR(50) PRIMARY KEY,
        `info` TEXT,
        `masked_info` TEXT,
        `customer_username` VARCHAR(255),
        `status` VARCHAR(50),
        `reporter_id` BIGINT,
        `reporter_username` VARCHAR(255),
        `amount` VARCHAR(50),
        `created_time` VARCHAR(50),
        `group_chat_id` BIGINT,
        `group_message_id` BIGINT,
        `customer_id` BIGINT,
        `confirmed_time` VARCHAR(50),
        `admin_completed` BOOLEAN DEFAULT 0,
        `customer_cancelled` BOOLEAN DEFAULT 0,
        `admin_cancelled` BOOLEAN DEFAULT 0,
        `deposit_updated` BOOLEAN DEFAULT 0,
        `staff_confirmed` BOOLEAN DEFAULT 0
    )
    ''')
    
    conn.commit()
    conn.close()

def add_group(group_id, group_name, group_code="", deposit_amount="", group_full_name="", settlement_type=""):
    """添加群组到数据库"""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO `groups` (`group_id`, `group_name`, `group_code`, `deposit_amount`, `group_full_name`, `settlement_type`) VALUES (%s, %s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE `group_name` = %s, `group_code` = %s, `deposit_amount` = %s, `group_full_name` = %s, `settlement_type` = %s",
            (group_id, group_name, group_code, deposit_amount, group_full_name, settlement_type, group_name, group_code, deposit_amount, group_full_name, settlement_type)
        )
        conn.commit()
    finally:
        conn.close()

def activate_group(group_id):
    """激活群组"""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "UPDATE `groups` SET `is_active` = 1 WHERE `group_id` = %s",
            (group_id,)
        )
        conn.commit()
    finally:
        conn.close()

def deactivate_group(group_id):
    """停用群组"""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "UPDATE `groups` SET `is_active` = 0 WHERE `group_id` = %s",
            (group_id,)
        )
        conn.commit()
    finally:
        conn.close()

def get_active_groups():
    """获取所有激活的群组"""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT `group_id`, `group_name` FROM `groups` WHERE `is_active` = 1")
        groups = {row['group_name']: row['group_id'] for row in cursor.fetchall()}
        return groups
    finally:
        conn.close()

def get_admin_groups(user_id):
    """获取用户管理的群组
    
    如果用户是超级管理员，返回所有激活的群组
    否则，只返回用户是管理员的群组
    """
    if user_id in SUPER_ADMIN_IDS:
        return get_active_groups()
        
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            SELECT g.group_id, g.group_name 
            FROM `groups` g
            JOIN `admins` a ON g.group_id = a.group_id
            WHERE a.user_id = %s AND g.is_active = 1
        """, (user_id,))
        groups = {row['group_name']: row['group_id'] for row in cursor.fetchall()}
        return groups
    finally:
        conn.close()

def add_admin(user_id, group_id, username, added_by):
    """添加管理员"""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO `admins` (`user_id`, `group_id`, `username`, `added_by`) VALUES (%s, %s, %s, %s)",
            (user_id, group_id, username, added_by)
        )
        conn.commit()
        result = True
    except pymysql.IntegrityError:
        # 如果管理员已经存在
        result = False
    finally:
        conn.close()
    return result

def remove_admin(user_id, group_id):
    """移除管理员"""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "DELETE FROM `admins` WHERE `user_id` = %s AND `group_id` = %s",
            (user_id, group_id)
        )
        conn.commit()
    finally:
        conn.close()

def is_admin(user_id, group_id=None):
    """检查用户是否是管理员
    
    如果指定了group_id，则检查用户是否是该群的管理员
    如果没有指定group_id，则检查用户是否是任何群的管理员
    超级管理员始终返回True
    """
    if user_id in SUPER_ADMIN_IDS:
        return True
        
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        if group_id:
            cursor.execute(
                "SELECT 1 FROM `admins` WHERE `user_id` = %s AND `group_id` = %s",
                (user_id, group_id)
            )
        else:
            cursor.execute(
                "SELECT 1 FROM `admins` WHERE `user_id` = %s",
                (user_id,)
            )
            
        result = cursor.fetchone() is not None
        return result
    finally:
        conn.close()

def get_admins_for_group(group_id):
    """获取指定群组的所有管理员ID"""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "SELECT `user_id` FROM `admins` WHERE `group_id` = %s",
            (group_id,)
        )
        admin_ids = [row['user_id'] for row in cursor.fetchall()]
        return admin_ids + SUPER_ADMIN_IDS  # 加上超级管理员
    finally:
        conn.close()

def save_report(report_id, report_data):
    """保存报备信息到数据库"""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        # 检查报备是否已存在
        cursor.execute("SELECT 1 FROM `reports` WHERE `report_id` = %s", (report_id,))
        exists = cursor.fetchone() is not None
        
        if exists:
            # 如果存在，则更新
            update_parts = []
            update_values = []
            
            for key, value in report_data.items():
                update_parts.append(f"`{key}` = %s")
                update_values.append(value)
            
            sql = f"UPDATE `reports` SET {', '.join(update_parts)} WHERE `report_id` = %s"
            cursor.execute(sql, update_values + [report_id])
        else:
            # 如果不存在，则插入
            columns = ['report_id'] + list(report_data.keys())
            placeholders = ', '.join(['%s'] * len(columns))
            values = [report_id] + list(report_data.values())
        
            sql = f"INSERT INTO `reports` (`{'`, `'.join(columns)}`) VALUES ({placeholders})"
            cursor.execute(sql, values)
            
        conn.commit()
    finally:
        conn.close()

def get_report(report_id):
    """从数据库获取报备信息"""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM `reports` WHERE `report_id` = %s", (report_id,))
        report = cursor.fetchone()
        return report
    finally:
        conn.close()

def get_all_reports():
    """获取所有报备信息"""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM `reports`")
        rows = cursor.fetchall()
        
        # 将结果转换为字典
        reports = {row['report_id']: row for row in rows}
        return reports
    finally:
        conn.close()

def delete_report(report_id):
    """删除报备信息"""
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("DELETE FROM `reports` WHERE `report_id` = %s", (report_id,))
        conn.commit()
    finally:
        conn.close()

def get_deposit_info(group_id):
    """获取群组的押金信息
    
    参数:
    - group_id: 群组ID
    
    返回:
    - deposit_info: 包含总押金、已使用押金和剩余押金的字典
    """
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT `deposit_amount`, `used_deposit` FROM `groups` WHERE `group_id` = %s", (group_id,))
        group = cursor.fetchone()
        
        if not group:
            return {
                "total": 0.0,
                "used": 0.0,
                "remaining": 0.0
            }
        
        # 提取押金金额中的数字部分
        deposit_str = group.get('deposit_amount', '0U')
        total_deposit = 0.0
        
        # 从字符串中提取数字
        match = re.search(r'(\d+(?:\.\d+)?)', deposit_str)
        if match:
            try:
                total_deposit = float(match.group(1))
            except ValueError:
                total_deposit = 0.0
        
        used_deposit = float(group.get('used_deposit', 0.0))
        remaining_deposit = total_deposit - used_deposit
        
        return {
            "total": total_deposit,
            "used": used_deposit,
            "remaining": remaining_deposit
        }
    finally:
        conn.close()

def update_deposit_usage(group_id, amount, is_add=True):
    """更新群组的押金使用情况
    
    参数:
    - group_id: 群组ID
    - amount: 金额
    - is_add: 如果为True，增加已使用押金；如果为False，减少已使用押金
    
    返回:
    - success: 操作是否成功
    """
    try:
        # 获取当前押金使用情况
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT `used_deposit` FROM `groups` WHERE `group_id` = %s", (group_id,))
        group = cursor.fetchone()
        
        if not group:
            return False
        
        current_used = float(group.get('used_deposit', 0.0))
        
        # 计算新的已使用押金
        new_used = current_used + amount if is_add else current_used - amount
        if new_used < 0:
            new_used = 0  # 确保已使用押金不为负
        
        # 更新数据库
        cursor.execute(
            "UPDATE `groups` SET `used_deposit` = %s WHERE `group_id` = %s",
            (new_used, group_id)
        )
        conn.commit()
        return True
    except Exception as e:
        logger.error(f"更新押金使用情况失败: {str(e)}")
        return False
    finally:
        conn.close()

def reset_group_deposit(group_id):
    """重置群组的押金使用情况
    
    参数:
    - group_id: 群组ID
    
    返回:
    - success: 操作是否成功
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # 更新数据库，将已使用押金重置为0
        cursor.execute(
            "UPDATE `groups` SET `used_deposit` = 0.0 WHERE `group_id` = %s",
            (group_id,)
        )
        conn.commit()
        
        # 更新所有该群组的报备记录，将deposit_updated标记为False
        cursor.execute(
            "UPDATE `reports` SET `deposit_updated` = 0 WHERE `group_chat_id` = %s",
            (group_id,)
        )
        conn.commit()
        
        return True
    except Exception as e:
        logger.error(f"重置押金使用情况失败: {str(e)}")
        return False
    finally:
        conn.close()

def format_report_message(report_id, report, status_text=""):
    """格式化报备信息，统一显示格式
    
    参数:
    - report_id: 报备ID
    - report: 报备信息字典
    - status_text: 状态文本，如"✅ 报备已确认"、"已取消"等
    
    返回:
    - formatted_text: 格式化后的报备信息文本
    """
    # 获取群组名称
    group_name = ""
    group_chat_id = report.get('group_chat_id')
    if group_chat_id:
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("SELECT `group_name` FROM `groups` WHERE `group_id` = %s", (group_chat_id,))
            group = cursor.fetchone()
            if group:
                group_name = group['group_name']
        except Exception as e:
            logger.error(f"获取群组名称失败: {str(e)}")
        finally:
            conn.close()
    
    # 计算过期时间（仅用于处理确认信息，不再显示在底部）
    validity_days = 1  # 默认1天
    validity_match = re.search(r'报备有效期:(.*?)(?:\n|$)', report.get('info', ''))
    if validity_match:
        validity_text = validity_match.group(1).strip()
        # 尝试提取数字
        days_match = re.search(r'(\d+)', validity_text)
        if days_match:
            try:
                validity_days = int(days_match.group(1))
            except ValueError:
                pass
    
    # 计算过期时间
    created_time = report.get('created_time', datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    expire_date = datetime.strptime(created_time, "%Y-%m-%d %H:%M:%S") + timedelta(days=validity_days)
    expire_time = expire_date.strftime("%m月%d日%H:%M:%S")
    
    # 获取确认时间
    confirmed_time = ""
    if report.get('status') == ORDER_STATUS['CONFIRMED'] or report.get('status') == ORDER_STATUS['COMPLETED']:
        confirmed_time = report.get('confirmed_time')
        if confirmed_time:
            try:
                confirmed_datetime = datetime.strptime(confirmed_time, "%Y-%m-%d %H:%M:%S")
                confirmed_time = confirmed_datetime.strftime("%m月%d日%H:%M:%S")
            except Exception as e:
                logger.error(f"格式化确认时间失败: {str(e)}")
                confirmed_time = ""
    
    # 获取交易方用户名行
    masked_info = report.get('masked_info', '')
    
    # 在交易方用户名行后添加确认信息
    if report.get('status') == ORDER_STATUS['CONFIRMED'] or report.get('status') == ORDER_STATUS['COMPLETED']:
        # 查找交易方用户名行
        user_line_match = re.search(r'(交易方用户名或ID:.*?)(?:\n|$)', masked_info)
        if user_line_match:
            user_line = user_line_match.group(1)
            # 替换原始行，添加确认信息
            masked_info = masked_info.replace(
                user_line,
                f"{user_line}\n客人已确认，时间{confirmed_time}"
            )
    
    # 构建格式化的报备信息
    formatted_text = (
        f"交易号<code>{report_id}</code>\n"
        f"群名称{group_name}\n"
        f"<code>{report_id}</code>\n"
        f"{masked_info}\n"
        f"温馨提示:如果没有报备造成纠纷不予受理，请双方把握好时间"
    )
    
    # 获取交易金额
    amount = 0.0
    amount_match = re.search(r'交易总金额:(.*?)(?:\n|$)', report.get('info', ''))
    if amount_match:
        amount_text = amount_match.group(1).strip()
        # 尝试提取数字
        amount_num_match = re.search(r'(\d+(?:\.\d+)?)', amount_text)
        if amount_num_match:
            try:
                amount = float(amount_num_match.group(1))
            except ValueError:
                pass
    
    # 如果是新确认的订单，更新押金使用情况
    if report.get('status') == ORDER_STATUS['CONFIRMED'] and group_chat_id and not report.get('deposit_updated') and amount > 0:
        update_deposit_usage(group_chat_id, amount)
        report['deposit_updated'] = True
        save_report(report_id, report)  # 保存更新标记
    
    # 如果订单取消或完成，恢复押金
    if (report.get('status') == ORDER_STATUS['CANCELLED'] or report.get('status') == ORDER_STATUS['COMPLETED']) and group_chat_id and report.get('deposit_updated'):
        # 恢复押金
        if amount > 0:
            update_deposit_usage(group_chat_id, amount, is_add=False)
            report['deposit_updated'] = False
            save_report(report_id, report)  # 保存更新标记
    
    # 添加押金使用信息（在所有状态下都显示）
    if group_chat_id:
        # 获取押金信息
        deposit_info = get_deposit_info(group_chat_id)
        
        # 显示当前的押金使用情况
        used_deposit = deposit_info['used']
        remaining_deposit = deposit_info['total'] - used_deposit
        
        # 加粗显示押金信息（使用HTML格式）
        formatted_text += f"\n新币管理员已确认本群押金累计已使用{used_deposit:.2f}\n<b>剩余可用:{remaining_deposit:.2f}</b>"
    
    # 添加状态文本
    if status_text:
        formatted_text += f"\n{status_text}"
    # 如果是已确认状态但没有特定状态文本，根据员工确认状态添加提示
    elif report.get('status') == ORDER_STATUS['CONFIRMED']:
        if report.get('staff_confirmed'):
            formatted_text += f"\n交易方已确认 新币员工已确认"
        else:
            formatted_text += f"\n交易方已确认 等待新币员工确认"
    
    return formatted_text

# 添加新的状态常量
ORDER_STATUS = {
    'WAITING_CONFIRMATION': 'waiting_confirmation',  # 等待确认
    'CONFIRMED': 'confirmed',                        # 已确认
    'CANCELLING': 'cancelling',                      # 取消中
    'CANCELLED': 'cancelled',                        # 已取消
    'COMPLETED': 'completed'                         # 已完成
}

# 初始化数据库
init_db()
# 迁移数据库（添加新字段）
migrate_db()

# 全局变量，用于存储报备信息（将逐步迁移到数据库）
reports = {}
report_ids = []

async def generate_report_id():
    """生成随机订单号，格式类似 TD96c64f33t197bc2c2676"""
    # 生成随机字符串
    timestamp = int(time.time())
    random_str = ''.join(random.choices(string.ascii_lowercase + string.digits, k=16))
    
    # 格式化为 TD + 随机字符 + t + 随机字符
    parts = [random_str[i:i+4] for i in range(0, len(random_str), 4)]
    order_id = f"TD{parts[0]}{parts[1]}t{parts[2]}{parts[3]}"
    
    return order_id

async def check_group_permissions(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """检查群组权限"""
    try:
        chat = update.chat_member.chat
        from_user = update.chat_member.from_user
        new_chat_member = update.chat_member.new_chat_member
        
        # 如果是机器人被添加到群组
        if new_chat_member.user.id == context.bot.id:
            # 检查添加机器人的用户是否是管理员
            if from_user.id not in SUPER_ADMIN_IDS: # 改为 SUPER_ADMIN_IDS
                await context.bot.send_message(
                    chat_id=chat.id,
                    text="⚠️ 只有管理员才能将机器人添加到群组中。\n机器人将自动退出群组。"
                )
                # 机器人退出群组
                await context.bot.leave_chat(chat.id)
            else:
                await context.bot.send_message(
                    chat_id=chat.id,
                    text="✅ 机器人已成功加入群组！"
                )
    except AttributeError:
        pass  # 忽略其他类型的更新

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理 /start 命令"""
    try:
        message = update.message
        logger.debug(f"Start command received: {message.text}")

        # 检查是否有参数
        if len(message.text.split()) > 1:
            param = message.text.split()[1]
            logger.debug(f"Start command parameter: {param}")
            
            # 处理报备确认
            if param.startswith('r'):
                report_id = param[1:]  # 获取报备ID
                logger.debug(f"Looking for report with ID: {report_id}")
                
                # 获取报备信息
                report = get_report(report_id)  # 从数据库获取
                if not report:
                    await message.reply_text("❌ 报备信息不存在或已过期")
                    return
                
                # 验证用户身份
                if update.effective_user.username != report.get('customer_username', '').replace('@', ''):
                    await message.reply_text("❌ 只有交易方可以确认报备")
                    return
                
                # 更新报备状态
                report['status'] = ORDER_STATUS['CONFIRMED']
                report['confirmed_time'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                report['customer_id'] = update.effective_user.id
                
                # 保存报备信息
                save_report(report_id, report)  # 保存到数据库
                
                # 使用格式化函数生成报备信息
                formatted_info = format_report_message(report_id, report, "")
                
                # 设置60秒后自动确认（兼容 job_queue 可能为 None 的情况）
                job_queue = getattr(context, "job_queue", None)
                if job_queue is not None:
                    job_queue.run_once(
                        lambda job_ctx: asyncio.create_task(auto_staff_confirm(report_id, context)),
                        60,
                        name=f"auto_confirm_{report_id}",
                    )
                else:
                    logger.warning("job_queue 为 None，跳过自动确认任务")
                
                # 更新群组消息
                try:
                    await context.bot.edit_message_text(
                        chat_id=report['group_chat_id'],
                        message_id=report['group_message_id'],
                        text=formatted_info,
                        reply_markup=InlineKeyboardMarkup([
                            [
                                InlineKeyboardButton("新币员工确认", callback_data=f"staff_confirm_{report_id}")
                            ]
                        ]),
                        parse_mode='HTML'  # 添加HTML解析模式
                    )
                except Exception as e:
                    logger.error(f"Failed to update group message: {e}")
                
                # 发送确认消息给用户
                confirmation_text = (
                    f"✅ 报备成功\n\n"
                    f"报备信息：\n{report['info']}"
                )
                await message.reply_text(confirmation_text)
                
                # 获取报备提及用户配置
                mention_config = config.get_report_mention_config()
                
                # 发送提及用户的消息
                try:
                    await context.bot.send_message(
                        chat_id=report['group_chat_id'],
                        text=mention_config['text'],
                        reply_to_message_id=report['group_message_id'],
                        disable_web_page_preview=True,
                        parse_mode='HTML'  # 添加HTML解析模式以支持超链接
                    )
                except Exception as e:
                    logger.error(f"Failed to send mention message: {e}")
                
                # 通知报备发起者（管理员）
                reporter_id = report.get('reporter_id')
                if reporter_id and reporter_id != update.effective_user.id:  # 如果报备发起者不是当前确认的用户
                    try:
                        await context.bot.send_message(
                            chat_id=reporter_id,
                            text=(
                                f"✅ 您发起的报备已被确认\n\n"
                                f"{report_id}\n"
                                f"{report['info']}"
                            ),
                            reply_markup=InlineKeyboardMarkup([
                                [
                                    InlineKeyboardButton("新币员工确认", callback_data=f"staff_confirm_{report_id}")
                                ]
                            ]),
                            disable_web_page_preview=True
                        )
                    except Exception as e:
                        logger.error(f"Failed to notify reporter {reporter_id}: {e}")
                
                return

        # 如果没有参数，显示主菜单
        reply_markup = ReplyKeyboardMarkup([
            ['公群报备', '本群查询', '我的报备(客人)']
        ], resize_keyboard=True)

        await message.reply_text("欢迎使用报备机器人", reply_markup=reply_markup)

    except Exception as e:
        logger.exception(f"处理 start 命令时发生错误: {e}")
        await message.reply_text("处理命令时发生错误")


async def handle_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理菜单按钮点击"""
    try:
        text = update.message.text
        user = update.effective_user
        
        if text == "我的报备(客人)":
            await my_orders(update, context)  # 调用 my_orders 函数
        
        elif text == "公群报备":
            # 检查是否是管理员
            if is_admin(user.id):
                # 管理员：开始报备流程
                await start_report(update, context)
            else:
                # 普通用户：显示提示信息
                await update.message.reply_text("未查询到您报备的公群，请在您的公群发送 公群报备 激活机器人")
            
        elif text == "本群查询":
            # 检查是否是管理员
            if is_admin(user.id):
                # 管理员：显示所管理群组的交易信息
                await group_query(update, context)
            else:
                # 普通用户：显示提示信息
                await update.message.reply_text("未查询到您报备的公群，请在您的公群发送 公群报备 激活机器人")
            
    except Exception as e:
        logger.exception(f"处理菜单点击时发生错误: {e}")
        await update.message.reply_text("处理请求时发生错误")

async def group_query(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理管理员的本群查询"""
    try:
        user = update.effective_user
        
        # 获取管理员管理的群组
        admin_groups = get_admin_groups(user.id)
        
        if not admin_groups:
            await update.message.reply_text("您没有管理任何群组")
            return
        
        # 如果管理多个群组，让管理员选择要查询的群组
        if len(admin_groups) > 1:
            keyboard = []
            for group_name, group_id in admin_groups.items():
                keyboard.append([InlineKeyboardButton(f"查询 {group_name}", callback_data=f"query_group_{group_id}")])
            
            reply_markup = InlineKeyboardMarkup(keyboard)
            await update.message.reply_text("请选择要查询的群组：", reply_markup=reply_markup)
            return
        
        # 如果只管理一个群组，直接显示该群组的交易信息
        group_id = list(admin_groups.values())[0]
        group_name = list(admin_groups.keys())[0]
        await show_group_reports(update.message.chat_id, group_id, group_name, context)
        
    except Exception as e:
        logger.exception(f"处理本群查询时发生错误: {e}")
        await update.message.reply_text("查询群组交易信息时发生错误")

async def show_group_reports(chat_id, group_id, group_name, context):
    """显示指定群组的交易信息"""
    try:
        # 获取该群组的所有交易信息
        all_reports = get_all_reports()
        group_reports = []
        
        for report_id, report in all_reports.items():
            # 检查是否属于该群组
            if report.get('group_chat_id') == group_id:
                status = report.get('status', '')
                
                # 格式化订单信息，使用完整的订单号
                report_hash = report_id
                
                # 获取状态文本
                status_text = '已确认 正在交易' if status == ORDER_STATUS['CONFIRMED'] else \
                            '已完成' if status == ORDER_STATUS['COMPLETED'] else \
                            '已取消' if status == ORDER_STATUS['CANCELLED'] else \
                            '取消中' if status == ORDER_STATUS['CANCELLING'] else \
                            '等待确认'
                
                # 计算过期时间（示例：创建时间加2天）
                created_time = report.get('created_time', '')
                if created_time:
                    try:
                        created_date = datetime.strptime(created_time, "%Y-%m-%d %H:%M:%S")
                        # 假设过期时间为创建时间后2天
                        expire_date = created_date + timedelta(days=2)
                        expire_time = expire_date.strftime("%m-%d %H:%M:%S")
                    except Exception as e:
                        expire_time = ""
                else:
                    expire_time = ""
                
                # 格式化开始时间
                start_time = ""
                if created_time:
                    try:
                        created_date = datetime.strptime(created_time, "%Y-%m-%d %H:%M:%S")
                        start_time = created_date.strftime("%m-%d %H:%M:%S")
                    except Exception as e:
                        start_time = ""
                
                report_text = (
                    f"{report_hash} 交易对象 "
                    f"{report.get('customer_username', '')} "
                    f"ID{report.get('customer_id', '')} "
                    f"@{report.get('customer_username', '').replace('@', '')} "
                    f"{status_text}"
                    f"\n金额 {report.get('amount', '')}U"
                    f"\n开启时间 {start_time.split()[0]} {start_time.split()[1]} 过期时间："
                    f"{expire_time}"
                )
                group_reports.append((report_text, report_id, status))
        
        if group_reports:
            # 按创建时间排序（如果有）或保持原顺序
            group_reports.sort(key=lambda x: get_report(x[1]).get('created_time', '') if get_report(x[1]) else '', reverse=True)
            
            # 添加页面标题和计数
            message_text = f"尊贵的管理员 您正在查询 {group_name} 的交易信息\n\n本页共计 {len(group_reports)} 条\n\n"
            
            # 添加每条交易信息
            for i, (report_text, _, _) in enumerate(group_reports):
                message_text += f"{report_text}\n\n"
            
            # 添加底部按钮
            keyboard = [
                [
                    InlineKeyboardButton("✅所有", callback_data="filter_group_all"),
                    InlineKeyboardButton("未提交", callback_data="filter_group_pending"),
                    InlineKeyboardButton("正在交易", callback_data="filter_group_trading"),
                ],
                [
                    InlineKeyboardButton("已完成", callback_data="filter_group_completed"),
                    InlineKeyboardButton("已取消", callback_data="filter_group_cancelled"),
                ],
                [
                    InlineKeyboardButton("统计表格下载", callback_data="download_group_stats"),
                ]
            ]
            
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            # 发送消息
            await context.bot.send_message(
                chat_id=chat_id,
                text=message_text,
                reply_markup=reply_markup
            )
        else:
            # 没有找到交易信息
            await context.bot.send_message(
                chat_id=chat_id,
                text=f"群组 '{group_name}' 没有交易信息"
            )
            
    except Exception as e:
        logger.exception(f"显示群组交易信息时发生错误: {e}")
        await context.bot.send_message(
            chat_id=chat_id,
            text="获取群组交易信息时发生错误"
        )

# 添加处理群组查询按钮的回调函数
async def handle_group_query(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理群组查询按钮"""
    try:
        query = update.callback_query
        group_id = int(query.data.split('_')[2])
        
        # 获取群组名称
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("SELECT `group_name` FROM `groups` WHERE `group_id` = %s", (group_id,))
            group = cursor.fetchone()
            group_name = group['group_name'] if group else "未知群组"
        finally:
            conn.close()
        
        await query.answer()
        await show_group_reports(query.message.chat_id, group_id, group_name, context)
        
    except Exception as e:
        logger.exception(f"处理群组查询按钮时发生错误: {e}")
        await query.answer("处理查询请求时发生错误", show_alert=True)

async def handle_group_filter(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理群组交易信息筛选按钮"""
    try:
        query = update.callback_query
        filter_type = query.data.split('_')[2]  # filter_group_all -> all
        user = query.from_user
        
        # 获取当前消息中的群组ID（需要从消息中提取或存储在用户数据中）
        # 这里简化处理，假设我们可以从消息文本中提取群组ID
        # 实际应用中可能需要更复杂的状态管理
        
        # 获取管理员管理的群组
        admin_groups = get_admin_groups(user.id)
        if not admin_groups:
            await query.answer("您没有管理任何群组", show_alert=True)
            return
            
        # 这里简化处理，假设只处理一个群组
        # 在实际应用中，可能需要从消息或用户会话状态中获取当前查询的群组ID
        group_id = list(admin_groups.values())[0]
        group_name = list(admin_groups.keys())[0]
        
        # 获取该群组的所有交易信息
        all_reports = get_all_reports()
        filtered_reports = []
        
        for report_id, report in all_reports.items():
            # 检查是否属于该群组
            if report.get('group_chat_id') == group_id:
                status = report.get('status', '')
                
                # 根据筛选类型过滤
                if filter_type == 'all' or \
                   (filter_type == 'pending' and status == ORDER_STATUS['WAITING_CONFIRMATION']) or \
                   (filter_type == 'trading' and status == ORDER_STATUS['CONFIRMED']) or \
                   (filter_type == 'completed' and status == ORDER_STATUS['COMPLETED']) or \
                   (filter_type == 'cancelled' and (status == ORDER_STATUS['CANCELLED'] or status == ORDER_STATUS['CANCELLING'])):
                    
                    # 格式化订单信息，类似图片中的格式
                    # 生成类似TDa67dd61bt197f3f795c3的ID
                    report_hash = f"{report_id[-6:]}"
                    
                    # 获取状态文本
                    status_text = '已确认 正在交易' if status == ORDER_STATUS['CONFIRMED'] else \
                                '已完成' if status == ORDER_STATUS['COMPLETED'] else \
                                '已取消' if status == ORDER_STATUS['CANCELLED'] else \
                                '取消中' if status == ORDER_STATUS['CANCELLING'] else \
                                '等待确认'
                    
                    # 计算过期时间（示例：创建时间加2天）
                    created_time = report.get('created_time', '')
                    if created_time:
                        try:
                            created_date = datetime.strptime(created_time, "%Y-%m-%d %H:%M:%S")
                            # 假设过期时间为创建时间后2天
                            expire_date = created_date + timedelta(days=2)
                            expire_time = expire_date.strftime("%m-%d %H:%M:%S")
                        except Exception as e:
                            expire_time = ""
                    else:
                        expire_time = ""
                    
                    # 格式化开始时间
                    start_time = ""
                    if created_time:
                        try:
                            created_date = datetime.strptime(created_time, "%Y-%m-%d %H:%M:%S")
                            start_time = created_date.strftime("%m-%d %H:%M:%S")
                        except Exception as e:
                            start_time = ""
                    
                    report_text = (
                        f"{report_hash} 交易对象 "
                        f"{report.get('customer_username', '')} "
                        f"ID{report.get('customer_id', '')} "
                        f"@{report.get('customer_username', '').replace('@', '')} "
                        f"{status_text}"
                        f"\n金额 {report.get('amount', '')}U"
                        f"\n开启时间 {start_time.split()[0]} {start_time.split()[1]} 过期时间："
                        f"{expire_time}"
                    )
                    filtered_reports.append((report_text, report_id, status))
        
        if filtered_reports:
            # 按创建时间排序（如果有）或保持原顺序
            filtered_reports.sort(key=lambda x: get_report(x[1]).get('created_time', '') if get_report(x[1]) else '', reverse=True)
            
            # 添加页面标题和计数
            message_text = f"尊贵的管理员 您正在查询 {group_name} 的交易信息\n\n本页共计 {len(filtered_reports)} 条\n\n"
            
            # 添加每条交易信息
            for i, (report_text, _, _) in enumerate(filtered_reports):
                message_text += f"{report_text}\n\n"
            
            # 更新按钮状态
            keyboard = [
                [
                    InlineKeyboardButton(f"所有{'✅' if filter_type == 'all' else ''}", callback_data="filter_group_all"),
                    InlineKeyboardButton(f"未提交{'✅' if filter_type == 'pending' else ''}", callback_data="filter_group_pending"),
                    InlineKeyboardButton(f"正在交易{'✅' if filter_type == 'trading' else ''}", callback_data="filter_group_trading"),
                ],
                [
                    InlineKeyboardButton(f"已完成{'✅' if filter_type == 'completed' else ''}", callback_data="filter_group_completed"),
                    InlineKeyboardButton(f"已取消{'✅' if filter_type == 'cancelled' else ''}", callback_data="filter_group_cancelled"),
                ],
                [
                    InlineKeyboardButton("统计表格下载", callback_data="download_group_stats"),
                ]
            ]
            
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            # 更新消息
            await query.edit_message_text(
                text=message_text,
                reply_markup=reply_markup
            )
        else:
            # 如果没有符合条件的交易信息
            keyboard = [
                [
                    InlineKeyboardButton(f"所有{'✅' if filter_type == 'all' else ''}", callback_data="filter_group_all"),
                    InlineKeyboardButton(f"未提交{'✅' if filter_type == 'pending' else ''}", callback_data="filter_group_pending"),
                    InlineKeyboardButton(f"正在交易{'✅' if filter_type == 'trading' else ''}", callback_data="filter_group_trading"),
                ],
                [
                    InlineKeyboardButton(f"已完成{'✅' if filter_type == 'completed' else ''}", callback_data="filter_group_completed"),
                    InlineKeyboardButton(f"已取消{'✅' if filter_type == 'cancelled' else ''}", callback_data="filter_group_cancelled"),
                ],
                [
                    InlineKeyboardButton("统计表格下载", callback_data="download_group_stats"),
                ]
            ]
            
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                text=f"没有找到符合条件的交易信息",
                reply_markup=reply_markup
            )
        
        await query.answer()
        
    except Exception as e:
        logger.exception(f"处理群组筛选按钮时发生错误: {e}")
        await query.answer("处理筛选请求时发生错误", show_alert=True)

async def download_group_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理群组统计表格下载按钮"""
    query = update.callback_query
    await query.answer("群组统计表格下载功能正在开发中")
    # 这里可以添加生成和发送群组统计表格的逻辑

async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理按钮回调"""
    query = update.callback_query
    await query.answer()  # 响应回调查询
    
    if query.data.startswith("confirm_"):
        report_id = query.data.split("_")[1]  # 获取报备编号
        logger.debug(f"确认报备的 report_id: {report_id}")  # 添加调试日志
        
        # 获取报备信息
        report_info = get_report(report_id) # 从数据库获取
        logger.debug(f"获取的报备信息: {report_info}")  # 添加调试日志
        logger.debug(f"当前报备信息字典: {reports}")  # 查看整个字典
        
        if report_info:
            # 发送带参数的 /start 命令
            await context.bot.send_message(
                chat_id=query.from_user.id,
                text=f"请点击以下链接确认报备：\n/start r{report_id}",
                disable_web_page_preview=True
            )
        else:
            await context.bot.send_message(
                chat_id=query.from_user.id,
                text="报备信息不存在"
            )
    elif query.data == "complete":
        await query.edit_message_text(
            text=f"{query.message.text}\n\n"
                 "✅ 订单已完成",
            reply_markup=None
        )
    elif query.data == "cancel":
        await query.edit_message_text(
            text=f"{query.message.text}\n\n"
                 "❌ 订单已取消",
            reply_markup=None
        )

async def my_orders(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理我的订单命令 - 仅供交易方查看自己的订单"""
    try:
        user = update.message.from_user
        
        # 管理员不需要使用此功能
        if is_admin(user.id):
            await update.message.reply_text("此功能仅供交易方查看自己的订单")
            return
            
        user_orders = []
        
        # 只显示客人自己的订单
        
        # 遍历所有报备，找出已确认的订单
        for report_id, report in get_all_reports().items(): # 从数据库获取所有报备
            # 检查是否是客人的订单
            is_customer = user.username == report.get('customer_username', '').replace('@', '')
            
            # 只显示客人自己的订单
            if is_customer and report.get('status') in [ORDER_STATUS['CONFIRMED'], ORDER_STATUS['CANCELLING'], ORDER_STATUS['COMPLETED'], ORDER_STATUS['CANCELLED']]:
                # 获取订单状态的中文描述
                status = report.get('status', '')
                status_text = '已完成' if status == ORDER_STATUS['COMPLETED'] else \
                            '已取消' if status == ORDER_STATUS['CANCELLED'] else \
                            '取消中' if status == ORDER_STATUS['CANCELLING'] else \
                            '已确认'
                
                # 获取群组编号
                group_chat_id = report.get('group_chat_id')
                group_code = ""
                if group_chat_id:
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    try:
                        cursor.execute("SELECT `group_code` FROM `groups` WHERE `group_id` = %s", (group_chat_id,))
                        group = cursor.fetchone()
                        if group and group.get('group_code'):
                            group_code = group.get('group_code')
                    except Exception as e:
                        logger.error(f"获取群组编号失败: {str(e)}")
                    finally:
                        conn.close()
                
                # 格式化订单信息
                order_text = (
                    f"公群{group_code or '未知'} 订单号{report_id} "
                    f"交易方 @{report.get('customer_username', '').replace('@', '')} "
                    f"金额{report.get('amount', '')}u "
                    f"{status_text}"
                )
                user_orders.append((order_text, report_id, status))
        
        if user_orders:
            # 按创建时间排序（如果有）或保持原顺序
            user_orders.sort(key=lambda x: get_report(x[1]).get('created_time', '') if get_report(x[1]) else '', reverse=True)
            # 添加序号并创建消息文本
            message_text = "\n".join(f"{i+1}. {order[0]}" for i, order in enumerate(user_orders))
            
            # 创建状态筛选按钮
            keyboard = [
                [
                    InlineKeyboardButton("首页", callback_data="filter_home"),
                ],
                [
                    InlineKeyboardButton("所有✅", callback_data="filter_all"),
                    InlineKeyboardButton("已确认", callback_data="filter_confirmed"),
                    InlineKeyboardButton("已完成", callback_data="filter_completed"),
                    InlineKeyboardButton("已取消", callback_data="filter_cancelled"),
                ],
                [
                    InlineKeyboardButton("统计表格下载", callback_data="download_stats"),
                ]
            ]
            
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            # 发送消息和按钮
            await update.message.reply_text(
                message_text,
                reply_markup=reply_markup
            )
        else:
            # 没有找到客人的订单
            await update.message.reply_text("您被报备且被确认的交易信息\n\n未查询到您的交易信息")
            
    except Exception as e:
        logger.exception(f"处理我的订单请求时发生错误: {e}")
        await update.message.reply_text("获取订单记录时发生错误")

# 添加处理筛选按钮的回调函数
async def handle_order_filter(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理订单筛选按钮"""
    query = update.callback_query
    filter_type = query.data.split('_')[1]
    user = query.from_user
    filtered_orders = []
    
    # 处理首页按钮
    if filter_type == 'home':
        # 将首页按钮视为"所有"按钮，重用相同的逻辑
        filter_type = 'all'
        # 继续执行后面的代码，不需要return
    
    # 遍历所有报备，根据筛选类型过滤订单
    for report_id, report in get_all_reports().items(): # 从数据库获取所有报备
        # 检查是否是交易方或管理员
        is_customer = user.username == report.get('customer_username', '').replace('@', '')
        is_user_admin = is_admin(user.id) # 检查是否是管理员
        
        if is_customer or is_user_admin:
                # 获取状态文本
            status = report.get('status', '')
            status_text = '已完成' if status == ORDER_STATUS['COMPLETED'] else \
                              '已取消' if status == ORDER_STATUS['CANCELLED'] else \
                              '取消中' if status == ORDER_STATUS['CANCELLING'] else \
                              '已确认'
            
            # 根据筛选类型决定是否添加到结果中
            if filter_type == 'all' or \
               (filter_type == 'confirmed' and status == ORDER_STATUS['CONFIRMED']) or \
               (filter_type == 'completed' and status == ORDER_STATUS['COMPLETED']) or \
               (filter_type == 'cancelled' and (status == ORDER_STATUS['CANCELLED'] or status == ORDER_STATUS['CANCELLING'])):
                
                # 获取群组编号
                group_chat_id = report.get('group_chat_id')
                group_code = ""
                if group_chat_id:
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    try:
                        cursor.execute("SELECT `group_code` FROM `groups` WHERE `group_id` = %s", (group_chat_id,))
                        group = cursor.fetchone()
                        if group and group.get('group_code'):
                            group_code = group.get('group_code')
                    except Exception as e:
                        logger.error(f"获取群组编号失败: {str(e)}")
                    finally:
                        conn.close()
                
                # 格式化订单信息
                order_text = (
                    f"公群{group_code or '未知'} 订单号{report_id} "
                    f"交易方 @{report.get('customer_username', '').replace('@', '')} "
                    f"金额{report.get('amount', '')}u "
                    f"{status_text}"
                )
                filtered_orders.append((order_text, report_id))
    
    if filtered_orders:
        # 按创建时间排序（如果有）或保持原顺序
        filtered_orders.sort(key=lambda x: get_report(x[1]).get('created_time', '') if get_report(x[1]) else '', reverse=True)
        # 添加序号并创建消息文本
        message_text = "\n".join(f"{i+1}. {order[0]}" for i, order in enumerate(filtered_orders))
        
        # 更新按钮状态
        keyboard = [
            [
                InlineKeyboardButton("首页", callback_data="filter_home"),
            ],
            [
                InlineKeyboardButton(f"所有{'✅' if filter_type == 'all' else ''}", callback_data="filter_all"),
                InlineKeyboardButton(f"已确认{'✅' if filter_type == 'confirmed' else ''}", callback_data="filter_confirmed"),
                InlineKeyboardButton(f"已完成{'✅' if filter_type == 'completed' else ''}", callback_data="filter_completed"),
                InlineKeyboardButton(f"已取消{'✅' if filter_type == 'cancelled' else ''}", callback_data="filter_cancelled"),
            ],
            [
                InlineKeyboardButton("统计表格下载", callback_data="download_stats"),
            ]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # 更新消息
        await query.message.edit_text(
            message_text,
            reply_markup=reply_markup
        )
    else:
        # 如果没有符合条件的订单
        # 更新按钮状态
        keyboard = [
            [
                InlineKeyboardButton("首页", callback_data="filter_home"),
            ],
            [
                InlineKeyboardButton(f"所有{'✅' if filter_type == 'all' else ''}", callback_data="filter_all"),
                InlineKeyboardButton(f"已确认{'✅' if filter_type == 'confirmed' else ''}", callback_data="filter_confirmed"),
                InlineKeyboardButton(f"已完成{'✅' if filter_type == 'completed' else ''}", callback_data="filter_completed"),
                InlineKeyboardButton(f"已取消{'✅' if filter_type == 'cancelled' else ''}", callback_data="filter_cancelled"),
            ],
            [
                InlineKeyboardButton("统计表格下载", callback_data="download_stats"),
            ]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.message.edit_text(
            "没有找到符合条件的订单",
            reply_markup=reply_markup
        )
    
    await query.answer()

# 删除help函数

async def start_report(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """开始报备流程"""
    # 检查是否是管理员且在私聊
    if not is_admin(update.effective_user.id): # 使用is_admin函数检查是否是管理员
        await update.message.reply_text("只有管理员才能发起报备。")
        return
    
    if update.effective_chat.type != "private":
        await update.message.reply_text("请在私聊中发起报备。")
        return
    
    # 开始报备流程
    await update.message.reply_text(
        "报备模板中必须包含：\n\n"
        "交易方用户名或ID:\n"
        "交易总金额:\n"
        "报备有效期:\n"
        "群方用户名：\n"
        "交易项目：\n"
        "附加规则：",
        reply_markup=ForceReply(),
        disable_web_page_preview=True
    )

async def handle_report_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理报备信息输入"""
    try:
        message = update.message
        text = message.text
        
        # 检查是否是管理员
        if not is_admin(update.effective_user.id): # 使用is_admin函数检查是否是管理员
            await message.reply_text("非管理员无法操作")
            return
        
        # 解析报备信息
        customer_username = None
        amount = None
        
        # 解析交易方用户名或ID
        match = re.search(r'交易方用户名或ID:(.*?)(?:\n|$)', text)
        if match:
            customer_username = match.group(1).strip()
            # 如果用户名以@开头，去掉@
            if customer_username.startswith('@'):
                customer_username = customer_username[1:]
            
        # 解析交易金额
        match = re.search(r'交易总金额:(.*?)(?:\n|$)', text)
        if match:
            amount = match.group(1).strip()
            
        if not customer_username or not amount:
            await message.reply_text("报备格式错误，请检查后重试")
            return
            
        # 生成报备编号
        report_id = await generate_report_id() # 生成随机订单号
        
        # 解析报备有效期
        validity_days = 1  # 默认1天
        validity_match = re.search(r'报备有效期:(.*?)(?:\n|$)', text)
        if validity_match:
            validity_text = validity_match.group(1).strip()
            # 尝试提取数字
            days_match = re.search(r'(\d+)', validity_text)
            if days_match:
                try:
                    validity_days = int(days_match.group(1))
                except ValueError:
                    pass
        
        # 计算过期时间
        created_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        expire_date = datetime.now() + timedelta(days=validity_days)
        expire_time = expire_date.strftime("%m月%d日%H:%M:%S")
        
        # 屏蔽用户名
        masked_text = re.sub(r'交易方用户名或ID:(.*?)(?:\n|$)', r'交易方用户名或ID: ****\n', text)
        
        # 替换报备有效期行，添加具体过期时间
        masked_text = re.sub(
            r'(报备有效期:.*?)(?:\n|$)',
            f'报备有效期:{validity_days}天 时间至{expire_time}\n',
            masked_text
        )
        
        # 保存报备信息
        save_report(report_id, {
            'info': text,
            'masked_info': masked_text,
            'customer_username': customer_username,
            'status': ORDER_STATUS['WAITING_CONFIRMATION'],
            'reporter_id': update.effective_user.id,
            'reporter_username': update.effective_user.username,
            'amount': amount,  # 添加金额字段
            'created_time': created_time
        }) # 保存到数据库
        
        # 获取用户管理的群组
        admin_groups = get_admin_groups(update.effective_user.id)
        
        if not admin_groups:
            await message.reply_text("您没有管理任何群组，无法发起报备")
            delete_report(report_id)  # 删除已创建的报备
            return
        
        # 发送确认按钮 - 只显示群组编号以避免callback_data过长
        buttons = []
        for name, group_id in admin_groups.items():
            # 从数据库获取群组编号
            conn = get_db_connection()
            cursor = conn.cursor()
            try:
                cursor.execute("SELECT `group_code` FROM `groups` WHERE `group_id` = %s", (group_id,))
                group = cursor.fetchone()
                # 使用群组编号或简短名称
                display_name = f"公群{group.get('group_code', '')}" if group and group.get('group_code') else f"群组{str(group_id)[-4:]}"
                buttons.append([InlineKeyboardButton(text=display_name, callback_data=f"send_{report_id}_{group_id}")])
            except Exception as e:
                logger.error(f"获取群组编号失败: {str(e)}")
                # 如果获取失败，使用简短标识
                buttons.append([InlineKeyboardButton(text=f"群组{str(group_id)[-4:]}", callback_data=f"send_{report_id}_{group_id}")])
            finally:
                conn.close()
        
        # 添加取消按钮
        buttons.append([InlineKeyboardButton(text="取消", callback_data=f"cancel_send_{report_id}")])
        reply_markup = InlineKeyboardMarkup(buttons)

        
        await message.reply_text(
            f"{report_id}\n{masked_text}",
            reply_markup=reply_markup
        )
        
    except Exception as e:
        logger.exception(f"处理报备信息输入时发生错误: {e}")
        await message.reply_text("处理报备信息输入时发生错误，请重试")

async def send_to_group(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """发送报备到选定的群组"""
    query = update.callback_query
    await query.answer()
    
    # 解析回调数据
    parts = query.data.split('_')
    report_id = parts[1]
    group_id = int(parts[2])  # 现在直接使用群组ID
    
    # 从数据库获取报备信息
    report = get_report(report_id)
    if not report:
        await query.edit_message_text("报备信息已过期或不存在")
        return
    
    # 检查用户是否有权限管理此群组
    admin_groups = get_admin_groups(query.from_user.id)
    if group_id not in admin_groups.values():
        await query.edit_message_text("群组不存在、未激活或您无权管理该群组")
        return
    
    # 使用已经隐藏的信息
    masked_info = report['masked_info']
    
    # 保存创建时间和群组ID
    created_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    report['created_time'] = created_time
    report['group_chat_id'] = group_id
    
    # 使用格式化函数生成报备信息
    formatted_text = format_report_message(report_id, report, "")
    
    # 创建确认和取消按钮
    keyboard = [
        [
            InlineKeyboardButton("确认", callback_data=f"confirm_{report_id}"),
            InlineKeyboardButton("取消", callback_data=f"cancel_{report_id}")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # 添加重试机制
    max_retries = 3
    retry_delay = 1  # 秒
    
    for attempt in range(max_retries):
        try:
            # 发送到选定的群组
            message = await context.bot.send_message(
                chat_id=group_id,
                text=formatted_text,
                reply_markup=reply_markup,
                disable_web_page_preview=True,
                parse_mode='HTML'  # 添加HTML解析模式
            )
            
            # 保存群组消息信息
            report['group_message_id'] = message.message_id
            save_report(report_id, report)  # 保存到数据库
            
            # 更新私聊消息，修改成功提示
            await query.edit_message_text(
                "发送成功，请在公群内查看"
            )
            return  # 成功发送后退出
        except (TimedOut, NetworkError) as e:
            if attempt == max_retries - 1:  # 最后一次尝试
                await query.edit_message_text(
                    "❌ 网络连接不稳定，请稍后重试。"
                )
                print(f"发送失败（尝试 {attempt + 1}/{max_retries}）：{str(e)}")
            else:
                print(f"重试中（{attempt + 1}/{max_retries}）...")
                await asyncio.sleep(retry_delay)
        except Exception as e:
            await query.edit_message_text(f"❌ 发送失败！\n错误信息：{str(e)}")
            print(f"未知错误：{str(e)}")
            break

async def cancel_send(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理报备发送前的取消"""
    try:
        query = update.callback_query
        report_id = query.data.split('_')[2]  # cancel_send_编号：01
        
        if report_id in get_all_reports(): # 从数据库获取报备
            delete_report(report_id) # 从数据库删除
            
        await query.message.edit_text("已取消报备")
        await query.answer("已取消")
        
    except Exception as e:
        logger.exception(f"取消报备时发生错误: {e}")
        await query.answer("处理取消请求时发生错误", show_alert=True)

async def cancel_report(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理普通取消按钮"""
    try:
        query = update.callback_query
        report_id = query.data.split('_')[1]
        current_user = query.from_user
        
        if report_id not in get_all_reports(): # 从数据库获取报备
            await query.answer("报备信息已过期或不存在", show_alert=True)
            return
        
        report = get_report(report_id) # 从数据库获取报备
        
        # 检查是否是客户或管理员
        is_customer = current_user.username == report.get('customer_username', '').replace('@', '')
        is_user_admin = is_admin(current_user.id) # 检查是否是管理员
        
        if not (is_customer or is_user_admin):
            await query.answer("只有交易方或管理员可以取消报备", show_alert=True)
            return
        
        # 直接取消报备
        report["status"] = ORDER_STATUS['CANCELLED']
        save_report(report_id, report) # 保存到数据库
        
        # 使用格式化函数生成报备信息
        formatted_info = format_report_message(report_id, report, "已取消")
        
        # 更新群组消息
        await context.bot.edit_message_text(
            chat_id=report['group_chat_id'],
            message_id=report['group_message_id'],
            text=formatted_info,
            reply_markup=None,  # 移除按钮
            parse_mode='HTML'  # 添加HTML解析模式
        )
        
        await query.answer("已取消", show_alert=True)
            
    except Exception as e:
        logger.exception(f"取消报备时发生错误: {e}")
        await query.answer("处理取消请求时发生错误", show_alert=True)

async def cancel_order(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理订单取消按钮"""
    try:
        query = update.callback_query
        parts = query.data.split('_')
        report_id = parts[2]  # 获取完整的报备ID
        logger.debug(f"Cancel order called with data: {query.data}, report_id: {report_id}")
        current_user = query.from_user
        
        if report_id not in get_all_reports(): # 从数据库获取报备
            await query.answer("报备信息已过期或不存在", show_alert=True)
            return
        
        report = get_report(report_id) # 从数据库获取报备
        
        # 检查是否是客户或管理员
        is_customer = current_user.username == report.get('customer_username', '').replace('@', '')
        is_user_admin = is_admin(current_user.id) # 检查是否是管理员
        
        if not (is_customer or is_user_admin):
            await query.answer("只有交易方或管理员可以取消订单", show_alert=True)
            return
            
        # 如果是客户点击订单取消
        if is_customer:
            # 检查订单是否已经取消
            if report.get('status') == ORDER_STATUS['CANCELLED']:
                await query.answer("订单已经取消了", show_alert=True)
                return
            
            # 如果管理员已经申请订单取消，则完成取消
            if report.get('admin_cancelled'):
                # 更新报备状态为已取消
                report["status"] = ORDER_STATUS['CANCELLED']
                save_report(report_id, report) # 保存到数据库
                
                # 使用格式化函数生成报备信息
                cancel_message = format_report_message(report_id, report, "已取消")
                
                # 更新群组消息
                await context.bot.edit_message_text(
                    chat_id=report['group_chat_id'],
                    message_id=report['group_message_id'],
                    text=cancel_message,
                    reply_markup=None,
                    parse_mode='HTML'  # 添加HTML解析模式
                )
                
                # 更新当前消息（如果是在私聊中）
                if query.message.chat.type == 'private':
                    await query.edit_message_text(
                        text=cancel_message,
                        reply_markup=None,
                        parse_mode='HTML'  # 添加HTML解析模式
                    )
                
                await query.answer("已取消", show_alert=True)
                return
            
            # 检查是否已经申请过取消
            if report.get('customer_cancelled'):
                await query.answer("您已经申请过取消了，等待群老板确认", show_alert=True)
                return
            
            # 否则标记客户已申请订单取消
            report['customer_cancelled'] = True
            report["status"] = ORDER_STATUS['CANCELLING']
            save_report(report_id, report) # 保存到数据库
            
            # 更新群组消息
            try:
                await query.edit_message_text(
                    text=(
                        f"{report_id}\n"
                        f"{report['masked_info']}\n\n"
                        f"✅ 报备已确认\n"
                        f"客户已取消，等待群老板确认取消"
                    ),
                    reply_markup=InlineKeyboardMarkup([
                        [
                            InlineKeyboardButton("双方确认完成", callback_data=f"complete_{report_id}"),
                            InlineKeyboardButton("双方确认取消", callback_data=f"order_cancel_{report_id}")
                        ]
                    ])
                )
            except Exception as e:
                logger.error(f"Failed to update cancel message: {e}")
                # 如果更新失败，给用户一个提示
                await query.answer("取消申请已提交", show_alert=True)
                return
            
            # 通知管理员
            for admin_id in SUPER_ADMIN_IDS: # 改为 SUPER_ADMIN_IDS
                try:
                    await context.bot.send_message(
                        chat_id=admin_id,
                        text=(
                            f"⚠️ 客户申请取消订单\n\n"
                            f"{report_id}\n"
                            f"{report['info']}"
                        ),
                        reply_markup=InlineKeyboardMarkup([
                            [
                                InlineKeyboardButton("双方确认完成", callback_data=f"complete_{report_id}"),
                                InlineKeyboardButton("双方确认取消", callback_data=f"order_cancel_{report_id}")
                            ]
                        ]),
                        disable_web_page_preview=True
                    )
                except Exception as e:
                    logger.error(f"Failed to notify admin {admin_id}: {e}")
            
            await query.answer("等待群老板确认取消", show_alert=True)
            
        # 如果是管理员点击订单取消
        elif is_user_admin:
            # 检查订单是否已经取消
            if report.get('status') == ORDER_STATUS['CANCELLED']:
                await query.answer("订单已经取消了", show_alert=True)
                return
            
            # 如果客户已经申请订单取消，则完成取消
            if report.get('customer_cancelled'):
                # 更新报备状态为已取消
                report["status"] = ORDER_STATUS['CANCELLED']
                save_report(report_id, report) # 保存到数据库
                
                # 使用格式化函数生成报备信息
                cancel_message = format_report_message(report_id, report, "已取消")
                
                # 更新群组消息
                await context.bot.edit_message_text(
                    chat_id=report['group_chat_id'],
                    message_id=report['group_message_id'],
                    text=cancel_message,
                    reply_markup=None,
                    parse_mode='HTML'  # 添加HTML解析模式
                )
                
                # 更新当前消息（如果是在私聊中）
                if query.message.chat.type == 'private':
                    await query.edit_message_text(
                        text=cancel_message,
                        reply_markup=None,
                        parse_mode='HTML'  # 添加HTML解析模式
                    )
                
                await query.answer("已取消", show_alert=True)
                return
            
            # 检查是否已经申请过取消
            if report.get('admin_cancelled'):
                await query.answer("您已经申请过取消了，等待客户确认", show_alert=True)
                return
            
            # 否则标记管理员已申请订单取消
            report['admin_cancelled'] = True
            report["status"] = ORDER_STATUS['CANCELLING']
            save_report(report_id, report) # 保存到数据库
            
            # 更新群组消息
            try:
                await query.edit_message_text(
                    text=(
                        f"{report_id}\n"
                        f"{report['masked_info']}\n\n"
                        f"✅ 报备已确认\n"
                        f"管理员已取消，等待客户确认取消"
                    ),
                    reply_markup=InlineKeyboardMarkup([
                        [
                            InlineKeyboardButton("双方确认完成", callback_data=f"complete_{report_id}"),
                            InlineKeyboardButton("双方确认取消", callback_data=f"order_cancel_{report_id}")
                        ]
                    ])
                )
            except Exception as e:
                logger.error(f"Failed to update admin cancel message: {e}")
                # 如果更新失败，给用户一个提示
                await query.answer("取消申请已提交", show_alert=True)
                return
            
            # 通知客户
            try:
                await context.bot.send_message(
                    chat_id=report['customer_id'],
                    text=(
                        f"⚠️ 管理员申请取消订单\n\n"
                        f"{report_id}\n"
                        f"{report['info']}"
                    ),
                    reply_markup=InlineKeyboardMarkup([
                        [
                            InlineKeyboardButton("订单取消", callback_data=f"order_cancel_{report_id}")
                        ]
                    ]),
                    disable_web_page_preview=True
                )
            except Exception as e:
                logger.error(f"Failed to notify customer: {e}")
            
            await query.answer("等待客户确认取消", show_alert=True)
            
    except Exception as e:
        logger.exception(f"取消订单时发生错误: {e}")
        await query.answer("处理取消请求时发生错误", show_alert=True)

async def handle_video(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理接收到的视频消息"""
    try:
        video = update.message.video
        user = update.message.from_user
        
        if video:
            # 检查是否是管理员
            if user.id in SUPER_ADMIN_IDS: # 改为 SUPER_ADMIN_IDS
                # 管理员：显示视频file_id信息
                file_id = video.file_id
                file_info = (
                    f"Video File ID: {file_id}\n"
                    f"Duration: {video.duration}s\n"
                    f"File size: {video.file_size} bytes"
                )
                logger.info(file_info)
                await update.message.reply_text(file_info)
            else:
                # 非管理员：显示报备模板
                template = (
                    "报备模板中必须包含：\n\n"
                    "交易方用户名或ID:\n"
                    "交易总金额:\n"
                    "报备有效期:\n"
                    "群方用户名：\n"
                    "交易项目：\n"
                    "附加规则："
                )
                await update.message.reply_text(template, disable_web_page_preview=True)
    except Exception as e:
        logger.exception(f"处理视频消息时发生错误: {e}")

async def complete_order(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理订单完成按钮"""
    try:
        query = update.callback_query
        report_id = query.data.split('_')[1]
        current_user = query.from_user
        
        if report_id not in get_all_reports(): # 从数据库获取报备
            await query.answer("订单信息已过期", show_alert=True)
            return
            
        report = get_report(report_id) # 从数据库获取报备
        
        # 检查是否是管理员或客户
        is_user_admin = is_admin(current_user.id) # 检查是否是管理员
        is_customer = current_user.username == report.get('customer_username', '').replace('@', '')
        
        if not (is_user_admin or is_customer):
            await query.answer("只有管理员或客户可以操作", show_alert=True)
            return

        # 如果是管理员点击
        if is_user_admin:
            # 检查是否已经确认过了
            if report.get('admin_completed'):
                await query.answer("您已经确认过完成了，等待客户确认", show_alert=True)
                return
            
            # 标记管理员已确认完成
            report['admin_completed'] = True
            save_report(report_id, report) # 保存到数据库
            
            # 更新群组消息和管理员私聊消息
            try:
                # 使用格式化函数生成报备信息
                formatted_info = format_report_message(report_id, report, "群老板已确认完成，等待客户确认完成")
                
                # 更新群组消息
                await context.bot.edit_message_text(
                    chat_id=report['group_chat_id'],
                    message_id=report['group_message_id'],
                    text=formatted_info,
                    reply_markup=InlineKeyboardMarkup([
                        [
                            InlineKeyboardButton("双方确认完成", callback_data=f"complete_{report_id}"),
                            InlineKeyboardButton("双方确认取消", callback_data=f"order_cancel_{report_id}")
                        ]
                    ]),
                    parse_mode='HTML'  # 添加HTML解析模式
                )
                
                # 更新当前消息（如果是在私聊中）
                if query.message.chat.type == 'private':
                    await query.edit_message_text(
                        text=formatted_info,
                        reply_markup=InlineKeyboardMarkup([
                            [
                                InlineKeyboardButton("双方确认完成", callback_data=f"complete_{report_id}"),
                                InlineKeyboardButton("双方确认取消", callback_data=f"order_cancel_{report_id}")
                            ]
                        ]),
                        parse_mode='HTML'  # 添加HTML解析模式
                    )
                
                await query.answer("等待客户确认完成", show_alert=True)
                
            except Exception as e:
                logger.error(f"Failed to update messages: {e}")
                # 如果更新失败，可能是因为内容相同，给用户一个提示
                await query.answer("状态已更新", show_alert=True)

        # 如果是客户点击
        elif is_customer:
            # 检查管理员是否已经确认完成
            if not report.get('admin_completed'):
                await query.answer("需要等待群老板先确认完成", show_alert=True)
                return
            
            # 检查是否已经完成了
            if report.get('status') == ORDER_STATUS['COMPLETED']:
                await query.answer("订单已经完成了", show_alert=True)
                return
            
            try:
                # 更新报备状态
                report['status'] = ORDER_STATUS['COMPLETED']
                save_report(report_id, report) # 保存到数据库
                
                # 使用格式化函数生成报备信息
                complete_message = format_report_message(report_id, report, "已完成")
                
                # 更新群组消息，添加双方互评按钮
                await context.bot.edit_message_text(
                    chat_id=report['group_chat_id'],
                    message_id=report['group_message_id'],
                    text=complete_message,
                    reply_markup=InlineKeyboardMarkup([
                        [
                            InlineKeyboardButton("双方互评", callback_data=f"rate_{report_id}")
                        ]
                    ]),
                    parse_mode='HTML'  # 添加HTML解析模式
                )
                
                # 如果是在私聊中，也更新私聊消息，添加双方互评按钮
                if query.message.chat.type == 'private':
                    await query.edit_message_text(
                        text=complete_message,
                        reply_markup=InlineKeyboardMarkup([
                            [
                                InlineKeyboardButton("双方互评", callback_data=f"rate_{report_id}")
                            ]
                        ]),
                        parse_mode='HTML'  # 添加HTML解析模式
                    )
                
                # 通知管理员
                for admin_id in SUPER_ADMIN_IDS: # 改为 SUPER_ADMIN_IDS
                    try:
                        await context.bot.send_message(
                            chat_id=admin_id,
                            text=f"✅ 订单已完成\n\n{report_id}\n{report['info']}",
                            disable_web_page_preview=True
                        )
                    except Exception as e:
                        logger.error(f"Failed to notify admin {admin_id}: {e}")
                
                await query.answer("订单已完成", show_alert=True)
                
            except Exception as e:
                logger.error(f"Failed to complete order: {e}")
                await query.answer("处理完成请求时发生错误", show_alert=True)
                
    except Exception as e:
        logger.exception(f"处理订单完成请求时发生错误: {e}")
        await query.answer("处理完成请求时发生错误", show_alert=True)

async def confirm_cancel_order(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理管理员确认取消订单"""
    try:
        query = update.callback_query
        report_id = query.data.split('_')[2]  # confirm_cancel_编号：01
        
        if report_id not in get_all_reports(): # 从数据库获取报备
            await query.answer("订单信息已过期", show_alert=True)
            return
            
        report = get_report(report_id) # 从数据库获取报备
        
        # 更新订单状态
        report["status"] = ORDER_STATUS['CANCELLED']
        
        # 更新群组消息
        await context.bot.edit_message_text(
            chat_id=report['group_chat_id'],
            message_id=report['group_message_id'],
            text=f"{report_id}\n{report['masked_info']}\n\n❌ 订单已取消",
            reply_markup=None
        )
        
        # 通知交易方
        customer_username = report.get('customer_username')
        if customer_username:
            await context.bot.send_message(
                chat_id=report.get('customer_id'),
                text=f"❌ 订单已取消\n\n{report_id}"
            )
        
        await query.answer("已确认取消订单", show_alert=True)
        
    except Exception as e:
        logger.exception(f"确认取消订单时发生错误: {e}")
        await query.answer("处理确认取消时发生错误", show_alert=True)

async def staff_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理新币员工确认按钮"""
    try:
        query = update.callback_query
        report_id = query.data.split('_')[2]
        current_user = query.from_user
        
        # 对所有用户显示权限不足
        await query.answer("权限不足", show_alert=True)
        return
            
    except Exception as e:
        logger.exception(f"处理新币员工确认时发生错误: {e}")
        await query.answer("处理确认请求时发生错误", show_alert=True)

# 添加自动确认的函数
async def auto_staff_confirm(report_id, context):
    """60秒后自动确认"""
    try:
        # 获取报备信息
        report = get_report(report_id)
        if not report:
            logger.error(f"自动确认失败：找不到报备 {report_id}")
            return
            
        # 检查报备状态
        if report.get('status') != ORDER_STATUS['CONFIRMED']:
            logger.error(f"自动确认失败：报备状态已改变 {report_id}")
            return
            
        # 检查是否已经被确认
        if report.get('staff_confirmed'):
            logger.info(f"报备 {report_id} 已被确认，无需自动确认")
            return
            
        # 标记新币员工已确认
        report['staff_confirmed'] = True
        save_report(report_id, report) # 保存到数据库
        
        # 使用格式化函数生成报备信息
        formatted_info = format_report_message(report_id, report, "新币员工已确认")
        
        # 更新群组消息，添加双方确认按钮
        await context.bot.edit_message_text(
            chat_id=report['group_chat_id'],
            message_id=report['group_message_id'],
            text=formatted_info,
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("双方确认完成", callback_data=f"complete_{report_id}"),
                    InlineKeyboardButton("双方确认取消", callback_data=f"order_cancel_{report_id}")
                ]
            ]),
            parse_mode='HTML'  # 添加HTML解析模式
        )
        
        logger.info(f"报备 {report_id} 已自动确认")
        
    except Exception as e:
        logger.exception(f"自动确认报备时发生错误: {e}")

async def reject_cancel_order(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """管理员拒绝取消订单"""
    try:
        query = update.callback_query
        report_id = query.data.split('_')[2]  # reject_cancel_reportid
        current_user = query.from_user
        
        if current_user.id not in SUPER_ADMIN_IDS: # 改为 SUPER_ADMIN_IDS
            await query.answer("只有管理员可以拒绝取消订单", show_alert=True)
            return
            
        if report_id not in get_all_reports(): # 从数据库获取报备
            await query.answer("报备信息已过期", show_alert=True)
            return
            
        report = get_report(report_id) # 从数据库获取报备
        
        if report["status"] != "waiting_cancel":
            await query.answer("此订单不在等待取消状态", show_alert=True)
            return
            
        # 恢复订单状态
        report["status"] = ORDER_STATUS['CONFIRMED']
        
        # 更新群组消息
        await context.bot.edit_message_text(
            chat_id=query.message.chat.id,
            message_id=query.message.message_id,
            text=f"{report_id}\n{report['masked_info']}\n\n✅ 报备已确认",
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("双方确认完成", callback_data=f"complete_{report_id}"),
                    InlineKeyboardButton("双方确认取消", callback_data=f"order_cancel_{report_id}")
                ]
            ])
        )
        
        # 通知交易方
        customer_id = report.get("customer_id")
        if customer_id:
            await context.bot.send_message(
                chat_id=customer_id,
                text=f"❗️ 订单取消申请已被管理员拒绝\n\n{report_id}",
                disable_web_page_preview=True
            )
        
        await query.answer("已拒绝取消申请", show_alert=True)
        
    except Exception as e:
        logger.exception(f"拒绝取消订单时发生错误: {e}")
        await query.answer("处理拒绝取消时发生错误", show_alert=True)

# 删除my_reports函数

async def create_report(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """创建报备信息"""
    report_id = await generate_report_id()  # 生成报备编号
    
    # 计算过期时间
    validity_days = 1  # 默认1天
    created_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    expire_date = datetime.now() + timedelta(days=validity_days)
    expire_time = expire_date.strftime("%m月%d日%H:%M:%S")
    
    # 创建带有过期时间的报备信息
    info = f'交易方用户名或ID: heige\n交易总金额: 1000\n报备有效期: 1天\n群方用户名：admin\n交易项目：USDT\n附加规则：无'
    masked_info = f'交易方用户名或ID: ****\n交易总金额: 1000\n报备有效期: 1天 时间至{expire_time}\n群方用户名：admin\n交易项目：USDT\n附加规则：无'
    
    
    save_report(report_id, {
        'info': info,
        'masked_info': masked_info,
        'customer_username': 'huohuapi',
        'status': 'waiting_confirmation',
        'reporter_id': update.effective_user.id,
        'reporter_username': update.effective_user.username,
        'amount': '1000',
        'created_time': created_time,
        'group_chat_id': update.effective_chat.id,
        'group_message_id': update.message.message_id
    }) # 保存到数据库
    logger.debug(f"当前报备信息字典: {reports}")  # 查看整个字典
    # save_reports()  # 保存报备信息到文件 - 移除旧的JSON保存

    # 保存 report_id
    report_ids.append(report_id)  # 将新生成的 report_id 添加到列表
    # save_report_ids(report_ids)  # 保存 report_id 列表到文件 - 移除旧的JSON保存

async def confirm_report(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """确认报备"""
    try:
        query = update.callback_query
        report_id = query.data.split('_')[1]
        current_user = query.from_user
        logger.debug(f"Confirm report called with report_id: {report_id}")
        
        if report_id not in get_all_reports(): # 从数据库获取报备
            await query.answer("报备信息已过期", show_alert=True)
            return
        
        report = get_report(report_id) # 从数据库获取报备
        logger.debug(f"Customer username from report: {report.get('customer_username')}")
        logger.debug(f"Current username: {current_user.username}")
        
        # 检查是否是交易方
        if current_user.username != report.get('customer_username').replace('@', ''):
            await query.answer("只有交易方可以确认报备", show_alert=True)
            return
        
        # 生成深度链接
        bot_info = await context.bot.get_me()
        bot_username = bot_info.username
        deep_link = f"https://t.me/{bot_username}?start=r{report_id}"
        logger.debug(f"Generated deep link: {deep_link}")
        
        # 设置状态为等待私聊确认
        report["status"] = "waiting_confirmation"
        report['group_chat_id'] = query.message.chat_id
        report['group_message_id'] = query.message.message_id
        save_report(report_id, report) # 保存到数据库
        
        # 显示提示并提供深度链接
        await query.answer(
            "请点击下方按钮前往私聊确认",
            show_alert=True,
            url=deep_link
        )
            
    except Exception as e:
        logger.exception(f"确认报备时发生错误: {e}")
        await query.answer("处理确认请求时发生错误", show_alert=True)

# REPORTS_FILE = 'reports.json'  # 存储报备信息的文件 - 移除旧的JSON文件

# def load_reports():
#     """从文件加载报备信息"""
#     try:
#         with open(REPORTS_FILE, 'r', encoding='utf-8') as f:
#             return json.load(f)
#     except (FileNotFoundError, json.JSONDecodeError):
#         return {}  # 如果文件不存在或格式错误，返回空字典

# def save_reports():
#     """将报备信息保存到文件"""
#     with open(REPORTS_FILE, 'w', encoding='utf-8') as f:
#         json.dump(reports, f, ensure_ascii=False, indent=4)
#         logger.debug(f"报备信息已保存到 {REPORTS_FILE}: {reports}")  # 添加调试日志

# REPORT_IDS_FILE = 'report_ids.json'  # 存储 report_id 的文件 - 移除旧的JSON文件

# def load_report_ids():
#     """从文件加载 report_id"""
#     try:
#         with open(REPORT_IDS_FILE, 'r', encoding='utf-8') as f:
#             return json.load(f)
#     except (FileNotFoundError, json.JSONDecodeError):
#         return []  # 如果文件不存在或格式错误，返回空列表

# def save_report_ids(report_ids):
#     """将 report_id 保存到文件"""
#     with open(REPORT_IDS_FILE, 'w', encoding='utf-8') as f:
#         json.dump(report_ids, f, ensure_ascii=False, indent=4)

async def handle_group_report_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理群组中的公群报备命令"""
    try:
        # 获取群组和用户信息
        chat = update.effective_chat
        user = update.effective_user
        message = update.message
        
        # 检查群组是否已激活
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("SELECT `is_active` FROM `groups` WHERE `group_id` = %s", (chat.id,))
            group = cursor.fetchone()
            is_active = group and group['is_active'] == 1
        finally:
            conn.close()
        
        if is_active:
            # 如果群组已激活，发送带有按钮的消息
            keyboard = [[InlineKeyboardButton("公群报备(仅管理员可用)", url=f"https://t.me/{context.bot.username}")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            # 回复原始消息
            await message.reply_text(
                text="交易报备，请管理员点击此按钮进行",
                reply_markup=reply_markup
            )
        else:
            # 如果群组未激活，提示用户
            await message.reply_text("此群组尚未激活，请联系管理员激活。")
    except Exception as e:
        logger.exception(f"处理群组公群报备命令时发生错误: {e}")

async def download_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理统计表格下载按钮"""
    query = update.callback_query
    await query.answer("统计表格下载功能正在开发中")
    # 这里可以添加生成和发送统计表格的逻辑

async def handle_rating(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理双方互评按钮"""
    try:
        query = update.callback_query
        report_id = query.data.split('_')[1]
        
        # 获取机器人用户名
        bot_info = await context.bot.get_me()
        bot_username = bot_info.username
        
        # 创建正确格式的深度链接
        deep_link = f"https://t.me/{bot_username}?start=rate_{report_id}"
        
        # 显示提示并提供深度链接
        try:
            await query.answer(
                "点击确定跳转到机器人进行互评",
                show_alert=True,
                url=deep_link
            )
        except telegram.error.BadRequest as e:
            if "Query is too old" in str(e):
                logger.warning("回调查询已过期，无法回应")
            elif "Url_invalid" in str(e):
                logger.error(f"URL格式无效: {deep_link}")
                # 尝试不带URL参数回答
                await query.answer("请点击确定后手动前往机器人进行互评", show_alert=True)
            else:
                logger.error(f"回答回调查询时发生错误: {e}")
    except Exception as e:
        logger.exception(f"处理双方互评按钮时发生错误: {e}")

# 添加群组管理命令
async def cmd_add_group(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """添加群组到数据库"""
    user = update.effective_user
    
    # 检查是否是超级管理员
    if user.id not in SUPER_ADMIN_IDS:
        await update.message.reply_text("只有超级管理员可以添加群组")
        return
    
    # 检查参数
    if len(context.args) < 1:
        await update.message.reply_text(
            "使用方法: /add_group <群组信息>\n\n"
            "格式示例：\n"
            "公群H小组9555 -供押46666U 刘老根卡商公群 （月结）\n\n"
            "包含以下信息：\n"
            "组名：公群H小组9555\n"
            "供押：46666U\n"
            "名称：刘老根卡商公群\n"
            "结算：月结"
        )
        return
    
    # 解析群组信息
    group_info = ' '.join(context.args)
    
    try:
        # 尝试解析格式
        # 提取组名
        group_code_match = re.search(r'公群(\w+小组\d+)', group_info)
        group_code = group_code_match.group(1) if group_code_match else ""
        
        # 提取供押金额
        deposit_match = re.search(r'供押(\d+)U', group_info)
        deposit_amount = deposit_match.group(1) + "U" if deposit_match else ""
        
        # 提取名称（在供押和结算之间的部分）
        name_match = re.search(r'U\s+(.+?)\s+（', group_info)
        group_full_name = name_match.group(1) if name_match else ""
        
        # 提取结算方式
        settlement_match = re.search(r'（(.+?)）', group_info)
        settlement_type = settlement_match.group(1) if settlement_match else ""
        
        # 生成群组名称
        group_name = f"公群{group_code} -供押{deposit_amount} {group_full_name} （{settlement_type}）"
        
        # 要求用户将机器人添加到群组
        await update.message.reply_text(
            f"已解析群组信息：\n\n"
            f"组名：公群{group_code}\n"
            f"供押：{deposit_amount}\n"
            f"名称：{group_full_name}\n"
            f"结算：{settlement_type}\n\n"
            f"请将机器人添加到群组，然后在该群组中发送 /register_group 命令来完成注册。"
        )
        
        # 将群组信息存储在用户数据中，以便在注册时使用
        if not context.user_data:
            context.user_data = {}
        context.user_data['pending_group'] = {
            'group_name': group_name,
            'group_code': group_code,
            'deposit_amount': deposit_amount,
            'group_full_name': group_full_name,
            'settlement_type': settlement_type
        }
    except Exception as e:
        logger.exception(f"解析群组信息时发生错误: {e}")
        await update.message.reply_text(
            "解析群组信息失败，请确保格式正确。\n\n"
            "格式示例：\n"
            "公群H小组9555 -供押46666U 刘老根卡商公群 （月结）"
        )

async def cmd_register_group(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """注册当前群组"""
    user = update.effective_user
    chat = update.effective_chat
    
    # 检查是否在群组中
    if chat.type not in ['group', 'supergroup']:
        await update.message.reply_text("此命令只能在群组中使用")
        return
    
    # 检查是否是超级管理员
    if user.id not in SUPER_ADMIN_IDS:
        await update.message.reply_text("只有超级管理员可以注册群组")
        return
    
    # 检查是否有待注册的群组信息
    pending_group = context.user_data.get('pending_group') if context.user_data else None
    
    if pending_group:
        # 使用之前解析的群组信息
        group_name = pending_group['group_name']
        group_code = pending_group['group_code']
        deposit_amount = pending_group['deposit_amount']
        group_full_name = pending_group['group_full_name']
        settlement_type = pending_group['settlement_type']
    
    # 添加群组到数据库
        add_group(chat.id, group_name, group_code, deposit_amount, group_full_name, settlement_type)
        
        # 清除待注册的群组信息
        context.user_data.pop('pending_group', None)
    else:
        # 如果没有待注册的群组信息，使用默认名称
        group_name = chat.title
        add_group(chat.id, group_name)
    
    # 激活群组
    activate_group(chat.id)
    
    await update.message.reply_text(f"群组 '{group_name}' 已成功注册并激活")

async def cmd_list_groups(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """列出所有群组"""
    user = update.effective_user
    
    # 检查是否是超级管理员
    if user.id not in SUPER_ADMIN_IDS:
        await update.message.reply_text("只有超级管理员可以查看群组列表")
        return
    
    # 获取所有激活的群组
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT `group_id`, `group_name`, `group_code`, `deposit_amount`, `group_full_name`, `settlement_type`, `is_active` FROM `groups`")
        groups = cursor.fetchall()
    finally:
        conn.close()
    
    if not groups:
        await update.message.reply_text("还没有注册任何群组")
        return
    
    # 格式化群组列表
    group_list = ""
    for i, group in enumerate(groups):
        status = '✅ 已激活' if group['is_active'] else '❌ 未激活'
        group_info = f"{i+1}. {group['group_name']} (ID: {group['group_id']}) {status}\n"
        
        # 添加详细信息
        if group['group_code'] or group['deposit_amount'] or group['group_full_name'] or group['settlement_type']:
            group_info += f"   组名：公群{group['group_code']}\n"
            group_info += f"   供押：{group['deposit_amount']}\n"
            group_info += f"   名称：{group['group_full_name']}\n"
            group_info += f"   结算：{group['settlement_type']}\n"
        
        group_list += group_info + "\n"
    
    await update.message.reply_text(f"群组列表:\n{group_list}")

async def cmd_activate_group(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """激活群组"""
    user = update.effective_user
    
    # 检查是否是超级管理员
    if user.id not in SUPER_ADMIN_IDS:
        await update.message.reply_text("只有超级管理员可以激活群组")
        return
    
    # 检查参数
    if len(context.args) != 1:
        await update.message.reply_text("使用方法: /activate_group <群组ID>")
        return
    
    try:
        group_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("群组ID必须是数字")
        return
    
    # 激活群组
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT `group_name` FROM `groups` WHERE `group_id` = %s", (group_id,))
        group = cursor.fetchone()
    finally:
        conn.close()
    
    if not group:
        await update.message.reply_text("找不到指定的群组")
        return
    
    activate_group(group_id)
    
    await update.message.reply_text(f"群组 '{group['group_name']}' 已激活")

async def cmd_deactivate_group(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """停用群组"""
    user = update.effective_user
    
    # 检查是否是超级管理员
    if user.id not in SUPER_ADMIN_IDS:
        await update.message.reply_text("只有超级管理员可以停用群组")
        return
    
    # 检查参数
    if len(context.args) != 1:
        await update.message.reply_text("使用方法: /deactivate_group <群组ID>")
        return
    
    try:
        group_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("群组ID必须是数字")
        return
    
    # 停用群组
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT `group_name` FROM `groups` WHERE `group_id` = %s", (group_id,))
        group = cursor.fetchone()
    finally:
        conn.close()
    
    if not group:
        await update.message.reply_text("找不到指定的群组")
        return
    
    deactivate_group(group_id)
    
    await update.message.reply_text(f"群组 '{group['group_name']}' 已停用")

async def cmd_add_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """添加管理员"""
    user = update.effective_user
    
    # 检查是否是超级管理员
    if user.id not in SUPER_ADMIN_IDS:
        await update.message.reply_text("只有超级管理员可以添加管理员")
        return
    
    # 检查参数
    if len(context.args) < 2:
        await update.message.reply_text("使用方法: /add_admin <用户ID> <群组ID>")
        return
    
    try:
        user_id = int(context.args[0])
        group_id = int(context.args[1])
    except ValueError:
        await update.message.reply_text("用户ID和群组ID必须是数字")
        return
    
    # 检查群组是否存在
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT `group_name` FROM `groups` WHERE `group_id` = %s", (group_id,))
        group = cursor.fetchone()
    finally:
        conn.close()
    
    if not group:
        await update.message.reply_text("找不到指定的群组")
        return
    
    # 添加管理员
    result = add_admin(user_id, group_id, "", user.id)
    
    if result:
        await update.message.reply_text(f"已将用户 {user_id} 添加为群组 '{group['group_name']}' 的管理员")
    else:
        await update.message.reply_text(f"用户 {user_id} 已经是群组 '{group['group_name']}' 的管理员")

async def cmd_remove_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """移除管理员"""
    user = update.effective_user
    
    # 检查是否是超级管理员
    if user.id not in SUPER_ADMIN_IDS:
        await update.message.reply_text("只有超级管理员可以移除管理员")
        return
    
    # 检查参数
    if len(context.args) < 2:
        await update.message.reply_text("使用方法: /remove_admin <用户ID> <群组ID>")
        return
    
    try:
        user_id = int(context.args[0])
        group_id = int(context.args[1])
    except ValueError:
        await update.message.reply_text("用户ID和群组ID必须是数字")
        return
    
    # 检查群组是否存在
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT `group_name` FROM `groups` WHERE `group_id` = %s", (group_id,))
        group = cursor.fetchone()
    finally:
        conn.close()
    
    if not group:
        await update.message.reply_text("找不到指定的群组")
        return
    
    # 移除管理员
    remove_admin(user_id, group_id)
    
    await update.message.reply_text(f"已将用户 {user_id} 从群组 '{group['group_name']}' 的管理员中移除")

async def cmd_list_admins(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """列出群组的所有管理员"""
    user = update.effective_user
    
    # 检查是否是超级管理员
    if user.id not in SUPER_ADMIN_IDS:
        await update.message.reply_text("只有超级管理员可以查看管理员列表")
        return
    
    # 检查参数
    if len(context.args) != 1:
        await update.message.reply_text("使用方法: /list_admins <群组ID>")
        return
    
    try:
        group_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("群组ID必须是数字")
        return
    
    # 检查群组是否存在
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT `group_name` FROM `groups` WHERE `group_id` = %s", (group_id,))
        group = cursor.fetchone()
    finally:
        conn.close()
    
    if not group:
        await update.message.reply_text("找不到指定的群组")
        return
    
    # 获取管理员列表
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            SELECT a.user_id, a.username, a.created_at 
            FROM admins a 
            WHERE a.group_id = %s
        """, (group_id,))
        admins = cursor.fetchall()
    finally:
        conn.close()
    
    if not admins:
        await update.message.reply_text(f"群组 '{group['group_name']}' 没有管理员")
        return
    
    # 格式化管理员列表
    admin_list = "\n".join([
        f"{i+1}. ID: {admin['user_id']}, 用户名: {admin['username'] or '未知'}, 添加时间: {admin['created_at']}"
        for i, admin in enumerate(admins)
    ])
    
    await update.message.reply_text(f"群组 '{group['group_name']}' 的管理员列表:\n{admin_list}\n\n超级管理员: {', '.join(map(str, SUPER_ADMIN_IDS))}")

async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """显示帮助信息"""
    user = update.effective_user
    is_user_admin = is_admin(user.id)
    
    help_text = "📋 命令列表：\n\n"
    
    # 基本命令
    help_text += "🔹 基本命令：\n"
    help_text += "/start - 启动机器人\n"
    help_text += "/help - 显示此帮助信息\n"
    help_text += "/my_reports - 查看我的订单\n\n"
    
    # 管理员命令
    if is_user_admin:
        help_text += "🔹 管理员命令：\n"
        help_text += "公群报备 - 在群组中激活机器人\n\n"
    
    await update.message.reply_text(help_text)

async def cmd_config_db(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """配置MySQL数据库连接"""
    user = update.effective_user
    
    # 检查是否是超级管理员
    if user.id not in SUPER_ADMIN_IDS:
        await update.message.reply_text("只有超级管理员可以配置数据库")
        return
    
    # 检查参数
    if len(context.args) < 4:
        await update.message.reply_text("使用方法: /config_db <host> <user> <password> <database>")
        return
    
    host = context.args[0]
    db_user = context.args[1]
    password = context.args[2]
    database = context.args[3]
    
    # 更新数据库配置
    if config.update_db_config(host, db_user, password, database):
        # 测试连接
        try:
            conn = get_db_connection()
            conn.close()
            await update.message.reply_text(f"数据库连接配置成功！\n主机: {host}\n用户: {db_user}\n数据库: {database}")
            
            # 初始化数据库
            init_db()
            await update.message.reply_text("数据库表已创建/更新")
        except Exception as e:
            await update.message.reply_text(f"数据库连接失败: {str(e)}")
            # 恢复默认配置
            config.update_db_config(
                'localhost', 'root', 'password', 'telegram_bot'
            )
    else:
        await update.message.reply_text("保存配置失败，请检查文件权限")

def main():
    """主函数"""
    # 在线程中运行时，需要创建新的事件循环
    try:
        loop = asyncio.get_event_loop()
        if loop.is_closed():
            raise RuntimeError("Event loop is closed")
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    
    # 初始化数据库
    try:
        init_db()
        logger.info("数据库初始化成功")
    except Exception as e:
        logger.error(f"数据库初始化失败: {str(e)}")
        logger.info("请使用Web管理后台配置数据库")

    # 创建Telegram机器人应用
    application = Application.builder().token(BOT_TOKEN).build()
    
    # 添加处理器
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", cmd_help))
    
    # 先处理菜单按钮点击
    application.add_handler(MessageHandler(
        filters.TEXT & filters.ChatType.PRIVATE & filters.Regex('^(公群报备|本群查询|我的报备\\(客人\\))$'),
        handle_menu
    ))
    
    # 处理群组中的"公群报备"命令
    application.add_handler(MessageHandler(
        filters.TEXT & ~filters.ChatType.PRIVATE & filters.Regex('^公群报备$'),
        handle_group_report_command
    ))
    
    # 再处理报备信息输入
    application.add_handler(MessageHandler(
        filters.TEXT & filters.ChatType.PRIVATE & ~filters.COMMAND,
        handle_report_input
    ))
    
    # 其他处理器
    application.add_handler(CallbackQueryHandler(send_to_group, pattern="^send_"))
    application.add_handler(CallbackQueryHandler(cancel_send, pattern="^cancel_send_"))
    application.add_handler(CallbackQueryHandler(confirm_report, pattern="^confirm_"))
    application.add_handler(CallbackQueryHandler(cancel_report, pattern="^cancel_"))
    application.add_handler(CallbackQueryHandler(cancel_order, pattern="^order_cancel_"))
    application.add_handler(ChatMemberHandler(check_group_permissions, ChatMemberStatus.MEMBER))
    application.add_handler(MessageHandler(filters.VIDEO, handle_video))
    application.add_handler(CallbackQueryHandler(staff_confirm, pattern="^staff_confirm_"))
    application.add_handler(CallbackQueryHandler(complete_order, pattern="^complete_"))
    
    # 添加命令处理器
    application.add_handler(CommandHandler("my_reports", my_orders))  # 改为调用my_orders
    
    # 添加订单筛选按钮的处理器
    application.add_handler(CallbackQueryHandler(handle_order_filter, pattern="^filter_all$|^filter_confirmed$|^filter_completed$|^filter_cancelled$"))
    
    # 添加群组查询按钮的处理器
    application.add_handler(CallbackQueryHandler(handle_group_query, pattern="^query_group_"))
    
    # 添加群组筛选按钮的处理器
    application.add_handler(CallbackQueryHandler(handle_group_filter, pattern="^filter_group_"))
    
    # 添加统计表格下载按钮的处理器
    application.add_handler(CallbackQueryHandler(download_stats, pattern="^download_stats"))
    
    # 添加群组统计表格下载按钮的处理器
    application.add_handler(CallbackQueryHandler(download_group_stats, pattern="^download_group_stats"))
    
    # 添加双方互评按钮的处理器
    application.add_handler(CallbackQueryHandler(handle_rating, pattern="^rate_"))
    
    # 注意：Web管理后台已在main.py中统一启动，不在此处启动
    logger.info("报备机器人初始化完成")
    
    # 启动Telegram机器人（禁用信号处理以支持在线程中运行）
    application.run_polling(stop_signals=None)

if __name__ == "__main__":
    main() 
