from telegram import Update, ChatPermissions
from telegram.ext import CallbackContext
from telegram.error import BadRequest
import utils
import config
import re
import logging
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
import json
import os
from datetime import datetime

# 设置日志 - 强制输出到标准输出
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    force=True,
    handlers=[
        logging.StreamHandler()  # 强制输出到标准输出
    ]
)
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# 检查群组授权
def check_group_authorization(chat_id):
    """检查群组是否有使用授权"""
    try:
        import requests
        response = requests.get(f'http://localhost:3002/api/check_auth/{chat_id}', timeout=5)
        if response.status_code == 200:
            return response.json().get('authorized', False)
    except Exception as e:
        logger.error(f"检查群组授权失败: {e}")
        # 如果无法连接到Web后台，默认拒绝使用（安全第一）
        return False
    return False

def check_admin_authorization(chat_id, user_id):
    """检查管理员是否有使用授权"""
    try:
        import requests
        response = requests.get(f'http://localhost:3002/api/check_admin_auth/{chat_id}/{user_id}', timeout=5)
        if response.status_code == 200:
            return response.json().get('authorized', False)
    except Exception as e:
        logger.error(f"检查管理员授权失败: {e}")
        # 如果无法连接到Web后台，默认拒绝使用（安全第一）
        return False
    return False

def verification_timeout(context):
    """验证超时处理：删除验证消息，保持用户禁言状态"""
    job = context.job
    chat_id = job.context['chat_id']
    user_id = job.context['user_id']
    message_id = job.context['message_id']
    
    # 检查用户是否还在待验证列表中
    if chat_id in pending_verification and user_id in pending_verification[chat_id]:
        try:
            # 删除验证消息
            try:
                context.bot.delete_message(chat_id=chat_id, message_id=message_id)
                logger.info(f"已删除群 {chat_id} 中用户 {user_id} 的验证消息（超时）")
            except Exception as e:
                logger.error(f"删除验证消息失败: {e}")
            
            # 不踢出用户，保持禁言状态
            logger.info(f"用户 {user_id} 在群组 {chat_id} 验证超时，保持禁言状态")
            
            # 从待验证列表中移除
            del pending_verification[chat_id][user_id]
            if not pending_verification[chat_id]:
                del pending_verification[chat_id]
                
        except Exception as e:
            logger.error(f"处理验证超时失败: {e}")
    else:
        logger.info(f"用户 {user_id} 在群组 {chat_id} 已完成验证或已被移除")

# 存储用户信息的字典
user_info = {}
# 存储群组管理员的字典
group_admins = {}
# 存储待验证用户的字典
pending_verification = {}
# 存储每个群组的最后一条欢迎消息ID
last_welcome_messages = {}

def is_group_admin(chat_id, user_id):
    """检查用户是否为群组管理员"""
    if chat_id not in group_admins:
        return False
    return user_id in group_admins[chat_id]

def update_group_admins(bot, chat_id):
    """更新群组管理员列表"""
    try:
        admins = bot.get_chat_administrators(chat_id)
        group_admins[chat_id] = [admin.user.id for admin in admins]
        return True
    except Exception as e:
        logger.error(f"更新管理员列表失败: {e}")
        return False

def start(update, context):
    """处理/start命令"""
    logger.info(f"收到 /start 命令，来自: {update.effective_user.id}")
    chat_id = update.effective_chat.id
    chat_type = update.effective_chat.type
    logger.info(f"聊天类型: {chat_type}, 聊天ID: {chat_id}")
    
    if chat_type == 'private':
        # 私聊消息
        try:
            # 从配置文件获取启动消息和按钮
            from telegram import InlineKeyboardMarkup, InlineKeyboardButton
            import config
            
            # 创建按钮
            buttons = []
            row = []
            for i, button in enumerate(config.START_BUTTONS):
                row.append(InlineKeyboardButton(text=button["text"], url=button["url"]))
                
                # 每行放两个按钮
                if (i + 1) % 2 == 0 or i == len(config.START_BUTTONS) - 1:
                    buttons.append(row)
                    row = []
            
            reply_markup = InlineKeyboardMarkup(buttons)
            
            # 发送消息
            template = utils.get_message_template('start_message')
            
            # 创建按钮
            keyboard = []
            if template['buttons']:
                buttons_row = []
                for button in template['buttons']:
                    buttons_row.append(InlineKeyboardButton(button["text"], url=button["url"]))
                keyboard.append(buttons_row)
            reply_markup = InlineKeyboardMarkup(keyboard) if keyboard else None
            
            context.bot.send_message(
                chat_id=chat_id,
                text=template['content'],
                parse_mode="HTML",
                reply_markup=reply_markup,
                disable_web_page_preview=True
            )
        except Exception as e:
            logging.error(f"发送启动消息失败: {e}")
            # 发送默认消息
            context.bot.send_message(
                chat_id=chat_id,
                text="欢迎使用机器人！"
            )
    else:
        # 群组消息
        context.bot.send_message(
            chat_id=chat_id,
            text="机器人已启动，可以使用了。"
        )

def strict_mode_command(update: Update, context: CallbackContext):
    """处理严格模式命令"""
    chat_id = update.effective_chat.id
    user_id = update.effective_user.id
    
    # 检查群组授权
    if not check_group_authorization(chat_id):
        context.bot.send_message(
            chat_id=chat_id,
            text="⚠️ 此群组未获得使用授权，请联系管理员开通权限。"
        )
        # 尝试退出未授权群组
        try:
            context.bot.leave_chat(chat_id)
            logger.info(f"检测到未授权群组 {chat_id}，机器人已退出")
        except Exception as e:
            logger.error(f"退出未授权群组失败: {e}")
        return
    
    # 更新管理员列表
    update_group_admins(context.bot, chat_id)
    
    # 检查是否为管理员
    if not is_group_admin(chat_id, user_id) and not utils.is_admin(user_id):
        context.bot.send_message(chat_id=chat_id, text="只有管理员可以使用此命令")
        return
    
    # 获取或初始化群组设置
    settings = utils.get_settings(chat_id)
    
    # 切换严格模式
    strict_mode = not settings.get("strict_mode", False)
    utils.update_setting(chat_id, "strict_mode", strict_mode)
    
    # 发送设置面板
    keyboard = utils.get_strict_mode_keyboard(chat_id)
    
    # 发送新消息，不回复原消息
    context.bot.send_message(
        chat_id=chat_id,
        text="严格模式 已启用\n\n"
             "使用说明:\n"
             "所有限制适用管理员除外\n"
             "转发限制: 限制所有转发信息\n"
             "信息限制: 限制字符超过50个和超过三行的字符\n"
             "禁止链接: 限制群发送链接 包括信息包含链接\n"
             "防骚扰强: 启用防骚扰强 将会直接将骚扰踢出群聊\n"
             "广告限制: 基础的广告限制公告容易误杀 慎用\n"
             "欢迎语: 欢迎所有成员\n"
             "仅欢迎重要人士: 仅仅发送重要人士的欢迎信息例如VIP成员 新币员工\n"
             "踢出退群: (默认开启)",
        reply_markup=keyboard
    )

def handle_callback_query(update: Update, context: CallbackContext):
    """处理回调查询"""
    logger.info(f"收到回调查询事件")
    query = update.callback_query
    chat_id = query.message.chat_id
    user_id = query.from_user.id
    logger.info(f"回调查询 - 群组ID: {chat_id}, 用户ID: {user_id}, 数据: {query.data}")
    
    # 处理验证按钮
    if query.data.startswith("verify_"):
        handle_verification_callback(update, context)
        return
    
    # 处理解除禁言按钮（仅显示提示，不执行实际操作）
    if query.data == "unmute_user":
        query.answer("您可以发言了", show_alert=True)
        return
    
    # 检查群组是否已授权
    if not check_group_authorization(chat_id):
        query.answer("此群组未获得使用授权，请联系管理员开通权限。")
        return
    
    # 检查是否为管理员
    if not is_group_admin(chat_id, user_id) and not utils.is_admin(user_id):
        query.answer("只有管理员可以更改设置")
        return
    
    # 获取回调数据
    callback_data = query.data
    
    # 处理不同的设置切换
    if callback_data.startswith("toggle_"):
        setting_name = callback_data[7:]  # 移除 "toggle_" 前缀
        settings = utils.get_settings(chat_id)
        current_value = settings.get(setting_name, False)
        utils.update_setting(chat_id, setting_name, not current_value)
        
        # 更新键盘
        keyboard = utils.get_strict_mode_keyboard(chat_id)
        try:
            query.edit_message_reply_markup(reply_markup=keyboard)
            query.answer(f"已{'启用' if not current_value else '禁用'} {setting_name}")
        except BadRequest as e:
            logger.error(f"更新键盘失败: {e}")
            query.answer("无法更新设置，请稍后再试")

def handle_new_member(update: Update, context: CallbackContext):
    """处理新成员加入"""
    chat_id = update.effective_chat.id
    
    # 检查是否是机器人自己被拉入群组
    for new_member in update.message.new_chat_members:
        if new_member.id == context.bot.id:
            # 检查群组是否已授权
            if not check_group_authorization(chat_id):
                logger.info(f"机器人被拉入未授权群组 {chat_id}，正在退出...")
                try:
                    # 发送提示消息
                    context.bot.send_message(
                        chat_id=chat_id,
                        text="此群组未获得使用授权，机器人将自动退出。请联系管理员开通权限。"
                    )
                    # 退出群组
                    context.bot.leave_chat(chat_id)
                    return
                except Exception as e:
                    logger.error(f"退出未授权群组失败: {e}")
            else:
                logger.info(f"机器人被拉入已授权群组 {chat_id}")
    
    # 检查群组是否已授权
    if not check_group_authorization(chat_id):
        return
    
    settings = utils.get_settings(chat_id)
    
    logger.info(f"新成员加入群聊 {chat_id}, 进群验证设置: {settings.get('verification', False)}")
    
    verification_enabled = settings.get("verification", False)
    welcome_enabled = settings.get("welcome_message", False)
    
    if not verification_enabled and not welcome_enabled:
        logger.info(f"群组 {chat_id} 未启用进群验证和欢迎语，跳过")
        return
    
    # 处理所有新成员
    for new_member in update.message.new_chat_members:
        # 跳过机器人自己
        if new_member.id == context.bot.id:
            continue
        
        user_id = new_member.id
        logger.info(f"处理新成员: {user_id}, 验证启用: {verification_enabled}, 欢迎语启用: {welcome_enabled}")
        
        # 如果启用了进群验证
        if verification_enabled:
            # 获取群组名称
            try:
                chat = context.bot.get_chat(chat_id)
                group_name = chat.title
            except Exception as e:
                logger.error(f"获取群组名称失败: {e}")
                group_name = "本群"
            
            # 获取用户信息
            user_name = new_member.first_name
            if new_member.last_name:
                user_name += f" {new_member.last_name}"
            user_mention = f"@{new_member.username}" if new_member.username else user_name
            
            # 自动限制新成员
            try:
                context.bot.restrict_chat_member(
                    chat_id=chat_id,
                    user_id=user_id,
                    permissions=ChatPermissions(
                        can_send_messages=False,
                        can_send_media_messages=False,
                        can_send_polls=False,
                        can_send_other_messages=False,
                        can_add_web_page_previews=False,
                        can_change_info=False,
                        can_invite_users=True,
                        can_pin_messages=False
                    )
                )
                logger.info(f"已限制用户 {user_id} 在群组 {chat_id} 的发言、媒体和表情权限")
            except Exception as e:
                logger.error(f"限制用户失败: {e}")
            
            # 尝试删除上一条欢迎消息
            try:
                if chat_id in last_welcome_messages:
                    last_msg_id = last_welcome_messages[chat_id]
                    try:
                        context.bot.delete_message(chat_id=chat_id, message_id=last_msg_id)
                        logger.info(f"已删除群 {chat_id} 的上一条欢迎消息 {last_msg_id}")
                    except Exception as e:
                        logger.error(f"删除上一条欢迎消息失败: {e}")
            except Exception as e:
                logger.error(f"处理上一条欢迎消息时出错: {e}")
            
            # 构建验证消息文本
            template = utils.get_message_template('verification_message')
            welcome_text = template['content'].format(
                user_name=user_name,
                group_name=group_name
            )
            
            # 创建按钮键盘
            keyboard = []
            if template['buttons']:
                template_buttons = template['buttons']
                all_buttons = []
                for btn in template_buttons:
                    all_buttons.append(InlineKeyboardButton(btn["text"], url=btn["url"]))
                all_buttons.append(InlineKeyboardButton("解除禁言", callback_data=f"verify_{user_id}"))
                for i in range(0, len(all_buttons), 2):
                    row = []
                    for j in range(i, min(i+2, len(all_buttons))):
                        row.append(all_buttons[j])
                    keyboard.append(row)
            else:
                keyboard.append([InlineKeyboardButton("解除禁言", callback_data=f"verify_{user_id}")])
            
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            # 添加到待验证列表
            if chat_id not in pending_verification:
                pending_verification[chat_id] = {}
            
            # 发送验证消息
            welcome_msg = context.bot.send_message(
                chat_id=chat_id,
                text=welcome_text,
                parse_mode="HTML",
                disable_web_page_preview=True,
                reply_markup=reply_markup
            )
            
            # 创建20秒后超时踢出的定时任务
            job = context.job_queue.run_once(
                verification_timeout,
                20,
                context={
                    'chat_id': chat_id,
                    'user_id': user_id,
                    'message_id': welcome_msg.message_id
                },
                name=f"timeout_{chat_id}_{user_id}"
            )
            
            # 保存验证信息
            pending_verification[chat_id][user_id] = {
                'username': user_name,
                'join_time': datetime.now(),
                'message_id': welcome_msg.message_id,
                'delete_job': job
            }
            
            # 保存这条消息的ID
            last_welcome_messages[chat_id] = welcome_msg.message_id
            
            # 保存最后一条欢迎消息ID到文件
            try:
                save_welcome_message_ids()
            except Exception as e:
                logger.error(f"保存欢迎消息ID失败: {e}")
            
            logger.info(f"已发送进群验证消息给用户 {user_id} 在群组 {chat_id}")
            break
        
        # 如果没启用验证但启用了欢迎语
        elif welcome_enabled:
            # 获取群组名称
            try:
                chat = context.bot.get_chat(chat_id)
                group_name = chat.title
            except Exception as e:
                logger.error(f"获取群组名称失败: {e}")
                group_name = "本群"
            
            # 尝试删除上一条欢迎消息
            try:
                if chat_id in last_welcome_messages:
                    last_msg_id = last_welcome_messages[chat_id]
                    try:
                        context.bot.delete_message(chat_id=chat_id, message_id=last_msg_id)
                        logger.info(f"已删除群 {chat_id} 的上一条欢迎消息 {last_msg_id}")
                    except Exception as e:
                        logger.error(f"删除上一条欢迎消息失败: {e}")
            except Exception as e:
                logger.error(f"处理上一条欢迎消息时出错: {e}")
        
        for new_member in update.message.new_chat_members:
            # 跳过机器人自己
            if new_member.id == context.bot.id:
                continue
                
            # 构建欢迎消息
            user_name = new_member.first_name
            if new_member.last_name:
                user_name += f" {new_member.last_name}"
            
            # 使用数据库中的欢迎消息模板
            template = utils.get_message_template('welcome_message')
            welcome_text = template['content'].format(
                user_name=user_name,
                group_name=group_name
            )
            
            # 创建底部按钮
            keyboard = []
            if template['buttons']:
                buttons_row = []
                for button in template['buttons']:
                    buttons_row.append(
                        InlineKeyboardButton(button["text"], url=button["url"])
                    )
                keyboard.append(buttons_row)
            
            reply_markup = InlineKeyboardMarkup(keyboard) if keyboard else None
            
            # 发送欢迎消息
            welcome_msg = context.bot.send_message(
                chat_id=chat_id,
                text=welcome_text,
                parse_mode="HTML",
                disable_web_page_preview=True,
                reply_markup=reply_markup
            )
            
            # 保存这条消息的ID
            last_welcome_messages[chat_id] = welcome_msg.message_id
            
            # 保存最后一条欢迎消息ID到文件
            try:
                save_welcome_message_ids()
            except Exception as e:
                logger.error(f"保存欢迎消息ID失败: {e}")
            
            # 只处理第一个新成员
            break

def handle_verification_callback(update: Update, context: CallbackContext):
    """处理验证按钮回调"""
    query = update.callback_query
    chat_id = query.message.chat_id
    user_id = query.from_user.id
    
    # 检查群组是否已授权
    if not check_group_authorization(chat_id):
        query.answer("此群组未获得使用授权，请联系管理员开通权限。")
        return
    
    # 解析回调数据
    if query.data.startswith("verify_"):
        target_user_id = int(query.data.split("_")[1])
        
        # 检查是否是目标用户本人点击
        if user_id != target_user_id:
            query.answer("只有被验证的用户才能点击此按钮", show_alert=True)
            return
        
        # 恢复用户权限 - 恢复所有普通成员应有的权限
        try:
            context.bot.restrict_chat_member(
                chat_id,
                user_id,
                permissions=ChatPermissions(
                    can_send_messages=True,
                    can_send_media_messages=True,
                    can_send_polls=True,
                    can_send_other_messages=True,
                    can_add_web_page_previews=True,
                    can_change_info=False,  # 普通成员不能修改群信息
                    can_invite_users=True,
                    can_pin_messages=False  # 普通成员不能置顶消息
                )
            )
            logger.info(f"已完全解除用户 {user_id} 在群组 {chat_id} 的限制，恢复正常成员权限")
            
            # 从待验证列表中移除
            if chat_id in pending_verification and user_id in pending_verification[chat_id]:
                # 取消定时删除任务
                user_data = pending_verification[chat_id][user_id]
                if "delete_job" in user_data:
                    try:
                        user_data["delete_job"].schedule_removal()
                    except Exception as e:
                        logger.info(f"取消定时任务失败（可能已执行）: {e}")
                
                del pending_verification[chat_id][user_id]
            
            # 删除验证消息
            try:
                query.message.delete()
            except Exception as e:
                logger.error(f"删除验证消息失败: {e}")
            
            query.answer("验证成功！您现在可以正常发言了", show_alert=True)
            
            # 验证成功后，检查是否需要发送欢迎语
            settings = utils.get_settings(chat_id)
            if settings.get("welcome_message", False):
                try:
                    # 获取群组名称
                    try:
                        chat = context.bot.get_chat(chat_id)
                        group_name = chat.title
                    except Exception as e:
                        logger.error(f"获取群组名称失败: {e}")
                        group_name = "本群"
                    
                    # 获取用户信息
                    try:
                        user = context.bot.get_chat_member(chat_id, user_id).user
                        user_name = user.first_name
                        if user.last_name:
                            user_name += f" {user.last_name}"
                    except Exception as e:
                        logger.error(f"获取用户信息失败: {e}")
                        user_name = "新成员"
                    
                    # 使用数据库中的欢迎消息模板
                    template = utils.get_message_template('welcome_message')
                    welcome_text = template['content'].format(
                        user_name=user_name,
                        group_name=group_name
                    )
                    
                    # 创建底部按钮
                    keyboard = []
                    if template['buttons']:
                        buttons_row = []
                        for button in template['buttons']:
                            buttons_row.append(
                                InlineKeyboardButton(button["text"], url=button["url"])
                            )
                        keyboard.append(buttons_row)
                    
                    reply_markup = InlineKeyboardMarkup(keyboard) if keyboard else None
                    
                    # 发送欢迎消息
                    welcome_msg = context.bot.send_message(
                        chat_id=chat_id,
                        text=welcome_text,
                        parse_mode="HTML",
                        disable_web_page_preview=True,
                        reply_markup=reply_markup
                    )
                    
                    # 保存这条消息的ID
                    last_welcome_messages[chat_id] = welcome_msg.message_id
                    
                    # 保存最后一条欢迎消息ID到文件
                    try:
                        save_welcome_message_ids()
                    except Exception as e:
                        logger.error(f"保存欢迎消息ID失败: {e}")
                    
                    logger.info(f"已发送欢迎消息给用户 {user_id} 在群组 {chat_id}")
                except Exception as e:
                    logger.error(f"发送验证后欢迎消息失败: {e}")
            
        except Exception as e:
            logger.error(f"恢复用户权限失败: {e}")
            query.answer("验证失败，请联系管理员", show_alert=True)

def handle_message(update: Update, context: CallbackContext):
    """处理消息"""
    logger.info(f"收到消息事件")
    if not update.effective_message or not update.effective_chat:
        logger.info("无效的消息或聊天，跳过")
        return
        
    message = update.effective_message
    chat_id = update.effective_chat.id
    user_id = update.effective_user.id
    logger.info(f"处理消息 - 群组ID: {chat_id}, 用户ID: {user_id}, 消息类型: {update.effective_chat.type}")
    
    # 如果是私聊，则跳过
    if update.effective_chat.type == "private":
        logger.info("私聊消息，跳过处理")
        return
    
    # 检查群组是否已授权
    if not check_group_authorization(chat_id):
        # 如果是未授权群组，尝试退出
        logger.warning(f"检测到未授权群组 {chat_id}")
        try:
            context.bot.leave_chat(chat_id)
            logger.info(f"检测到未授权群组 {chat_id}，机器人已退出")
        except Exception as e:
            logger.error(f"退出未授权群组失败: {e}")
        return
    
    # 检查是否是"严格模式"文本
    if message.text == "严格模式":
        # 调用严格模式命令处理函数
        strict_mode_command(update, context)
        return
    
    # 检查是否是"上课"或"下课"命令
    if message.text in ["上课", "下课"]:
        # 检查是否为管理员
        is_admin = False
        try:
            # 更新管理员列表
            update_group_admins(context.bot, chat_id)
            is_admin = is_group_admin(chat_id, user_id) or utils.is_admin(user_id)
        except Exception as e:
            logger.error(f"检查管理员权限失败: {e}")
        
        if is_admin:
            # 调用上下课处理函数
            handle_class_command(update, context, message.text)
        else:
            # 静默忽略非管理员的上下课命令
            pass
        return
    
    # 处理地址关键词
    if handle_address_keyword(update, context, message.text):
        return
    
    # 处理特定关键词匹配
    if message.text and handle_keyword_matching(update, context):
        return
    
    # 检查是否是担保表单
    if message.text and handle_guarantee_form(update, context):
        return
    
    # 检查是否是验群关键词
    if message.text:
        # 获取该群组的验群设置
        verify_setting = get_group_verify_setting(chat_id)
        logger.info(f"检查验群关键词 - 消息: '{message.text.strip()}', 配置的关键词: '{verify_setting.get('keyword', '验群')}', 是否匹配: {message.text.strip() == verify_setting.get('keyword', '验群')}")
        
        if verify_setting and message.text.strip() == verify_setting.get('keyword', '验群'):
            # 只有当设置了回复消息时才回复
            reply_message = verify_setting.get('reply_message')
            logger.info(f"检测到验群关键词，回复消息是否配置: {bool(reply_message)}")
            if reply_message:
                # 发送验群回复，支持超链接并禁用链接预览
                reply_msg = context.bot.send_message(
                    chat_id=chat_id,
                    text=reply_message,
                    parse_mode="HTML",
                    disable_web_page_preview=True
                )
                
                # 获取自焚时间
                self_destruct_time = verify_setting.get('self_destruct_time', 100)
                
                # 计划任务：自焚消息
                context.job_queue.run_once(
                    self_destruct_messages,
                    self_destruct_time,
                    context={
                        'chat_id': chat_id,
                        'reply_message_id': reply_msg.message_id,
                        'original_message_id': message.message_id
                    }
                )
            return
    
    # 获取群组设置
    settings = utils.get_settings(chat_id)
    
    # 检查违禁词
    if check_group_authorization(chat_id):
        # 检查是否为管理员，管理员不受限制
        if not (is_group_admin(chat_id, user_id) or utils.is_admin(user_id)):
            # 获取消息文本
            text = message.text or message.caption or ""
            if text:
                # 检查违禁词
                prohibited_result = check_prohibited_words(text, context.bot, chat_id, user_id, message.message_id)
                if prohibited_result:
                    # 如果消息包含违禁词，已经处理过了，直接返回
                    return
    
    # 如果没有启用严格模式，则跳过
    if not settings.get("strict_mode", False):
        return
    
    # 检查是否为管理员，管理员不受限制
    if is_group_admin(chat_id, user_id) or utils.is_admin(user_id):
        return
    
    # 检查转发限制
    if settings.get("forward_restriction", False) and message.forward_date:
        try:
            message.delete()
            # 静默删除，不显示提示消息
            return
        except Exception as e:
            logger.error(f"删除转发消息失败: {e}")
    
    # 检查消息限制
    if settings.get("message_restriction", False):
        is_valid, reason = utils.check_message_restrictions(message)
        if not is_valid:
            try:
                message.delete()
                # 静默删除，不显示提示消息
                return
            except Exception as e:
                logger.error(f"删除违规消息失败: {e}")
    
    # 检查链接限制
    if settings.get("link_restriction", False):
        text = message.text or message.caption or ""
        if utils.contains_link(text):
            try:
                message.delete()
                # 静默删除，不显示提示消息
                return
            except Exception as e:
                logger.error(f"删除含链接消息失败: {e}")
    
    # 检查防骚扰强
    if settings.get("anti_spam", False):
        # 防骚扰强功能已移除 - 按钮保留但不执行任何操作
        pass
    
    # 广告限制功能已移除
    
    # 检查禁止外文
    if settings.get("external_text", False):
        text = message.text or message.caption or ""
        # 检查是否包含非中文字符（简单实现，可以根据需要扩展）
        if text and re.search(r'[a-zA-Z]', text):
            try:
                message.delete()
                # 静默删除，不显示提示消息
                return
            except Exception as e:
                logger.error(f"删除外文消息失败: {e}")
    
    # 检查拦截相同信息
    if settings.get("sync_blocked_users", False):
        # 这里可以实现检查相同消息的逻辑
        # 例如记录消息哈希值，检查是否有多个相同的消息等
        pass

def handle_left_member(update: Update, context: CallbackContext):
    """处理成员离开"""
    chat_id = update.effective_chat.id
    
    # 检查群组是否已授权
    if not check_group_authorization(chat_id):
        return
    
    settings = utils.get_settings(chat_id)
    
    # 踢出退群功能已移除，不再记录退群用户
    pass 

def get_group_verify_setting(chat_id):
    """获取群组验群设置"""
    try:
        import requests
        response = requests.get(f'http://localhost:3002/api/get_verify_setting/{chat_id}', timeout=5)
        if response.status_code == 200:
            data = response.json()
            if data.get('success', False):
                setting = data.get('setting', {})
                logger.info(f"获取到群组 {chat_id} 的验群设置: keyword={setting.get('keyword')}, has_reply={bool(setting.get('reply_message'))}")
                return {
                    'keyword': setting.get('keyword', '验群'),
                    'reply_message': setting.get('reply_message'),
                    'self_destruct_time': setting.get('self_destruct_time', 100)
                }
            else:
                logger.warning(f"群组 {chat_id} 未配置验群设置")
    except Exception as e:
        logger.error(f"获取验群设置失败: {e}")
    
    # 返回默认设置，但不包含回复消息
    return {
        'keyword': '验群',
        'reply_message': None,
        'self_destruct_time': 100
    }

def get_group_address_setting(chat_id):
    """获取群组的地址设置"""
    try:
        # 使用API方式获取设置，避免应用上下文问题
        import requests
        
        # 使用本地API获取设置
        response = requests.get(f'http://localhost:3002/api/get_address_setting/{chat_id}', timeout=5)
        if response.status_code == 200:
            data = response.json()
            if data.get('success', False):
                return data.get('data')
        
        return None
    except Exception as e:
        logging.error(f"获取地址设置失败: {e}")
        return None

def handle_address_keyword(update, context, message_text):
    """处理地址关键词"""
    if not message_text:
        return False
        
    chat_id = update.effective_chat.id
    user_id = update.effective_user.id
    message_id = update.message.message_id
    
    # 获取地址设置
    setting = get_group_address_setting(chat_id)
    if not setting:
        return False
    
    # 检查是否匹配关键词
    if setting['is_exact_match'] and message_text.strip() != "地址":
        return False
    elif not setting['is_exact_match'] and "地址" not in message_text:
        return False
    
    try:
        # 回复消息
        reply_text = setting['reply_text']
        reply_photo = setting['reply_photo']
        
        sent_message = None
        
        # 如果有图片，先发送图片
        if reply_photo:
            try:
                # 判断是URL还是文件ID
                if reply_photo.startswith(('http://', 'https://')):
                    # 如果是URL，先下载图片再发送
                    import requests
                    from io import BytesIO
                    
                    response = requests.get(reply_photo, timeout=10)
                    if response.status_code == 200:
                        photo = BytesIO(response.content)
                        photo.name = 'address_image.jpg'
                        
                        if reply_text:
                            # 发送图片和文本
                            sent_message = context.bot.send_photo(
                                chat_id=chat_id,
                                photo=photo,
                                caption=reply_text
                                # 移除 reply_to_message_id 参数
                            )
                        else:
                            # 只发送图片
                            sent_message = context.bot.send_photo(
                                chat_id=chat_id,
                                photo=photo
                                # 移除 reply_to_message_id 参数
                            )
                    else:
                        # URL无效，只发送文本
                        logging.error(f"下载地址图片失败: HTTP {response.status_code}")
                        if reply_text:
                            sent_message = context.bot.send_message(
                                chat_id=chat_id,
                                text=reply_text
                                # 移除 reply_to_message_id 参数
                            )
                else:
                    # 如果是文件ID，直接发送
                    if reply_text:
                        # 发送图片和文本
                        sent_message = context.bot.send_photo(
                            chat_id=chat_id,
                            photo=reply_photo,
                            caption=reply_text
                            # 移除 reply_to_message_id 参数
                        )
                    else:
                        # 只发送图片
                        sent_message = context.bot.send_photo(
                            chat_id=chat_id,
                            photo=reply_photo
                            # 移除 reply_to_message_id 参数
                        )
            except Exception as e:
                logging.error(f"发送地址图片失败: {e}")
                # 图片发送失败，尝试只发送文本
                if reply_text:
                    sent_message = context.bot.send_message(
                        chat_id=chat_id,
                        text=reply_text
                        # 移除 reply_to_message_id 参数
                    )
        elif reply_text:
            # 只有文本，没有图片
            sent_message = context.bot.send_message(
                chat_id=chat_id,
                text=reply_text
                # 移除 reply_to_message_id 参数
            )
        
        # 如果设置了自焚时间，安排删除消息
        if sent_message and setting['self_destruct_time'] > 0:
            # 安排删除原消息和回复消息
            context.job_queue.run_once(
                delete_messages,
                setting['self_destruct_time'],
                context={
                    'chat_id': chat_id,
                    'message_ids': [message_id, sent_message.message_id]
                }
            )
        
        return True
    except Exception as e:
        logging.error(f"处理地址关键词失败: {e}")
        return False

def handle_guarantee_form(update: Update, context: CallbackContext):
    """处理担保表单"""
    message = update.effective_message
    chat_id = update.effective_chat.id
    user_id = update.effective_user.id
    
    # 先更新管理员列表，确保能正确识别管理员
    update_group_admins(context.bot, chat_id)
    
    # 检查用户是否为管理员
    if not (is_group_admin(chat_id, user_id) or utils.is_admin(user_id)):
        return False
    
    # 检查消息是否以"担保表单:"开头
    if not message.text or not message.text.strip().startswith("担保表单:"):
        return False
    
    # 使用正则表达式解析表单内容
    form_pattern = r"担保表单:[\s\n]+" \
                   r"组别:([^\n]+)[\s\n]+" \
                   r"名字:([^\n]+)[\s\n]+" \
                   r"编号:([^\n]+)[\s\n]+" \
                   r"规则:([^\n]+)[\s\n]+" \
                   r"押金:([^\n]+)"
    
    match = re.search(form_pattern, message.text, re.DOTALL)
    if not match:
        # 格式不匹配
        logger.info(f"担保表单格式不匹配: {message.text}")
        return False
    
    try:
        # 提取表单信息
        group = match.group(1).strip()
        name = match.group(2).strip()
        number = match.group(3).strip()
        rule = match.group(4).strip()
        deposit = match.group(5).strip()
        
        # 构建回复消息
        reply_text = f"担保规则写入成功\n{group}{number}-{rule}{name}"
        
        # 发送回复消息
        context.bot.send_message(
            chat_id=chat_id,
            text=reply_text
        )
        
        # 记录日志
        logger.info(f"已处理担保表单: 组别={group}, 名字={name}, 编号={number}, 规则={rule}, 押金={deposit}")
        return True
    except Exception as e:
        logger.error(f"处理担保表单失败: {e}")
        return False

def self_destruct_messages(context):
    """自焚消息的回调函数"""
    job_context = context.job.context
    chat_id = job_context['chat_id']
    reply_message_id = job_context['reply_message_id']
    original_message_id = job_context['original_message_id']
    
    try:
        # 删除机器人的回复消息
        context.bot.delete_message(chat_id=chat_id, message_id=reply_message_id)
        # 删除用户的原始消息
        context.bot.delete_message(chat_id=chat_id, message_id=original_message_id)
    except Exception as e:
        logger.error(f"删除消息失败: {e}")
        # 消息可能已被删除，或机器人没有删除消息的权限 

def check_prohibited_words(text, bot, chat_id, user_id, message_id):
    """检查消息是否包含违禁词"""
    try:
        import requests
        response = requests.get('http://localhost:3002/api/get_prohibited_words', timeout=5)
        if response.status_code == 200:
            data = response.json()
            if data.get('success', False) and data.get('words'):
                prohibited_words = data['words']
                
                # 检查每个违禁词
                for word_data in prohibited_words:
                    word = word_data['word']
                    is_exact_match = word_data['is_exact_match']
                    action = word_data['action']
                    
                    # 根据匹配方式检查
                    if is_exact_match:
                        # 精确匹配
                        if word == text:
                            # 执行操作
                            handle_prohibited_word(bot, chat_id, user_id, action, word, message_id)
                            return True
                    else:
                        # 模糊匹配
                        if word in text:
                            # 执行操作
                            handle_prohibited_word(bot, chat_id, user_id, action, word, message_id)
                            return True
    except Exception as e:
        logger.error(f"检查违禁词失败: {e}")
    
    return False

def handle_prohibited_word(bot, chat_id, user_id, action, word, message_id):
    """处理违禁词"""
    try:
        # 删除消息 - 不使用get_updates()，因为这可能会获取到旧消息
        # 我们假设调用此函数时，消息ID已经通过update.message传入
        try:
            # 尝试删除消息，但不抛出异常
            bot.delete_message(chat_id=chat_id, message_id=message_id)
        except Exception as e:
            logger.error(f"删除违禁词消息失败: {e}")
        
        # 根据操作类型执行不同的操作
        if action == 'mute':
            # 禁言用户
            bot.restrict_chat_member(
                chat_id,
                user_id,
                permissions=ChatPermissions(
                    can_send_messages=False,
                    can_send_media_messages=False,
                    can_send_other_messages=False,
                    can_add_web_page_previews=False
                )
            )
            
            # 不发送提示消息
        elif action == 'kick':
            # 踢出用户
            bot.kick_chat_member(chat_id, user_id)
            
            # 不发送提示消息
    except Exception as e:
        logger.error(f"处理违禁词失败: {e}")

def save_welcome_message_ids():
    """保存欢迎消息ID到文件"""
    try:
        with open('welcome_messages.json', 'w') as f:
            json.dump(last_welcome_messages, f)
    except Exception as e:
        logger.error(f"保存欢迎消息ID文件失败: {e}")

def load_welcome_message_ids():
    """从文件加载欢迎消息ID"""
    global last_welcome_messages
    try:
        if os.path.exists('welcome_messages.json'):
            with open('welcome_messages.json', 'r') as f:
                last_welcome_messages = json.load(f)
                # 将字符串键转换为整数
                last_welcome_messages = {int(k): v for k, v in last_welcome_messages.items()}
    except Exception as e:
        logger.error(f"加载欢迎消息ID文件失败: {e}")
        last_welcome_messages = {}

# 在启动时加载欢迎消息ID
load_welcome_message_ids() 

def handle_class_command(update: Update, context: CallbackContext, command):
    """处理上下课命令"""
    chat_id = update.effective_chat.id
    user_id = update.effective_user.id
    
    # 检查群组是否已授权
    if not check_group_authorization(chat_id):
        context.bot.send_message(
            chat_id=chat_id,
            text="⚠️ 此群组未获得使用授权，请联系管理员开通权限。"
        )
        # 尝试退出未授权群组
        try:
            context.bot.leave_chat(chat_id)
            logger.info(f"检测到未授权群组 {chat_id}，机器人已退出")
        except Exception as e:
            logger.error(f"退出未授权群组失败: {e}")
        return
    
    # 获取群组名称
    try:
        chat = context.bot.get_chat(chat_id)
        group_name = chat.title
    except Exception as e:
        logger.error(f"获取群组名称失败: {e}")
        group_name = "本群"
    
    # 处理上课命令
    if command == "上课":
        # 获取上课消息模板
        template = utils.get_message_template('class_start_message')
        message_text = template['content']
        
        # 创建按钮
        keyboard = []
        if template['buttons']:
            buttons_row = []
            for button in template['buttons']:
                buttons_row.append(
                    InlineKeyboardButton(button["text"], url=button["url"])
                )
            keyboard.append(buttons_row)
        
        reply_markup = InlineKeyboardMarkup(keyboard) if keyboard else None
        
        # 发送上课消息
        class_msg = context.bot.send_message(
            chat_id=chat_id,
            text=message_text,
            parse_mode="HTML",
            disable_web_page_preview=True,
            reply_markup=reply_markup
        )
        
        # 保存这条消息的ID
        if chat_id not in utils.last_class_messages:
            utils.last_class_messages[chat_id] = []
        utils.last_class_messages[chat_id].append(class_msg.message_id)
        utils.save_class_message_ids()
        
        # 允许所有用户发言
        try:
            context.bot.set_chat_permissions(
                chat_id=chat_id,
                permissions=ChatPermissions(
                    can_send_messages=True,
                    can_send_media_messages=True,
                    can_send_other_messages=True,
                    can_add_web_page_previews=True,
                    can_send_polls=True,
                    can_invite_users=True
                )
            )
        except Exception as e:
            logger.error(f"设置群权限失败: {e}")
    
    # 处理下课命令
    elif command == "下课":
        # 获取下课消息模板
        template = utils.get_message_template('class_end_message')
        message_text = template['content']
        
        # 创建按钮
        keyboard = []
        if template['buttons']:
            buttons_row = []
            for button in template['buttons']:
                buttons_row.append(
                    InlineKeyboardButton(button["text"], url=button["url"])
                )
            keyboard.append(buttons_row)
        
        reply_markup = InlineKeyboardMarkup(keyboard) if keyboard else None
        
        # 发送下课消息
        class_msg = context.bot.send_message(
            chat_id=chat_id,
            text=message_text,
            parse_mode="HTML",
            disable_web_page_preview=True,
            reply_markup=reply_markup
        )
        
        # 保存这条消息的ID
        if chat_id not in utils.last_class_messages:
            utils.last_class_messages[chat_id] = []
        utils.last_class_messages[chat_id].append(class_msg.message_id)
        utils.save_class_message_ids()
        
        # 禁止普通用户发言
        try:
            context.bot.set_chat_permissions(
                chat_id=chat_id,
                permissions=ChatPermissions(
                    can_send_messages=False,
                    can_send_media_messages=False,
                    can_send_other_messages=False,
                    can_add_web_page_previews=False,
                    can_send_polls=False,
                    can_invite_users=False
                )
            )
        except Exception as e:
            logger.error(f"设置群权限失败: {e}")

def handle_chat_member_update(update: Update, context: CallbackContext):
    """处理成员状态更新，特别是加入请求"""
    chat_member_update = update.chat_member
    if not chat_member_update:
        return
    
    chat_id = chat_member_update.chat.id
    user_id = chat_member_update.new_chat_member.user.id
    
    # 记录详细的状态变化，用于调试
    old_status = chat_member_update.old_chat_member.status
    new_status = chat_member_update.new_chat_member.status
    logger.info(f"检测到成员状态更新: 用户 {user_id} 在群组 {chat_id} 中的状态从 {old_status} 变为 {new_status}")
    
    # 检查群组是否已授权
    if not check_group_authorization(chat_id):
        logger.info(f"未授权群组 {chat_id} 的成员状态更新，忽略")
        return
    
    # 检测新成员加入 - 当状态从 'left' 或其他非成员状态变为 'member', 'administrator' 或 'creator'
    if old_status in ['left', 'kicked', 'restricted'] and new_status in ['member', 'administrator', 'creator']:
        logger.info(f"检测到新成员加入通过chat_member_update: 用户 {user_id} 在群组 {chat_id}")
        
        # 跳过机器人自己
        if user_id == context.bot.id:
            logger.info("跳过机器人自己")
            return
        
        # 获取群组设置
        settings = utils.get_settings(chat_id)
        
        # 检查是否启用进群验证或欢迎语
        verification_enabled = settings.get("verification", False)
        welcome_enabled = settings.get("welcome_message", False)
        
        if not verification_enabled and not welcome_enabled:
            logger.info(f"群组 {chat_id} 未启用进群验证和欢迎语，跳过")
            return
        
        # 如果启用了进群验证
        if verification_enabled:
            # 获取群组名称
            try:
                chat = context.bot.get_chat(chat_id)
                group_name = chat.title
            except Exception as e:
                logger.error(f"获取群组名称失败: {e}")
                group_name = "本群"
            
            # 获取用户信息
            try:
                user = context.bot.get_chat_member(chat_id, user_id).user
                user_name = user.first_name
                if user.last_name:
                    user_name += f" {user.last_name}"
                user_mention = f"@{user.username}" if user.username else user_name
            except Exception as e:
                logger.error(f"获取用户信息失败: {e}")
                user_name = "新成员"
                user_mention = user_name
            
            # 自动限制新成员（只限制发言、媒体、表情，明确设置其他权限为正常状态）
            try:
                context.bot.restrict_chat_member(
                    chat_id=chat_id,
                    user_id=user_id,
                    permissions=ChatPermissions(
                        can_send_messages=False,
                        can_send_media_messages=False,
                        can_send_polls=False,
                        can_send_other_messages=False,
                        can_add_web_page_previews=False,
                        can_change_info=False,  # 普通成员不能修改群信息
                        can_invite_users=True,  # 保持可以邀请用户
                        can_pin_messages=False  # 普通成员不能置顶消息
                    )
                )
                logger.info(f"已限制用户 {user_id} 在群组 {chat_id} 的发言、媒体和表情权限")
            except Exception as e:
                logger.error(f"限制用户失败: {e}")
            
            # 尝试删除上一条欢迎消息
            try:
                if chat_id in last_welcome_messages:
                    last_msg_id = last_welcome_messages[chat_id]
                    try:
                        context.bot.delete_message(chat_id=chat_id, message_id=last_msg_id)
                        logger.info(f"已删除群 {chat_id} 的上一条欢迎消息 {last_msg_id}")
                    except Exception as e:
                        logger.error(f"删除上一条欢迎消息失败: {e}")
            except Exception as e:
                logger.error(f"处理上一条欢迎消息时出错: {e}")
            
            # 构建验证消息文本（从数据库获取）
            template = utils.get_message_template('verification_message')
            welcome_text = template['content'].format(
                user_name=user_name,
                group_name=group_name
            )
            
            # 创建按钮键盘（模板按钮 + 解除禁言按钮，智能排列）
            keyboard = []
            
            if template['buttons']:
                template_buttons = template['buttons']
                all_buttons = []
                
                # 先添加所有模板按钮
                for btn in template_buttons:
                    all_buttons.append(InlineKeyboardButton(btn["text"], url=btn["url"]))
                
                # 添加解除禁言按钮（使用verify前缀）
                all_buttons.append(InlineKeyboardButton("解除禁言", callback_data=f"verify_{user_id}"))
                
                # 按2个一行排列所有按钮
                for i in range(0, len(all_buttons), 2):
                    row = []
                    for j in range(i, min(i+2, len(all_buttons))):
                        row.append(all_buttons[j])
                    keyboard.append(row)
            else:
                # 如果没有模板按钮，解除禁言按钮单独一行（使用verify前缀）
                keyboard.append([
                    InlineKeyboardButton("解除禁言", callback_data=f"verify_{user_id}")
                ])
            
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            # 添加到待验证列表
            if chat_id not in pending_verification:
                pending_verification[chat_id] = {}
            
            # 发送验证消息
            welcome_msg = context.bot.send_message(
                chat_id=chat_id,
                text=welcome_text,
                parse_mode="HTML",
                disable_web_page_preview=True,
                reply_markup=reply_markup
            )
            
            # 创建20秒后超时踢出的定时任务
            job = context.job_queue.run_once(
                verification_timeout,
                20,
                context={
                    'chat_id': chat_id,
                    'user_id': user_id,
                    'message_id': welcome_msg.message_id
                },
                name=f"timeout_{chat_id}_{user_id}"
            )
            
            # 保存验证信息（包含job引用，用于取消）
            pending_verification[chat_id][user_id] = {
                'username': user_name,
                'join_time': datetime.now(),
                'message_id': welcome_msg.message_id,
                'delete_job': job  # 改为delete_job，与handle_verification_callback一致
            }
            
            # 保存这条消息的ID
            last_welcome_messages[chat_id] = welcome_msg.message_id
            
            # 保存最后一条欢迎消息ID到文件
            try:
                save_welcome_message_ids()
            except Exception as e:
                logger.error(f"保存欢迎消息ID失败: {e}")
            
                logger.info(f"已发送进群验证消息给用户 {user_id} 在群组 {chat_id}，用户已被禁言")
            except Exception as e:
                logger.error(f"发送进群验证消息失败: {e}")
        
        # 如果没启用验证但启用了欢迎语，直接发送欢迎消息（不禁言）
        elif welcome_enabled:
            try:
                # 获取群组名称
                try:
                    chat = context.bot.get_chat(chat_id)
                    group_name = chat.title
                except Exception as e:
                    logger.error(f"获取群组名称失败: {e}")
                    group_name = "本群"
                
                # 获取用户信息
                try:
                    user = context.bot.get_chat_member(chat_id, user_id).user
                    user_name = user.first_name
                    if user.last_name:
                        user_name += f" {user.last_name}"
                except Exception as e:
                    logger.error(f"获取用户信息失败: {e}")
                    user_name = "新成员"
                
                # 尝试删除上一条欢迎消息
                try:
                    if chat_id in last_welcome_messages:
                        last_msg_id = last_welcome_messages[chat_id]
                        try:
                            context.bot.delete_message(chat_id=chat_id, message_id=last_msg_id)
                            logger.info(f"已删除群 {chat_id} 的上一条欢迎消息 {last_msg_id}")
                        except Exception as e:
                            logger.error(f"删除上一条欢迎消息失败: {e}")
                except Exception as e:
                    logger.error(f"处理上一条欢迎消息时出错: {e}")
                
                # 使用数据库中的欢迎消息模板
                template = utils.get_message_template('welcome_message')
                welcome_text = template['content'].format(
                    user_name=user_name,
                    group_name=group_name
                )
                
                # 创建底部按钮
                keyboard = []
                if template['buttons']:
                    buttons_row = []
                    for button in template['buttons']:
                        buttons_row.append(
                            InlineKeyboardButton(button["text"], url=button["url"])
                        )
                    keyboard.append(buttons_row)
                
                reply_markup = InlineKeyboardMarkup(keyboard) if keyboard else None
                
                # 发送欢迎消息
                welcome_msg = context.bot.send_message(
                    chat_id=chat_id,
                    text=welcome_text,
                    parse_mode="HTML",
                    disable_web_page_preview=True,
                    reply_markup=reply_markup
                )
                
                # 保存这条消息的ID
                last_welcome_messages[chat_id] = welcome_msg.message_id
                
                # 保存最后一条欢迎消息ID到文件
                try:
                    save_welcome_message_ids()
                except Exception as e:
                    logger.error(f"保存欢迎消息ID失败: {e}")
                
                logger.info(f"已发送欢迎消息给用户 {user_id} 在群组 {chat_id}（无需验证）")
            except Exception as e:
                logger.error(f"发送欢迎消息失败: {e}")

def handle_join_request(update: Update, context: CallbackContext):
    """处理加入请求事件"""
    join_request = update.chat_join_request
    if not join_request:
        return
    
    chat_id = join_request.chat.id
    user_id = join_request.from_user.id
    
    logger.info(f"收到用户 {user_id} 加入群组 {chat_id} 的请求")
    
    # 检查群组是否已授权
    if not check_group_authorization(chat_id):
        logger.info(f"未授权群组 {chat_id} 的加入请求，忽略")
        return
    
    # 记录请求但不自动批准，由群组管理员手动处理
    logger.info(f"用户 {user_id} 加入群组 {chat_id} 的请求已记录，等待管理员处理")

# 添加删除消息的函数
def delete_messages(context):
    """删除消息（用于自焚功能）"""
    job = context.job
    chat_id = job.context['chat_id']
    message_ids = job.context['message_ids']
    
    bot = context.bot
    for message_id in message_ids:
        try:
            bot.delete_message(chat_id=chat_id, message_id=message_id)
        except Exception as e:
            logging.error(f"删除消息失败: {e}")

def handle_keyword_matching(update: Update, context: CallbackContext):
    """处理关键词匹配（从数据库读取配置）"""
    message = update.effective_message
    chat_id = update.effective_chat.id
    
    if not message.text:
        return False
    
    # 获取消息文本
    text = message.text.strip()
    
    try:
        # 从API获取关键词匹配配置
        import requests
        response = requests.get('http://localhost:3002/api/keyword_matching', timeout=5)
        
        if response.status_code != 200:
            logger.error("获取关键词匹配配置失败")
            return False
        
        data = response.json()
        if not data.get('success'):
            logger.error(f"获取关键词匹配配置失败: {data.get('error')}")
            return False
        
        keyword_configs = data.get('data', {})
        
        # 检查是否包含配置中的关键词
        for keyword, keyword_config in keyword_configs.items():
            if keyword in text:
                try:
                    # 准备回复消息
                    reply_text = keyword_config.get('reply_text', '')
                    
                    # 准备按钮
                    keyboard = []
                    buttons = keyword_config.get('buttons', [])
                    if buttons:
                        row = []
                        for i, button in enumerate(buttons):
                            row.append(InlineKeyboardButton(text=button["text"], url=button["url"]))
                            
                            # 每行放两个按钮
                            if (i + 1) % 2 == 0 or i == len(buttons) - 1:
                                keyboard.append(row)
                                row = []
                    
                    reply_markup = InlineKeyboardMarkup(keyboard) if keyboard else None
                    
                    # 回复原消息，而不是发送新消息
                    message.reply_text(
                        text=reply_text,
                        reply_markup=reply_markup,
                        parse_mode="HTML",
                        disable_web_page_preview=True
                    )
                    
                    logger.info(f"关键词匹配成功: {keyword}")
                    return True
                except Exception as e:
                    logger.error(f"处理关键词匹配失败: {e}")
                    return False
    except Exception as e:
        logger.error(f"获取关键词匹配配置异常: {e}")
    
    return False