#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
统一数据库管理模块
"""

import pymysql
from pymysql.cursors import DictCursor
import sys
import os
import logging

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

# 导入统一配置
import config

logger = logging.getLogger(__name__)

def get_db_connection():
    """获取数据库连接"""
    return pymysql.connect(
        host=config.DB_HOST,
        port=config.DB_PORT,
        user=config.DB_USER,
        password=config.DB_PASSWORD,
        database=config.DB_NAME,
        charset='utf8mb4',
        cursorclass=DictCursor
    )

def init_database():
    """初始化数据库，创建所有必要的表"""
    print("正在初始化数据库...")
    
    # 连接MySQL（不指定数据库）
    conn = pymysql.connect(
        host=config.DB_HOST,
        port=config.DB_PORT,
        user=config.DB_USER,
        password=config.DB_PASSWORD,
        charset='utf8mb4'
    )
    cursor = conn.cursor()
    
    try:
        # 创建数据库
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS `{config.DB_NAME}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
        cursor.execute(f"USE `{config.DB_NAME}`")
        print(f"✓ 数据库 '{config.DB_NAME}' 已就绪")
        
        # ========== 报备机器人表 ==========
        
        # 群组表
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS `groups` (
            `group_id` BIGINT PRIMARY KEY,
            `group_name` VARCHAR(255),
            `group_code` VARCHAR(50),
            `deposit_amount` VARCHAR(50),
            `group_full_name` VARCHAR(255),
            `settlement_type` VARCHAR(50),
            `is_active` BOOLEAN DEFAULT 0,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `used_deposit` DECIMAL(10,2) DEFAULT 0.00,
            INDEX `idx_is_active` (`is_active`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ''')
        print("✓ 表 'groups' 已创建")
        
        # 管理员表
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS `admins` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `user_id` BIGINT NOT NULL,
            `group_id` BIGINT,
            `username` VARCHAR(255),
            `added_by` BIGINT,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (`group_id`) REFERENCES `groups`(`group_id`) ON DELETE CASCADE,
            UNIQUE KEY `unique_user_group` (`user_id`, `group_id`),
            INDEX `idx_user_id` (`user_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ''')
        print("✓ 表 'admins' 已创建")
        
        # 报备表
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS `reports` (
            `report_id` VARCHAR(50) PRIMARY KEY,
            `info` TEXT,
            `masked_info` TEXT,
            `customer_username` VARCHAR(255),
            `status` VARCHAR(50),
            `reporter_id` BIGINT,
            `reporter_username` VARCHAR(255),
            `amount` VARCHAR(50),
            `created_time` VARCHAR(50),
            `group_chat_id` BIGINT,
            `group_message_id` BIGINT,
            `customer_id` BIGINT,
            `confirmed_time` VARCHAR(50),
            `admin_completed` BOOLEAN DEFAULT 0,
            `customer_cancelled` BOOLEAN DEFAULT 0,
            `admin_cancelled` BOOLEAN DEFAULT 0,
            `deposit_updated` BOOLEAN DEFAULT 0,
            `staff_confirmed` BOOLEAN DEFAULT 0,
            INDEX `idx_status` (`status`),
            INDEX `idx_group_chat_id` (`group_chat_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ''')
        print("✓ 表 'reports' 已创建")
        
        # ========== 防骗机器人表 ==========
        
        # 授权群组表
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS `authorized_groups` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `chat_id` VARCHAR(50) UNIQUE NOT NULL,
            `group_name` VARCHAR(200) NOT NULL,
            `is_active` BOOLEAN DEFAULT 1,
            `authorized_by` VARCHAR(80) NOT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `expires_at` TIMESTAMP NULL,
            INDEX `idx_chat_id` (`chat_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ''')
        print("✓ 表 'authorized_groups' 已创建")
        
        # 群组验证设置表
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS `group_verify_settings` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `chat_id` VARCHAR(50) UNIQUE NOT NULL,
            `keyword` VARCHAR(50) DEFAULT '验群',
            `reply_message` TEXT NOT NULL,
            `self_destruct_time` INT DEFAULT 100,
            `created_by` VARCHAR(80),
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX `idx_chat_id` (`chat_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ''')
        print("✓ 表 'group_verify_settings' 已创建")
        
        # 群组设置表
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS `group_settings` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `chat_id` VARCHAR(50) UNIQUE NOT NULL,
            `settings` JSON NOT NULL,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX `idx_chat_id` (`chat_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ''')
        print("✓ 表 'group_settings' 已创建")
        
        # 违禁词表
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS `prohibited_words` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `word` VARCHAR(200) NOT NULL,
            `is_exact_match` BOOLEAN DEFAULT 1,
            `action` VARCHAR(20) DEFAULT 'mute',
            `created_by` VARCHAR(80),
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX `idx_word` (`word`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ''')
        print("✓ 表 'prohibited_words' 已创建")
        
        # 地址设置表
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS `group_address_settings` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `chat_id` VARCHAR(50) UNIQUE NOT NULL,
            `enabled` BOOLEAN DEFAULT 1,
            `reply_text` TEXT,
            `reply_photo` TEXT,
            `is_exact_match` BOOLEAN DEFAULT 1,
            `self_destruct_time` INT DEFAULT 0,
            `created_by` VARCHAR(80),
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX `idx_chat_id` (`chat_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ''')
        print("✓ 表 'group_address_settings' 已创建")
        
        # 机器人配置表（消息模板）
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS `bot_message_templates` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `template_key` VARCHAR(50) UNIQUE NOT NULL,
            `template_name` VARCHAR(100) NOT NULL,
            `template_content` TEXT NOT NULL,
            `buttons` JSON,
            `description` VARCHAR(255),
            `updated_by` VARCHAR(80),
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX `idx_template_key` (`template_key`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ''')
        print("✓ 表 'bot_message_templates' 已创建")
        
        # 创建关键词匹配配置表
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS `keyword_matching_settings` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `keyword` VARCHAR(500) NOT NULL COMMENT '触发关键词',
            `reply_text` TEXT NOT NULL COMMENT '回复文本',
            `buttons` JSON COMMENT '按钮配置',
            `enabled` TINYINT(1) DEFAULT 1 COMMENT '是否启用',
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX `idx_keyword` (`keyword`(255)),
            INDEX `idx_enabled` (`enabled`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ''')
        print("✓ 表 'keyword_matching_settings' 已创建")
        
        # 检查是否已有默认关键词，避免重复插入
        cursor.execute("SELECT COUNT(*) FROM `keyword_matching_settings` WHERE `keyword` = 'TAB2kKwPYiXq1qNxaQHhrxvFNPZ51hSzmR'")
        count = cursor.fetchone()[0]
        if count == 0:
            # 插入默认关键词匹配配置（仅在不存在时插入）
            cursor.execute('''
            INSERT INTO `keyword_matching_settings` 
            (`keyword`, `reply_text`, `buttons`) 
            VALUES 
            ('TAB2kKwPYiXq1qNxaQHhrxvFNPZ51hSzmR', 
            '此地址为新币更换的最新地址，请放心交易，望各位用户知悉，惠存。',
            '[{"text": "我要举报", "url": "https://t.me/xdfkbot"}, {"text": "联系客服", "url": "https://t.me/xdfkbot"}]')
            ''')
            print("✓ 默认关键词匹配配置已插入")
        else:
            print("✓ 默认关键词匹配配置已存在，跳过插入")
        
        # 插入默认模板
        cursor.execute('''
        INSERT INTO `bot_message_templates` 
        (`template_key`, `template_name`, `template_content`, `buttons`, `description`) 
        VALUES 
        ('welcome_message', '欢迎消息', 
        '欢迎 {user_name} 来到 {group_name}\n交易前请先关注担保流程 【<a href="https://t.me/gonggao">@gonggao</a>】\n1.交易前认准群老板和业务员头衔，先看清楚置顶的群规则和报备模板；\n2.交易前群老板方必须在公群内进行报备，客户确认报备内容，如客户没确认此报备视为无效报备；\n3.交易过程中有任何变动需要在群内保留记录或者重新报备；\n4.有任何问题可以联系新币24小时客服 <a href="https://t.me/xdfkbot">@xbkf</a>\n⚠️注意: 主动私聊你的都是骗子！一切交易必须群内进行,切勿私下交易,请按照担保流程进行交易。',
        '[{"text": "新币供需", "url": "https://t.me/abcd"}, {"text": "新币客服", "url": "https://t.me/xdfkbot"}]',
        '用户验证通过后发送的欢迎消息'),
        
        ('verification_message', '进群验证消息',
        '欢迎来到 {group_name}\n\n⚠️ 先报备再交易,无报备属于私下作业!\n⚠️ 私下作业不在担保范围内,出现纠纷不予处理!',
        '[{"text": "新币客服", "url": "https://t.me/xdfkbot"}, {"text": "违规举报", "url": "https://t.me/xbwvvv"}, {"text": "新币供需", "url": "https://t.me/xbgx"}]',
        '新用户进群时的验证消息（含解除禁言按钮）'),
        
        ('class_start_message', '上课消息',
        '本群已开启发言，群内可以正常作业\n认准群老板头衔 切勿私下交易。',
        '[{"text": "新币供需", "url": "https://t.me/abcd"}, {"text": "新币客服", "url": "https://t.me/xdfkbot"}]',
        '群组开启发言时的通知消息'),
        
        ('class_end_message', '下课消息',
        '本公群已下课关闭发言\n如需交易，请在该群恢复营业后在群内交易！ 切勿私下交易！！',
        '[{"text": "新币供需", "url": "https://t.me/abcd"}, {"text": "新币客服", "url": "https://t.me/xdfkbot"}]',
        '群组关闭发言时的通知消息'),
        
        ('start_message', 'Start消息',
        '<a href="https://t.me/xdfkbot">点击此处可以添加机器人进群</a>\n\n更多服务，请访问 <a href="https://t.me/xdfkbot/">https://t.me/xbkf/</a>',
        '[{"text": "新币红包(24小时发红包)", "url": "https://t.me/+9S5qHAIh24JmMjBk"}, {"text": "新币客服", "url": "https://t.me/xdfkbot"}]',
        '用户私聊发送 /start 命令时的回复')
        ON DUPLICATE KEY UPDATE template_key=template_key
        ''')
        print("✓ 默认消息模板已插入")
        
        # ========== 客服机器人表 ==========
        
        # 客服机器人按钮配置表
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS `xinbi_bot_buttons` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `button_text` VARCHAR(100) NOT NULL COMMENT '按钮文本',
            `button_order` INT DEFAULT 0 COMMENT '排序顺序',
            `config_data` JSON COMMENT '按钮完整配置（消息、按钮等）',
            `is_enabled` BOOLEAN DEFAULT 1 COMMENT '是否启用',
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY `unique_button_text` (`button_text`),
            INDEX `idx_order` (`button_order`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ''')
        print("✓ 表 'xinbi_bot_buttons' 已创建")
        
        # 客服机器人全局配置表
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS `xinbi_bot_config` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `config_key` VARCHAR(50) UNIQUE NOT NULL COMMENT '配置键',
            `config_value` TEXT COMMENT '配置值',
            `description` VARCHAR(255) COMMENT '描述',
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX `idx_config_key` (`config_key`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ''')
        print("✓ 表 'xinbi_bot_config' 已创建")
        
        # 插入默认配置
        cursor.execute('''
        INSERT INTO `xinbi_bot_config` 
        (`config_key`, `config_value`, `description`) 
        VALUES 
        ('admin_group_id', '', '管理员群组ID'),
        ('welcome_message', '买会员/买广告/发供需\n联系 @xbkf 发送指令 /start\n点击👉购买广告/VIP精英群门票\n\n您好，这里是新币担保在线人工客服！\n真假群最简单的核实方式，只要担保靓号在群里的都是真群。\n请问有什么可以帮助您？', 'Start命令欢迎消息'),
        ('video_file_id', '', '查群验群视频file_id')
        ON DUPLICATE KEY UPDATE config_key=config_key
        ''')
        print("✓ 默认客服机器人配置已插入")
        
        # 检查并插入默认按钮配置
        import json as json_lib
        
        default_buttons = [
            ('新手必读', 1, {
                "messages": [
                    {
                        "text": "收费标准:\n1、新币供需200/条;vip群门票500U/一张\n2、专群上押500u起,担保费最低15u起\n3、公群上押3000U起,最低100U起,(按业务类型收取)",
                        "inline_buttons": [[
                            {"text": "专群流程频道", "url": "https://t.me/your_exclusive_channel"},
                            {"text": "公群流程频道", "url": "https://t.me/your_public_channel"}
                        ]]
                    },
                    {
                        "text": "新手必读:\n1、请务必核对以下三项信息:靓号用户名+888号码+唯一地址(注意:个人简介≠用户名,担保号三者俱全)\n2、新币最简单的核实方式,只要4A担保靓号在群里的都是真群。\n3、设置TG二步验证,加靓号好友改特殊备注,群邀请权限关闭。\n4、不要随意点击文件或链接,使用正版TG,无毒中文包。防止账号被盗",
                        "inline_buttons": [[
                            {"text": "高手秘笈", "url": "https://t.me/your_master_guide"},
                            {"text": "新币展示频道知识合集", "url": "https://t.me/your_knowledge_channel"}
                        ]]
                    }
                ]
            }, 1),
            ('购买广告/内部群门票', 2, {
                "messages": [
                    {"text": "✅优质社群开放招募｜精英联盟·资源互通·业务共赢\n\n✅常规业务管理群：88U\n✅一二通管理群：188U\n✅卡商管理交流群：188U\n✅新币资源交易群：188U\n✅海外管理交流群：288U\n✅VIP精英内部群：500U\n《料属性讨论群》：新币有交易担保实际买后免费进群\n\n加入方式：\n1️⃣ 开设公群联系担保即可免费进入对应业务群。\n2️⃣ 新币上推或者新币担保交易三次以上免费进新币资源交易群。\n3️⃣ 开设VIP任选一个业务群免费进入（新币资源交易群除外）。\n4️⃣ 俱乐部级资金｜优质生意对接｜跨领域资源｜深度合作机会\n\n现全面对外开放，可购票加入，共享资源，选择适合的群组，与行动者同行，共创价值！"},
                    {"text": "老板，先看下收货标准和发布规则：\n\n1️⃣ 不得发布虚假诈骗广告，违者立即下架且不退款。\n2️⃣ 【供需普通广告】@abcd\n单价：200U/条，买10曝2，500u/30条，14000u/100条。\n3️⃣ 【带公群链接广告】@abcd\n单价：150U/条，买10曝1，4500u/35条，15000u/120条\n直顶广告：周直顶1000U，月直顶3000U\n4️⃣ 供方频道 @gongfang｜需方频道 @xufang\n月费：200U 年费：200U（加'年'标识）\n5️⃣ 【vip内部门票】门票50U\n⚠️ 注：广告售出后不退不换，发布后无法撤销或重发"},
                    {"text": "老板，请问要购买什么样的广告呢？", "reply_keyboard": "exit"}
                ]
            }, 1),
            ('人工/解封', 3, {"messages": [{"text": "你好，这里是新币担保人工客服，请问有什么可以帮助您？"}]}, 1),
            ('进VIP精英群/资源交易群', 4, {
                "messages": [{
                    "text": "✅优质社群开放招募｜精英联盟·资源互通·业务共赢\n\n✅常规业务管理群：88U\n✅一二通管理群：188U\n✅卡商管理交流群：188U\n✅新币资源交易群：188U\n✅海外管理交流群：288U\n✅VIP精英内部群：500U\n《料属性讨论群》：新币有交易担保实际买后免费进群\n\n加入方式：\n1️⃣ 开设公群联系担保即可免费进入对应业务群。\n2️⃣ 新币上推或者新币担保交易三次以上免费进新币资源交易群。\n3️⃣ 开设VIP任选一个业务群免费进入（新币资源交易群除外）。\n4️⃣ 俱乐部级资金｜高质量业务对接｜跨领域资源｜深度合作机会。\n\n现全面对外开放，可购票加入，共享资源，选择适合的群组，与行动者同行，共创价值！\n\n购买方式：点击👉购买广告/内部群门票",
                    "inline_buttons": [[
                        {"text": "进VIP精英群", "callback": "enter_vip_group"},
                        {"text": "进资源交易群", "callback": "enter_resource_group"}
                    ], [
                        {"text": "SafeW登记VIP精英群信息", "callback": "register_vip_info"}
                    ]]
                }]
            }, 1),
            ('投诉建议', 5, {"messages": [{"text": "您好，投诉/建议请联系担保负责人 @xbppp"}]}, 1),
            ('担保靓号', 6, {"messages": [{"text": "点击查看担保靓号"}]}, 1),
            ('违规举报', 7, {"messages": [{"text": "引导私下作业，偷税漏税，杀车点赞等有奖举报联系 @boss1"}]}, 1),
            ('查验用户信息（骗子查询）', 8, {
                "messages": [{
                    "text": "骗子曝光，拉假群，克隆群，杀车等等。举报核实联系各担保组。\n\n骗子曝光联系 @bixin\n\n输入ID+用户id数字 可以查询用户信息 包含VIP 客户认证 骗子信息",
                    "inline_buttons": [[{"text": "骗子曝光", "url": "https://t.me/your_scammer_report_channel"}]]
                }]
            }, 1),
            ('查群/验群', 9, {
                "send_video": True,
                "messages": [
                    {
                        "text": "①最简单的核实方式，只要以下担保靓号在群里的都是真群：\n@aaaa @bbbb @cccc @dddd @eeee @vvvv @uuuu @yyyy @pppp\n@qqqq @tttt @ssss @kkkk @nnnn @gggg @hhhh @ffff @iiii @oooo\n@mmmm\n\n②验证私聊机器人 @xbkf 发送\"验群\"输入 组别和群编号例如：Q60000\n即可查询您是否在该群组",
                        "inline_buttons": [[
                            {"text": "公群导航", "url": "https://t.me/your_public_navigation"},
                            {"text": "供需频道", "url": "https://t.me/your_supply_demand"}
                        ], [
                            {"text": "新币招商", "url": "https://t.me/your_investment"},
                            {"text": "中文搜索", "url": "https://t.me/your_chinese_search"}
                        ]]
                    },
                    {"text": "请输入要验证的群编号 格式为一担保组编号+群编号  例如 a1234 a组1234  b1234  g1234\n\n发送 /start 或者退出，可以退出查询状态", "reply_keyboard": "exit"}
                ]
            }, 1),
            ('解除封禁', 10, {"messages": [{"text": "已解除封禁，请注意遵守群规"}]}, 1),
            ('资源对接', 11, {"messages": [{"text": "资源对接请联系 @xinbiziyuanBot"}]}, 1)
        ]
        
        for btn_text, btn_order, config_data, is_enabled in default_buttons:
            cursor.execute("SELECT COUNT(*) FROM `xinbi_bot_buttons` WHERE `button_text` = %s", (btn_text,))
            count = cursor.fetchone()[0]
            
            if count == 0:
                cursor.execute("""
                    INSERT INTO `xinbi_bot_buttons` 
                    (`button_text`, `button_order`, `config_data`, `is_enabled`) 
                    VALUES (%s, %s, %s, %s)
                """, (btn_text, btn_order, json_lib.dumps(config_data, ensure_ascii=False), is_enabled))
                print(f"✓ 插入按钮配置: {btn_text}")
            else:
                print(f"✓ 按钮配置已存在，跳过: {btn_text}")
        
        conn.commit()
        print("\n✅ 数据库初始化完成！")
        return True
        
    except Exception as e:
        print(f"\n❌ 数据库初始化失败: {e}")
        conn.rollback()
        return False
    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    init_database()
