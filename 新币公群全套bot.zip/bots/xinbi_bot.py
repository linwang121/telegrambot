#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
新币机器人启动模块
"""
import sys
import os
import logging
import importlib.util

# 设置日志
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def main():
    """启动新币机器人"""
    logger.info("正在启动新币机器人...")
    
    # 获取路径
    current_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(current_dir)
    eeee_bot_path = os.path.join(parent_dir, 'eeee', 'bot.py')
    
    logger.info(f"新币机器人文件路径: {eeee_bot_path}")
    
    # 检查文件是否存在
    if not os.path.exists(eeee_bot_path):
        logger.error(f"新币机器人文件不存在: {eeee_bot_path}")
        raise FileNotFoundError(f"找不到新币机器人文件: {eeee_bot_path}")
    
    # 确保父目录在 sys.path 中（用于导入 config 等模块）
    if parent_dir not in sys.path:
        sys.path.insert(0, parent_dir)
    
    # 使用 importlib 直接从指定路径导入模块，避免路径冲突
    try:
        spec = importlib.util.spec_from_file_location("xinbi_bot_module", eeee_bot_path)
        xinbi_bot_module = importlib.util.module_from_spec(spec)
        
        logger.info(f"正在从 {eeee_bot_path} 加载新币机器人模块...")
        spec.loader.exec_module(xinbi_bot_module)
        
        logger.info("新币机器人模块加载成功，开始执行...")
        xinbi_bot_module.main()
        
    except Exception as e:
        logger.error(f"新币机器人启动失败: {e}")
        import traceback
        traceback.print_exc()
        raise

if __name__ == '__main__':
    main()
