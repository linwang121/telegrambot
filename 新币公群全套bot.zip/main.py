#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
统一机器人系统主启动程序
同时启动Web管理后台和多个机器人
"""

import threading
import time
import sys
import os
import subprocess
import signal

# 添加当前目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 全局变量：用于跟踪子进程
antifraud_process = None

def start_web_admin():
    """启动Web管理后台"""
    print("正在启动Web管理后台...")
    try:
        import web_admin
        web_admin.app.run(
            host='0.0.0.0',
            port=3002,
            debug=False,
            use_reloader=False
        )
    except Exception as e:
        print(f"Web管理后台启动失败: {e}")

def start_report_bot():
    """启动报备机器人"""
    print("正在启动报备机器人...")
    try:
        from bots import report_bot
        report_bot.main()
    except Exception as e:
        print(f"报备机器人启动失败: {e}")
        import traceback
        traceback.print_exc()

def start_xinbi_bot():
    """启动新币机器人"""
    print("正在启动新币机器人...")
    try:
        from bots import xinbi_bot
        xinbi_bot.main()
    except Exception as e:
        print(f"新币机器人启动失败: {e}")
        import traceback
        traceback.print_exc()

def check_antifraud_venv():
    """检查防骗机器人虚拟环境是否正确安装"""
    import platform
    current_dir = os.path.dirname(os.path.abspath(__file__))
    venv_dir = os.path.join(current_dir, 'venv_antifraud')
    
    # 跨平台Python路径判断
    if platform.system() == 'Windows':
        venv_python = os.path.join(venv_dir, 'Scripts', 'python.exe')
    else:  # Linux/Unix/macOS
        venv_python = os.path.join(venv_dir, 'bin', 'python')
    
    if not os.path.exists(venv_python):
        return False, "虚拟环境不存在"
    
    # 检查是否安装了telegram模块
    result = subprocess.run(
        [venv_python, '-c', 'import telegram; print("OK")'],
        capture_output=True,
        text=True
    )
    
    if result.returncode == 0 and 'OK' in result.stdout:
        return True, "环境正常"
    else:
        return False, "依赖未安装或损坏"

def setup_antifraud_venv():
    """自动创建防骗机器人的虚拟环境"""
    import platform
    current_dir = os.path.dirname(os.path.abspath(__file__))
    venv_dir = os.path.join(current_dir, 'venv_antifraud')
    
    # 跨平台Python路径判断
    if platform.system() == 'Windows':
        venv_python = os.path.join(venv_dir, 'Scripts', 'python.exe')
        venv_pip = os.path.join(venv_dir, 'Scripts', 'pip.exe')
    else:  # Linux/Unix/macOS
        venv_python = os.path.join(venv_dir, 'bin', 'python')
        venv_pip = os.path.join(venv_dir, 'bin', 'pip')
    
    print("\n" + "=" * 60)
    print("🔧 正在为防骗机器人创建/修复独立虚拟环境...")
    print("=" * 60)
    
    try:
        # 1. 如果虚拟环境已存在，删除它
        if os.path.exists(venv_dir):
            print("\n[清理] 删除旧的虚拟环境...")
            import shutil
            shutil.rmtree(venv_dir, ignore_errors=True)
            time.sleep(1)
        
        # 2. 创建虚拟环境
        print("\n[1/3] 创建虚拟环境...")
        result = subprocess.run(
            [sys.executable, '-m', 'venv', venv_dir],
            capture_output=True,
            text=True,
            timeout=120
        )
        if result.returncode != 0:
            print(f"✗ 创建虚拟环境失败: {result.stderr}")
            return False
        print("✓ 虚拟环境创建成功")
        
        # 3. 升级pip
        print("\n[2/3] 升级pip...")
        result = subprocess.run(
            [venv_python, '-m', 'pip', 'install', '--upgrade', 'pip'],
            capture_output=True,
            timeout=120
        )
        if result.returncode == 0:
            print("✓ pip升级成功")
        
        # 4. 安装依赖
        print("\n[3/3] 安装防骗机器人依赖（python-telegram-bot==13.15）...")
        print("      这可能需要1-3分钟，请耐心等待...")
        
        packages = [
            'python-telegram-bot==13.15',
            'PyMySQL==1.1.0',
            'python-dotenv==1.0.0',
            'requests==2.31.0',
            'APScheduler==3.10.4'
        ]
        
        # 逐个安装包，显示进度
        for i, package in enumerate(packages, 1):
            print(f"      [{i}/{len(packages)}] 安装 {package}...", end='', flush=True)
            result = subprocess.run(
                [venv_pip, 'install', package, '--quiet'],
                capture_output=True,
                text=True,
                timeout=180
            )
            if result.returncode == 0:
                print(" ✓")
            else:
                print(f" ✗\n      错误: {result.stderr}")
                return False
        
        print("✓ 所有依赖安装成功")
        
        # 5. 验证安装
        print("\n[验证] 检查环境配置...")
        result = subprocess.run(
            [venv_python, '-c', 'from telegram.ext import Updater, Filters; print("OK")'],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        if result.returncode == 0 and 'OK' in result.stdout:
            print("✓ 环境验证成功")
            print("\n" + "=" * 60)
            print("✅ 防骗机器人虚拟环境配置完成！")
            print("=" * 60)
            return True
        else:
            print(f"✗ 环境验证失败: {result.stderr}")
            return False
            
    except subprocess.TimeoutExpired:
        print("\n✗ 操作超时，可能是网络问题")
        return False
    except Exception as e:
        print(f"✗ 自动配置失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def start_antifraud_bot_subprocess():
    """使用subprocess启动防骗机器人（独立进程，避免依赖冲突）"""
    import platform
    global antifraud_process
    print("正在启动防骗机器人（独立进程）...")
    try:
        # 构建路径
        current_dir = os.path.dirname(os.path.abspath(__file__))
        antifraud_script = os.path.join(current_dir, 'bots', 'antifraud_bot.py')
        venv_dir = os.path.join(current_dir, 'venv_antifraud')
        log_file = os.path.join(current_dir, 'antifraud_bot.log')
        
        # 跨平台Python路径判断
        if platform.system() == 'Windows':
            venv_python = os.path.join(venv_dir, 'Scripts', 'python.exe')
        else:  # Linux/Unix/macOS
            venv_python = os.path.join(venv_dir, 'bin', 'python')
        
        # 检查虚拟环境
        venv_ok, venv_msg = check_antifraud_venv()
        
        if not venv_ok:
            print(f"⚠️  虚拟环境状态: {venv_msg}")
            # 自动创建或修复虚拟环境
            if not setup_antifraud_venv():
                print("\n❌ 虚拟环境配置失败，防骗机器人无法启动")
                print("   请检查网络连接后重试，或手动安装依赖：")
                print("   1. .\\venv_antifraud\\Scripts\\Activate.ps1")
                print("   2. pip install python-telegram-bot==13.15 PyMySQL==1.1.0 python-dotenv==1.0.0")
                return
        else:
            print(f"✓ 使用虚拟环境: {venv_python}")
        
        # 打开日志文件
        log_f = open(log_file, 'a', encoding='utf-8')
        
        # 使用subprocess启动防骗机器人，日志同时输出到文件和PIPE
        antifraud_process = subprocess.Popen(
            [venv_python, antifraud_script],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            universal_newlines=True
        )
        
        print(f"✓ 防骗机器人进程已启动 (PID: {antifraud_process.pid})")
        print(f"✓ 日志文件: {log_file}")
        
        # 实时输出日志（同时打印到控制台和写入文件）
        for line in iter(antifraud_process.stdout.readline, ''):
            if line:
                log_line = f"[防骗机器人] {line.rstrip()}"
                print(log_line)
                log_f.write(f"{log_line}\n")
                log_f.flush()  # 立即刷新到文件
        
        log_f.close()
        antifraud_process.wait()
        
    except Exception as e:
        print(f"防骗机器人启动失败: {e}")
        import traceback
        traceback.print_exc()

def main():
    """主函数"""
    print("=" * 50)
    print("统一机器人系统启动中...")
    print("=" * 50)
    
    # 初始化数据库
    print("\n正在初始化数据库...")
    try:
        from database.db import init_database
        init_database()
        print("✓ 数据库初始化完成")
    except Exception as e:
        print(f"✗ 数据库初始化失败: {e}")
        import traceback
        traceback.print_exc()
        return
    
    # 创建线程列表
    threads = []
    
    # 启动Web管理后台
    web_thread = threading.Thread(target=start_web_admin, name="WebAdmin", daemon=True)
    web_thread.start()
    threads.append(web_thread)
    time.sleep(2)  # 等待Web服务启动
    
    # 启动报备机器人
    report_thread = threading.Thread(target=start_report_bot, name="ReportBot", daemon=True)
    report_thread.start()
    threads.append(report_thread)
    time.sleep(2)  # 等待机器人启动
    
    # 启动防骗机器人（使用独立进程）
    antifraud_thread = threading.Thread(target=start_antifraud_bot_subprocess, name="AntiFraudBot", daemon=True)
    antifraud_thread.start()
    threads.append(antifraud_thread)
    
    # 启动新币机器人
    xinbi_thread = threading.Thread(target=start_xinbi_bot, name="XinbiBot", daemon=True)
    xinbi_thread.start()
    threads.append(xinbi_thread)
    time.sleep(2)  # 等待机器人启动
    
    print("\n" + "=" * 50)
    print("所有服务已启动:")
    print("  - Web管理后台: http://localhost:3002")
    print("  - 报备机器人: 运行中")
    print("  - 防骗机器人: 运行中")
    print("  - 新币机器人: 运行中（仅私聊）")
    print("=" * 50)
    print("\n按 Ctrl+C 停止所有服务\n")
    
    # 主线程保持运行
    try:
        while True:
            time.sleep(1)
            # 检查线程状态
            for thread in threads:
                if not thread.is_alive():
                    print(f"警告: {thread.name} 线程已停止")
    except KeyboardInterrupt:
        print("\n正在停止所有服务...")
        
        # 停止防骗机器人子进程
        if antifraud_process and antifraud_process.poll() is None:
            print("正在停止防骗机器人...")
            try:
                antifraud_process.terminate()  # 友好终止
                antifraud_process.wait(timeout=5)  # 等待最多5秒
                print("✓ 防骗机器人已停止")
            except subprocess.TimeoutExpired:
                print("强制停止防骗机器人...")
                antifraud_process.kill()  # 强制终止
                print("✓ 防骗机器人已强制停止")
        
        print("✓ 所有服务已停止")

if __name__ == '__main__':
    main()
