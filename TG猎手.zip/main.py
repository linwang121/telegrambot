import asyncio
import aiosqlite
import re
import random
import logging
import os
import zipfile
import shutil
import tempfile
import time
from datetime import datetime
from pyrogram import Client, filters
from pyrogram.errors import FloodWait, SessionPasswordNeeded
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, Message, CallbackQuery

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

API_ID = 33832620
API_HASH = "de64691ab4d40e276cf43629b32da20f"
BOT_TOKEN = "8370075946:AAGNtvwN1X1nGIzk5tErJxPoIGT90bqZUWk"

DB_PATH = "bot_data.db"
UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(os.path.join(UPLOAD_DIR, "sessions"), exist_ok=True)
os.makedirs(os.path.join(UPLOAD_DIR, "tdata"), exist_ok=True)

user_states = {}
active_tasks = {}  # task_id -> {"task": asyncio.Task, "stop_event": asyncio.Event, "client": Client, ...}
task_clients = {}  # task_id -> list of (account_id, Client)

# ==================== 数据库 ====================
async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.executescript("""
            CREATE TABLE IF NOT EXISTS accounts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                phone TEXT DEFAULT '',
                session_string TEXT DEFAULT '',
                user_id INTEGER UNIQUE,
                session_file TEXT DEFAULT '',
                tdata_path TEXT DEFAULT '',
                password TEXT DEFAULT '',
                is_active INTEGER DEFAULT 1
            );
            CREATE TABLE IF NOT EXISTS groups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_id INTEGER UNIQUE,
                title TEXT,
                account_id INTEGER,
                joined_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS keywords (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                text TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            );
            INSERT OR IGNORE INTO settings (key, value) VALUES 
                ('join_interval', '120'),
                ('send_interval', '3600'),
                ('admin_message', '你好，请直接说明来意');

            CREATE TABLE IF NOT EXISTS account_groups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE
            );
            CREATE TABLE IF NOT EXISTS account_group_members (
                account_id INTEGER,
                group_id INTEGER,
                PRIMARY KEY (account_id, group_id),
                FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE,
                FOREIGN KEY (group_id) REFERENCES account_groups(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_type TEXT NOT NULL DEFAULT 'send_ads',
                account_group_id INTEGER NOT NULL,
                start_time TEXT DEFAULT '',
                end_time TEXT DEFAULT '',
                delay_min INTEGER DEFAULT 60,
                delay_max INTEGER DEFAULT 120,
                status TEXT DEFAULT 'pending',
                progress TEXT DEFAULT '{}',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        """)
        await db.commit()

# -------------------- 基础数据库操作 --------------------
async def get_setting(key):
    async with aiosqlite.connect(DB_PATH) as db:
        c = await db.execute("SELECT value FROM settings WHERE key=?", (key,))
        r = await c.fetchone()
        return r[0] if r else ""

async def set_setting(key, value):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?,?)", (key, value))
        await db.commit()

async def add_account(phone='', session_string='', user_id=None, session_file='', tdata_path='', password=''):
    async with aiosqlite.connect(DB_PATH) as db:
        if user_id:
            c = await db.execute("SELECT id FROM accounts WHERE user_id=?", (user_id,))
            exist = await c.fetchone()
            if exist:
                await db.execute("UPDATE accounts SET phone=?, session_string=?, session_file=?, tdata_path=?, password=? WHERE user_id=?",
                                 (phone, session_string, session_file, tdata_path, password, user_id))
                await db.commit()
                return exist[0]
        c = await db.execute("INSERT INTO accounts (phone, session_string, user_id, session_file, tdata_path, password) VALUES (?,?,?,?,?,?)",
                             (phone, session_string, user_id, session_file, tdata_path, password))
        await db.commit()
        return c.lastrowid

async def get_active_accounts():
    async with aiosqlite.connect(DB_PATH) as db:
        c = await db.execute("SELECT id, phone, session_string, user_id, session_file, tdata_path, password FROM accounts WHERE is_active=1")
        return await c.fetchall()

async def is_user_exists(user_id):
    async with aiosqlite.connect(DB_PATH) as db:
        c = await db.execute("SELECT 1 FROM accounts WHERE user_id=?", (user_id,))
        return await c.fetchone() is not None

async def add_group(group_id, title, account_id):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT OR IGNORE INTO groups (group_id, title, account_id) VALUES (?,?,?)", (group_id, title, account_id))
        await db.commit()

async def get_groups_for_account(account_id):
    async with aiosqlite.connect(DB_PATH) as db:
        c = await db.execute("SELECT group_id FROM groups WHERE account_id=?", (account_id,))
        rows = await c.fetchall()
        return [r[0] for r in rows]

async def get_all_keywords():
    async with aiosqlite.connect(DB_PATH) as db:
        c = await db.execute("SELECT text FROM keywords")
        rows = await c.fetchall()
        return [r[0] for r in rows]

async def add_keyword(text):
    async with aiosqlite.connect(DB_PATH) as db:
        # 去重
        c = await db.execute("SELECT 1 FROM keywords WHERE text=?", (text,))
        if await c.fetchone():
            return False
        await db.execute("INSERT INTO keywords (text) VALUES (?)", (text,))
        await db.commit()
        return True

async def remove_keyword(text):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM keywords WHERE text=?", (text,))
        await db.commit()

async def remove_group(group_id):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM groups WHERE group_id=?", (group_id,))
        await db.commit()

# -------------------- 分组操作 --------------------
async def create_group(name):
    async with aiosqlite.connect(DB_PATH) as db:
        try:
            await db.execute("INSERT INTO account_groups (name) VALUES (?)", (name,))
            await db.commit()
            return True
        except:
            return False

async def get_all_groups():
    async with aiosqlite.connect(DB_PATH) as db:
        c = await db.execute("SELECT id, name FROM account_groups ORDER BY id")
        rows = await c.fetchall()
        return [{"id": r[0], "name": r[1]} for r in rows]

async def delete_group(group_id):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM account_group_members WHERE group_id=?", (group_id,))
        await db.execute("DELETE FROM account_groups WHERE id=?", (group_id,))
        await db.commit()

async def add_account_to_group(account_id, group_id):
    async with aiosqlite.connect(DB_PATH) as db:
        try:
            await db.execute("INSERT OR IGNORE INTO account_group_members (account_id, group_id) VALUES (?,?)", (account_id, group_id))
            await db.commit()
            return True
        except:
            return False

async def remove_account_from_group(account_id, group_id):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM account_group_members WHERE account_id=? AND group_id=?", (account_id, group_id))
        await db.commit()

async def get_group_accounts(group_id):
    async with aiosqlite.connect(DB_PATH) as db:
        c = await db.execute("""
            SELECT a.id, a.phone, a.session_string, a.user_id FROM accounts a
            JOIN account_group_members agm ON a.id = agm.account_id
            WHERE agm.group_id = ? AND a.is_active = 1
        """, (group_id,))
        rows = await c.fetchall()
        return [{"id": r[0], "phone": r[1], "session_string": r[2], "user_id": r[3]} for r in rows]

# -------------------- 任务操作 --------------------
async def create_task(account_group_id, start_time, end_time, delay_min, delay_max):
    async with aiosqlite.connect(DB_PATH) as db:
        c = await db.execute("INSERT INTO tasks (account_group_id, start_time, end_time, delay_min, delay_max, status) VALUES (?,?,?,?,?, 'pending')",
                             (account_group_id, start_time, end_time, delay_min, delay_max))
        await db.commit()
        return c.lastrowid

async def get_all_tasks():
    async with aiosqlite.connect(DB_PATH) as db:
        c = await db.execute("SELECT id, account_group_id, start_time, end_time, delay_min, delay_max, status FROM tasks ORDER BY id DESC")
        rows = await c.fetchall()
        return [{"id": r[0], "account_group_id": r[1], "start_time": r[2], "end_time": r[3], "delay_min": r[4], "delay_max": r[5], "status": r[6]} for r in rows]

async def get_task(task_id):
    async with aiosqlite.connect(DB_PATH) as db:
        c = await db.execute("SELECT * FROM tasks WHERE id=?", (task_id,))
        row = await c.fetchone()
        if row:
            return {"id": row[0], "account_group_id": row[2], "start_time": row[3], "end_time": row[4], "delay_min": row[5], "delay_max": row[6], "status": row[7]}
        return None

async def update_task_status(task_id, status):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE tasks SET status=? WHERE id=?", (status, task_id))
        await db.commit()

async def delete_task(task_id):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM tasks WHERE id=?", (task_id,))
        await db.commit()

# -------------------- 协议处理 --------------------
async def process_session_file(file_path):
    try:
        from telethon import TelegramClient as TelethonClient
        from telethon.sessions import StringSession
        client = TelethonClient(file_path, API_ID, API_HASH)
        await client.connect()
        if not await client.is_user_authorized():
            await client.disconnect()
            return None, None
        me = await client.get_me()
        tsession_str = StringSession.save(client.session)
        await client.disconnect()
        return tsession_str, me.id
    except ImportError:
        logger.error("telethon未安装")
        return None, None
    except Exception as e:
        logger.error(f"session转换失败: {e}")
        return None, None

async def process_tdata_dir(tdata_path):
    try:
        from opentele.td import TDesktop
        from opentele.tl import TelegramClient as TClient
        tdesk = await TDesktop.FromDirectory(tdata_path)
        if not tdesk: return None, None
        tc = await TClient.FromTDesktop(tdesk)
        await tc.connect()
        if not await tc.is_user_authorized():
            await tc.disconnect()
            return None, None
        me = await tc.get_me()
        from pyrogram.storage import Storage
        ss = Storage.SessionStorage.stringify(tc._tg.session.dc_id, tc._tg.session.auth_key, me.id, False)
        uid = me.id
        await tc.disconnect()
        return ss, uid
    except ImportError:
        logger.error("opentele未安装")
        return None, None
    except Exception as e:
        logger.error(f"tdata转换失败: {e}")
        return None, None

# -------------------- 群发任务执行 --------------------
async def run_send_task(task_id):
    task = await get_task(task_id)
    if not task:
        return
    await update_task_status(task_id, "running")
    accounts = await get_group_accounts(task["account_group_id"])
    if not accounts:
        await update_task_status(task_id, "failed")
        return

    stop_event = asyncio.Event()
    active_tasks[task_id] = {"stop_event": stop_event, "clients": []}

    # 解析时间范围
    start = None
    end = None
    if task["start_time"]:
        try:
            start = datetime.strptime(task["start_time"], "%Y-%m-%d %H:%M")
        except:
            pass
    if task["end_time"]:
        try:
            end = datetime.strptime(task["end_time"], "%Y-%m-%d %H:%M")
        except:
            pass

    async def account_worker(account, client):
        try:
            while not stop_event.is_set():
                # 检查时间范围
                now = datetime.now()
                if start and now < start:
                    wait = (start - now).total_seconds()
                    if wait > 0:
                        try:
                            await asyncio.wait_for(stop_event.wait(), timeout=min(wait, 60))
                        except asyncio.TimeoutError:
                            continue
                        if stop_event.is_set():
                            break
                if end and now > end:
                    # 超过结束时间，退出循环
                    break

                # 获取该账号已加入的群
                groups = await get_groups_for_account(account["id"])
                if not groups:
                    await asyncio.sleep(60)
                    continue

                # 随机关键词
                keywords = await get_all_keywords()
                if not keywords:
                    await asyncio.sleep(60)
                    continue

                k = random.choice(keywords)
                g = random.choice(groups)
                try:
                    await client.send_message(g, k)
                    logger.info(f"任务{task_id} 账号{account['id']} 发送到{g}")
                except FloodWait as e:
                    await asyncio.sleep(e.value)
                except Exception as e:
                    logger.error(f"发送失败: {e}")

                # 随机延时
                delay = random.randint(task["delay_min"], task["delay_max"])
                try:
                    await asyncio.wait_for(stop_event.wait(), timeout=delay)
                    break  # stop_event被设置
                except asyncio.TimeoutError:
                    pass
        except asyncio.CancelledError:
            pass
        finally:
            try:
                await client.disconnect()
            except:
                pass

    # 启动每个账号的客户端
    for acc in accounts:
        if stop_event.is_set():
            break
        try:
            client = Client(
                name=f"task_{task_id}_{acc['id']}",
                api_id=API_ID,
                api_hash=API_HASH,
                session_string=acc["session_string"],
                in_memory=True
            )
            await client.start()
            # 注册自动回复
            @client.on_message(filters.private & ~filters.me)
            async def auto_reply(c, m):
                msg = await get_setting("admin_message")
                try:
                    await m.reply_text(msg)
                except FloodWait as e:
                    await asyncio.sleep(e.value)
            active_tasks[task_id]["clients"].append(client)
            asyncio.create_task(account_worker(acc, client))
        except Exception as e:
            logger.error(f"启动客户端失败 account {acc['id']}: {e}")

    # 等待停止
    await stop_event.wait()
    # 清理
    for c in active_tasks[task_id].get("clients", []):
        try:
            await c.disconnect()
        except:
            pass
    await update_task_status(task_id, "completed")
    active_tasks.pop(task_id, None)

async def stop_task(task_id):
    if task_id not in active_tasks:
        return False
    active_tasks[task_id]["stop_event"].set()
    return True

# -------------------- Bot 界面 --------------------
async def start_cmd(bot, msg):
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("📱 添加协议号", callback_data="menu_add")],
        [InlineKeyboardButton("📋 账号列表", callback_data="list_acc")],
        [InlineKeyboardButton("📂 分组管理", callback_data="menu_groups")],
        [InlineKeyboardButton("📥 批量加群", callback_data="batch_join_btn")],
        [InlineKeyboardButton("🔑 关键词管理", callback_data="menu_kw")],
        [InlineKeyboardButton("⚙️ 设置", callback_data="menu_set")],
        [InlineKeyboardButton("🚀 创建引流任务", callback_data="create_task_menu")],
        [InlineKeyboardButton("🛑 停止任务", callback_data="stop_tasks_menu")],
    ])
    await msg.reply_text("主菜单", reply_markup=kb)

async def handle_callback(bot, call: CallbackQuery):
    data = call.data
    uid = call.from_user.id

    # 添加协议号菜单
    if data == "menu_add":
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("📁 上传ZIP", callback_data="add_zip")],
            [InlineKeyboardButton("📞 手机号登录", callback_data="add_phone")],
            [InlineKeyboardButton("🔙 返回", callback_data="back_main")]
        ])
        await call.message.edit_text("选择添加方式", reply_markup=kb)
    elif data == "add_zip":
        await call.message.edit_text("请直接发送包含 tdata 或 .session 的 zip 文件")
        user_states[uid] = "wait_zip"
    elif data == "add_phone":
        await call.message.edit_text("请输入手机号 (带国家代码，如 +86138...):")
        user_states[uid] = "wait_phone"

    # 账号列表
    elif data == "list_acc":
        accs = await get_active_accounts()
        if not accs:
            await call.message.edit_text("没有账号", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 返回", callback_data="back_main")]]))
            return
        text = "账号列表:\n"
        for a in accs:
            label = a[1] if a[1] else f"ID:{a[3]}"
            text += f"• {label}\n"
        await call.message.edit_text(text, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 返回", callback_data="back_main")]]))

    # 分组管理
    elif data == "menu_groups":
        groups = await get_all_groups()
        text = "📂 分组管理\n"
        if groups:
            for g in groups:
                text += f"• {g['name']} (ID:{g['id']})\n"
        else:
            text += "暂无分组\n"
        buttons = [
            [InlineKeyboardButton("➕ 创建分组", callback_data="grp_create")],
            [InlineKeyboardButton("➕ 添加账号", callback_data="grp_add_account")],
            [InlineKeyboardButton("➖ 移除账号", callback_data="grp_remove_account")],
            [InlineKeyboardButton("👁 查看分组", callback_data="grp_view")],
            [InlineKeyboardButton("🗑 删除分组", callback_data="grp_delete")],
            [InlineKeyboardButton("🔙 返回", callback_data="back_main")],
        ]
        await call.message.edit_text(text, reply_markup=InlineKeyboardMarkup(buttons))

    elif data == "grp_create":
        await call.message.edit_text("请输入新分组名称：")
        user_states[uid] = "wait_group_name"
    elif data == "grp_add_account":
        groups = await get_all_groups()
        if not groups:
            await call.answer("请先创建分组", alert=True)
            return
        btns = [[InlineKeyboardButton(g['name'], callback_data=f"grpadd_{g['id']}")] for g in groups]
        btns.append([InlineKeyboardButton("🔙 返回", callback_data="menu_groups")])
        await call.message.edit_text("选择目标分组：", reply_markup=InlineKeyboardMarkup(btns))
    elif data.startswith("grpadd_"):
        gid = int(data.split("_")[1])
        accs = await get_active_accounts()
        if not accs:
            await call.answer("没有可用账号", alert=True)
            return
        btns = [[InlineKeyboardButton(a[1] or f"ID:{a[3]}", callback_data=f"grpaddacc_{gid}_{a[0]}")] for a in accs]
        btns.append([InlineKeyboardButton("🔙 返回", callback_data="menu_groups")])
        await call.message.edit_text("选择账号：", reply_markup=InlineKeyboardMarkup(btns))
    elif data.startswith("grpaddacc_"):
        _, gid, aid = data.split("_")
        await add_account_to_group(int(aid), int(gid))
        await call.answer("已添加")
        await handle_callback(bot, call)  # 刷新
    elif data == "grp_remove_account":
        groups = await get_all_groups()
        btns = [[InlineKeyboardButton(g['name'], callback_data=f"grprem_{g['id']}")] for g in groups]
        btns.append([InlineKeyboardButton("🔙 返回", callback_data="menu_groups")])
        await call.message.edit_text("选择分组：", reply_markup=InlineKeyboardMarkup(btns))
    elif data.startswith("grprem_"):
        gid = int(data.split("_")[1])
        accs = await get_group_accounts(gid)
        if not accs:
            await call.answer("该分组无账号")
            return
        btns = [[InlineKeyboardButton(a['phone'] or f"ID:{a['user_id']}", callback_data=f"grpremacc_{gid}_{a['id']}")] for a in accs]
        btns.append([InlineKeyboardButton("🔙 返回", callback_data="menu_groups")])
        await call.message.edit_text("选择要移除的账号：", reply_markup=InlineKeyboardMarkup(btns))
    elif data.startswith("grpremacc_"):
        _, gid, aid = data.split("_")
        await remove_account_from_group(int(aid), int(gid))
        await call.answer("已移除")
        await handle_callback(bot, call)
    elif data == "grp_view":
        groups = await get_all_groups()
        btns = [[InlineKeyboardButton(g['name'], callback_data=f"grpview_{g['id']}")] for g in groups]
        btns.append([InlineKeyboardButton("🔙 返回", callback_data="menu_groups")])
        await call.message.edit_text("选择查看分组：", reply_markup=InlineKeyboardMarkup(btns))
    elif data.startswith("grpview_"):
        gid = int(data.split("_")[1])
        accs = await get_group_accounts(gid)
        text = "账号列表:\n"
        if accs:
            for a in accs:
                text += f"• {a['phone'] or a['user_id']}\n"
        else:
            text += "空"
        await call.message.edit_text(text, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 返回", callback_data="menu_groups")]]))
    elif data == "grp_delete":
        groups = await get_all_groups()
        btns = [[InlineKeyboardButton(g['name'], callback_data=f"grpdel_{g['id']}")] for g in groups]
        btns.append([InlineKeyboardButton("🔙 返回", callback_data="menu_groups")])
        await call.message.edit_text("选择删除分组：", reply_markup=InlineKeyboardMarkup(btns))
    elif data.startswith("grpdel_"):
        gid = int(data.split("_")[1])
        await delete_group(gid)
        await call.answer("已删除")
        await handle_callback(bot, call)

    # 批量加群
    elif data == "batch_join_btn":
        accs = await get_active_accounts()
        if not accs:
            await call.message.edit_text("没有可用的账号", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 返回", callback_data="back_main")]]))
            return
        buttons = []
        for a in accs:
            label = a[1] if a[1] else f"ID:{a[3]}"
            buttons.append([InlineKeyboardButton(label, callback_data=f"joinonly_{a[3]}")])
        buttons.append([InlineKeyboardButton("🔙 返回", callback_data="back_main")])
        await call.message.edit_text("选择要用来加群的账号", reply_markup=InlineKeyboardMarkup(buttons))
    elif data.startswith("joinonly_"):
        target_uid = int(data.split("_")[1])
        user_states[uid] = ("wait_links_joinonly", target_uid)
        await call.message.edit_text("请发送群链接列表（多个用逗号分隔）:")

    # 关键词管理
    elif data == "menu_kw":
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("➕ 批量添加 (空格隔开)", callback_data="kw_add")],
            [InlineKeyboardButton("➖ 删除", callback_data="kw_del")],
            [InlineKeyboardButton("📄 查看列表", callback_data="kw_list")],
            [InlineKeyboardButton("🔙 返回", callback_data="back_main")]
        ])
        await call.message.edit_text("关键词管理", reply_markup=kb)
    elif data == "kw_add":
        await call.message.edit_text("请发送关键词，用空格隔开，可批量添加：")
        user_states[uid] = "wait_kw_add"
    elif data == "kw_del":
        await call.message.edit_text("发送要删除的关键词：")
        user_states[uid] = "wait_kw_del"
    elif data == "kw_list":
        kw = await get_all_keywords()
        text = "关键词列表:\n" + "\n".join(kw) if kw else "关键词为空"
        await call.message.edit_text(text, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 返回", callback_data="menu_kw")]]))

    # 设置
    elif data == "menu_set":
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("⏱ 加群间隔", callback_data="set_join")],
            [InlineKeyboardButton("⏱ 群发间隔", callback_data="set_send")],
            [InlineKeyboardButton("💬 自动回复话术", callback_data="set_msg")],
            [InlineKeyboardButton("🔙 返回", callback_data="back_main")]
        ])
        await call.message.edit_text("设置", reply_markup=kb)
    elif data.startswith("set_"):
        key_map = {"set_join": ("join_interval", "加群间隔(秒)"), "set_send": ("send_interval", "群发间隔(秒)"), "set_msg": ("admin_message", "自动回复内容")}
        key, desc = key_map[data]
        await call.message.edit_text(f"请输入新的 {desc}:")
        user_states[uid] = ("wait_set", key)

    # 创建引流任务
    elif data == "create_task_menu":
        groups = await get_all_groups()
        if not groups:
            await call.answer("请先创建分组并添加账号", alert=True)
            return
        btns = [[InlineKeyboardButton(g['name'], callback_data=f"taskgroup_{g['id']}")] for g in groups]
        btns.append([InlineKeyboardButton("🔙 返回", callback_data="back_main")])
        await call.message.edit_text("选择账号分组：", reply_markup=InlineKeyboardMarkup(btns))
    elif data.startswith("taskgroup_"):
        gid = int(data.split("_")[1])
        user_states[uid] = ("wait_task_time", gid)
        await call.message.edit_text("请输入时间范围 (格式: 开始时间-结束时间, 如 2026-08-11 08:00-2026-08-11 20:00)\n或发送 `无` 不限时间：")
    elif data == "stop_tasks_menu":
        tasks = await get_all_tasks()
        running = [t for t in tasks if t["status"] == "running"]
        if not running:
            await call.message.edit_text("没有正在运行的任务", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 返回", callback_data="back_main")]]))
            return
        btns = [[InlineKeyboardButton(f"任务#{t['id']} (分组{t['account_group_id']})", callback_data=f"stoptask_{t['id']}")] for t in running]
        btns.append([InlineKeyboardButton("🔙 返回", callback_data="back_main")])
        await call.message.edit_text("正在运行的任务，点击停止：", reply_markup=InlineKeyboardMarkup(btns))
    elif data.startswith("stoptask_"):
        task_id = int(data.split("_")[1])
        ok = await stop_task(task_id)
        if ok:
            await call.answer("已发送停止信号")
        else:
            await call.answer("任务不存在")
        await handle_callback(bot, call)  # 刷新

    # 返回主菜单
    elif data == "back_main":
        user_states.pop(uid, None)
        await call.message.edit_text("主菜单", reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("📱 添加协议号", callback_data="menu_add")],
            [InlineKeyboardButton("📋 账号列表", callback_data="list_acc")],
            [InlineKeyboardButton("📂 分组管理", callback_data="menu_groups")],
            [InlineKeyboardButton("📥 批量加群", callback_data="batch_join_btn")],
            [InlineKeyboardButton("🔑 关键词管理", callback_data="menu_kw")],
            [InlineKeyboardButton("⚙️ 设置", callback_data="menu_set")],
            [InlineKeyboardButton("🚀 创建引流任务", callback_data="create_task_menu")],
            [InlineKeyboardButton("🛑 停止任务", callback_data="stop_tasks_menu")],
        ]))
    await call.answer()

# -------------------- 文本消息处理 --------------------
async def handle_text(bot, msg: Message):
    uid = msg.from_user.id
    state = user_states.get(uid)
    if not state:
        return

    text = msg.text.strip()

    # 手机号登录流程
    if state == "wait_phone":
        phone = text
        await msg.reply_text("正在请求验证码...")
        client = Client(name=f"tmp_{phone}", api_id=API_ID, api_hash=API_HASH, phone_number=phone, in_memory=True)
        try:
            await client.connect()
            sent = await client.send_code(phone)
            user_states[uid] = ("wait_code", phone, sent.phone_code_hash, client)
            await msg.reply_text("验证码已发送，请输入收到的验证码:")
        except Exception as e:
            await msg.reply_text(f"失败: {e}")
            await client.disconnect()
            user_states.pop(uid, None)

    elif isinstance(state, tuple) and state[0] == "wait_code":
        _, phone, code_hash, client = state
        code = text
        try:
            await client.sign_in(phone, code_hash, code)
            ss = await client.export_session_string()
            me = await client.get_me()
            if await is_user_exists(me.id):
                await msg.reply_text("该账号已存在，已更新。")
            await add_account(phone=phone, session_string=ss, user_id=me.id)
            await msg.reply_text(f"✅ {phone} 登录成功")
            await client.disconnect()
            user_states.pop(uid, None)
        except SessionPasswordNeeded:
            user_states[uid] = ("wait_2fa", phone, code_hash, client)
            await msg.reply_text("该账号已启用两步验证，请输入二级密码:")
        except Exception as e:
            await msg.reply_text(f"登录失败: {e}")
            await client.disconnect()
            user_states.pop(uid, None)

    elif isinstance(state, tuple) and state[0] == "wait_2fa":
        _, phone, code_hash, client = state
        password = text
        try:
            await client.check_password(password)
            ss = await client.export_session_string()
            me = await client.get_me()
            if await is_user_exists(me.id):
                await msg.reply_text("该账号已存在，已更新。")
            await add_account(phone=phone, session_string=ss, user_id=me.id)
            await msg.reply_text(f"✅ {phone} 登录成功")
            await client.disconnect()
        except Exception as e:
            await msg.reply_text(f"二级密码验证失败: {e}")
        finally:
            user_states.pop(uid, None)
            try: await client.disconnect()
            except: pass

    # ZIP等待
    elif state == "wait_zip":
        await msg.reply_text("请发送 zip 文件，不是文本。")

    # 关键词批量添加（空格分隔）
    elif state == "wait_kw_add":
        parts = text.split()
        added = 0
        skipped = 0
        for word in parts:
            if word:
                if await add_keyword(word):
                    added += 1
                else:
                    skipped += 1
        await msg.reply_text(f"✅ 添加 {added} 个，跳过 {skipped} 个（已存在）")
        user_states.pop(uid, None)

    elif state == "wait_kw_del":
        await remove_keyword(text)
        await msg.reply_text(f"已删除关键词: {text}")
        user_states.pop(uid, None)

    elif isinstance(state, tuple) and state[0] == "wait_set":
        key = state[1]
        await set_setting(key, text)
        await msg.reply_text("设置已更新")
        user_states.pop(uid, None)

    # 分组名称输入
    elif state == "wait_group_name":
        if await create_group(text):
            await msg.reply_text(f"分组 '{text}' 创建成功")
        else:
            await msg.reply_text("分组已存在或失败")
        user_states.pop(uid, None)

    # 群发任务时间输入
    elif isinstance(state, tuple) and state[0] == "wait_task_time":
        gid = state[1]
        if text == "无":
            start = end = ""
        else:
            try:
                parts = text.split("-")
                start = parts[0].strip()
                end = parts[1].strip() if len(parts) > 1 else ""
            except:
                await msg.reply_text("格式错误，请重新输入或发送 `无`")
                return
        user_states[uid] = ("wait_task_delay", gid, start, end)
        await msg.reply_text("请输入群发间隔范围 (秒)，例如 60-180：")

    elif isinstance(state, tuple) and state[0] == "wait_task_delay":
        gid, start, end = state[1], state[2], state[3]
        try:
            parts = text.split("-")
            dmin = int(parts[0])
            dmax = int(parts[1]) if len(parts) > 1 else dmin
        except:
            await msg.reply_text("格式错误，请重新输入")
            return
        task_id = await create_task(gid, start, end, dmin, dmax)
        user_states.pop(uid, None)
        await msg.reply_text(f"任务 #{task_id} 已创建，将自动运行。")
        # 立即启动任务
        asyncio.create_task(run_send_task(task_id))

    # 批量加群（仅加群）
    elif isinstance(state, tuple) and state[0] == "wait_links_joinonly":
        target_uid = state[1]
        links = [l.strip() for l in text.split(",") if l.strip()]
        user_states.pop(uid, None)
        accs = await get_active_accounts()
        session_str = phone = account_db_id = None
        for a in accs:
            if a[3] == target_uid:
                account_db_id = a[0]
                session_str = a[2]
                phone = a[1]
                break
        if not session_str:
            await msg.reply_text("账号未找到")
            return
        client = Client(name=f"join_{phone}", api_id=API_ID, api_hash=API_HASH, session_string=session_str, in_memory=True)
        await client.start()
        join_int = int(await get_setting("join_interval"))
        await msg.reply_text(f"开始批量加群，间隔 {join_int} 秒...")
        count = 0
        for link in links:
            try:
                if link.startswith("https://t.me/+"):
                    chat = await client.join_chat(link.split("/+")[-1])
                else:
                    u = re.sub(r"https?://t\.me/", "", link).lstrip("@")
                    chat = await client.join_chat(u)
                if chat:
                    await add_group(chat.id, chat.title, account_db_id)
                    count += 1
            except FloodWait as e:
                await asyncio.sleep(e.value)
            except:
                pass
            await asyncio.sleep(join_int)
        await client.disconnect()
        await msg.reply_text(f"加群完成，成功加入 {count} 个群。")

# -------------------- 文件上传处理（ZIP） --------------------
async def handle_document(bot, msg: Message):
    uid = msg.from_user.id
    if user_states.get(uid) != "wait_zip":
        return
    if not msg.document.file_name.lower().endswith('.zip'):
        await msg.reply_text("请发送 zip 文件")
        return
    await msg.reply_text("处理中...")
    try:
        fp = await msg.download(in_memory=False)
        extract = tempfile.mkdtemp()
        with zipfile.ZipFile(fp, 'r') as z:
            z.extractall(extract)

        tdata_dirs = []
        session_files = []
        for root, dirs, files in os.walk(extract):
            if os.path.basename(root) == 'tdata':
                tdata_dirs.append(root)
            for f in files:
                if f.endswith('.session'):
                    session_files.append(os.path.join(root, f))

        processed_uids = set()
        success = 0
        duplicates = 0
        failures = []

        for sf in session_files:
            ss, user_id = await process_session_file(sf)
            if ss and user_id:
                if user_id in processed_uids or await is_user_exists(user_id):
                    duplicates += 1
                else:
                    dest = os.path.join(UPLOAD_DIR, "sessions", os.path.basename(sf))
                    shutil.copy2(sf, dest)
                    await add_account(phone='', session_string=ss, user_id=user_id, session_file=dest)
                    success += 1
                    processed_uids.add(user_id)
            else:
                failures.append(os.path.basename(sf))

        for td in tdata_dirs:
            ss, user_id = await process_tdata_dir(td)
            if ss and user_id:
                if user_id in processed_uids or await is_user_exists(user_id):
                    duplicates += 1
                else:
                    dest = os.path.join(UPLOAD_DIR, "tdata", f"tdata_{user_id}_{int(time.time())}")
                    shutil.move(td, dest)
                    await add_account(phone='', session_string=ss, user_id=user_id, tdata_path=dest)
                    success += 1
                    processed_uids.add(user_id)
            else:
                failures.append(os.path.basename(td))

        os.remove(fp)
        shutil.rmtree(extract, ignore_errors=True)

        text = f"✅ 导入成功: {success} 个账号"
        if duplicates > 0:
            text += f"\n⚠️ 重复跳过: {duplicates} 个"
        if failures:
            text += f"\n❌ 失败: {', '.join(failures)}"
        await msg.reply_text(text)

    except Exception as e:
        await msg.reply_text(f"处理失败: {e}")
    finally:
        user_states.pop(uid, None)

# -------------------- 主函数 --------------------
async def main():
    await init_db()
    bot = Client("control_bot", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)

    @bot.on_message(filters.command("start"))
    async def _start(c, m): await start_cmd(c, m)

    @bot.on_callback_query()
    async def _cb(c, q): await handle_callback(c, q)

    @bot.on_message(filters.text & filters.private)
    async def _text(c, m): await handle_text(c, m)

    @bot.on_message(filters.document & filters.private)
    async def _doc(c, m): await handle_document(c, m)

    await bot.start()
    logger.info("Bot已启动")
    await asyncio.Event().wait()

if __name__ == "__main__":
    asyncio.run(main())