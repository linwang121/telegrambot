import re
import logging
import requests
from collections import deque
from telegram import Update, ReplyKeyboardMarkup, InlineKeyboardButton, InlineKeyboardMarkup, ChatMember
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters,
    ContextTypes,
)

# ---------- 配置 ----------
BOT_TOKEN = "8868934756:AAFi20GpQzH2vLZaPkR81PLWBWeqIy0E74s"
PRIVATE_ADMIN_ID = 8348578747
GROUP_ADMIN_ID = 8299497984
ADMIN_IDS = {PRIVATE_ADMIN_ID, GROUP_ADMIN_ID}

user_sessions = {}
group_data = {}
trade_states = {}
admin_target = {}
chat_messages = {}
group_messages = {}
pinned_msg = {}

USDT_CNY_RATE = 7.25

# ---------- 用户/黑名单/消息ID追踪 ----------
known_users = {}
user_message_ids = {}
blacklist = set()
admin_action_state = {}

logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)


def remove_smileys(text: str) -> str:
    smiley_pattern = re.compile("[\U0001F600-\U0001F64F]+", re.UNICODE)
    return smiley_pattern.sub(r'', text).strip()


def replace_username(text: str) -> str:
    return text.replace("@daIilzhuanqun", '<a href="https://t.me/dalizhuanpunbot">@diao</a>')


EMOJI_IDS = {
    "1": "6179171291296174866",
    "2": "6179334375499372036",
    "3": "6181519362801800353",
    "4": "6179321589381731082",
    "5": "6179065042395206954",
    "6": "6181432960944706427",
}


def build_welcome_caption(member_name: str) -> str:
    lines = [
        f'<tg-emoji emoji-id="{EMOJI_IDS["1"]}" alt="😃">😃</tg-emoji>🎉欢迎 {member_name} 加入专群',
        f'<tg-emoji emoji-id="{EMOJI_IDS["2"]}" alt="😃">😃</tg-emoji>，首先感谢您对达利担保的信任与支持',
        f'<tg-emoji emoji-id="{EMOJI_IDS["3"]}" alt="😃">😃</tg-emoji>，请遵循达利担保专群的以下交易规则',
        f'<tg-emoji emoji-id="{EMOJI_IDS["4"]}" alt="😃">😃</tg-emoji>，请双方认真商定本次交易内容与规则',
        f'<tg-emoji emoji-id="{EMOJI_IDS["5"]}" alt="😃">😃</tg-emoji>，交易规则入档时请仔细复审后再确认',
        f'<tg-emoji emoji-id="{EMOJI_IDS["6"]}" alt="😃">😃</tg-emoji>，交易期间不要更改您的昵称与用户名',
        "😃，转账仔细核对达利专群唯一上押地址"
    ]
    return "\n".join(lines)


MAIN_KEYBOARD = ReplyKeyboardMarkup(
    [["👤人工客服", "✅防骗专区"],
     ["达利官方人员", "达利官方地址"]],
    resize_keyboard=True
)

ADMIN_KEYBOARD = ReplyKeyboardMarkup(
    [["👤人工客服", "✅防骗专区"],
     ["达利官方人员", "达利官方地址"],
     ["🗑删消息", "🚫黑名单管理"]],
    resize_keyboard=True
)


# ---------- 辅助函数 ----------
def track_user(user):
    if not user:
        return
    known_users[user.id] = {
        "full_name": user.full_name or "",
        "username": user.username or "",
    }


def track_message_id(user_id, chat_id, message_id):
    if user_id is None or message_id is None:
        return
    if user_id not in user_message_ids:
        user_message_ids[user_id] = []
    user_message_ids[user_id].append((chat_id, message_id))


async def delete_all_user_messages(context, user_id):
    if user_id not in user_message_ids:
        return 0, 0
    records = list(user_message_ids[user_id])
    unique = []
    seen = set()
    for chat_id, message_id in records:
        key = (chat_id, message_id)
        if key not in seen:
            seen.add(key)
            unique.append(key)

    success = 0
    failed = 0
    for chat_id, message_id in unique:
        try:
            await context.bot.delete_message(chat_id=chat_id, message_id=message_id)
            success += 1
        except Exception:
            failed += 1
    user_message_ids[user_id] = []
    return success, failed


def find_user_by_query(query: str):
    q = query.strip()
    if q.startswith("@"):
        q = q[1:]
    q = q.strip()
    if not q:
        return None
    if q.isdigit():
        uid = int(q)
        return uid if uid in known_users else None
    ql = q.lower()
    for uid, info in known_users.items():
        if (info.get("username") or "").lower() == ql:
            return uid
    return None


async def show_user_manage_menu(message, uid: int):
    info = known_users.get(uid, {"full_name": "未知", "username": ""})
    uname = f"@{info['username']}" if info.get("username") else "无用户名"
    is_bl = uid in blacklist
    status = "🚫 已拉黑" if is_bl else "✅ 正常"
    text = (
        f"👤 用户信息\n"
        f"━━━━━━━━━━━━━━━\n"
        f"ID：{uid}\n"
        f"昵称：{info.get('full_name', '未知')}\n"
        f"用户名：{uname}\n"
        f"状态：{status}"
    )
    toggle_text = "✅ 解除拉黑" if is_bl else "🚫 拉黑该用户"
    keyboard = [
        [InlineKeyboardButton(toggle_text, callback_data=f"togglebl_{uid}")],
        [InlineKeyboardButton("🗑 删除该用户聊天记录", callback_data=f"delchat_{uid}")],
    ]
    await message.reply_text(text, reply_markup=InlineKeyboardMarkup(keyboard))


# ---------- 原有函数 ----------
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if user.id in blacklist and user.id not in ADMIN_IDS:
        return
    track_user(user)

    if user.id in ADMIN_IDS:
        keyboard = [
            [InlineKeyboardButton("在线用户", callback_data="online_users"),
             InlineKeyboardButton("查看群组", callback_data="admin_chats")]
        ]
        await update.message.reply_text("管理面板，请选择操作：", reply_markup=InlineKeyboardMarkup(keyboard))
        # 静默弹出底部轮盘（无提示文字）
        await update.message.reply_text("\u200b", reply_markup=ADMIN_KEYBOARD)
    else:
        caption = (
            '👋 您好！欢迎咨询达利专群，先点击查看防骗专区，如需人工服务，请输入 人工客服即可。\n'
            '又或者请点击👇人工客服按钮。'
        )
        caption = replace_username(caption)
        sent = await context.bot.send_animation(
            chat_id=update.effective_chat.id,
            animation="https://files.catbox.moe/urlp95.mp4",
            caption=caption,
            parse_mode="HTML",
            reply_markup=MAIN_KEYBOARD
        )
        track_message_id(user.id, sent.chat_id, sent.message_id)


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id in blacklist and update.effective_user.id not in ADMIN_IDS:
        return
    if update.effective_user.id in ADMIN_IDS:
        help_text = (
            "管理员命令：\n"
            "/start - 打开管理面板\n"
            "/users - 查看在线用户\n"
            "/admin - 查看群组历史消息\n"
            "/cancel - 退出当前选择\n\n"
            "群组内命令：\n"
            "开群 / 规则 / +金额 / 开始营业 / 清群\n"
            "验群 / 地址 / 汇率"
        )
    else:
        help_text = (
            "可用命令：\n"
            "/start - 开始对话\n"
            "/cancel - 退出客服会话\n\n"
            "您也可以点击下方按钮直接操作。"
        )
    await update.message.reply_text(remove_smileys(help_text))


async def online_users_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if query.from_user.id not in ADMIN_IDS:
        return
    online = [uid for uid, active in user_sessions.items() if active]
    if not online:
        await query.edit_message_text("当前没有用户在线。")
        return
    keyboard = []
    for uid in online:
        try:
            user = await context.bot.get_chat(uid)
            name = user.full_name or str(uid)
        except:
            name = str(uid)
        keyboard.append([
            InlineKeyboardButton(name, callback_data=f"select_{uid}"),
            InlineKeyboardButton("❌", callback_data=f"enduser_{uid}")
        ])
    await query.edit_message_text("请选择要服务的用户（点击名称选择，❌ 结束会话）：", reply_markup=InlineKeyboardMarkup(keyboard))


async def admin_chats_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if query.from_user.id not in ADMIN_IDS:
        return
    all_chats = set(list(chat_messages.keys()) + list(group_data.keys()))
    if not all_chats:
        await query.edit_message_text("暂无群组数据。")
        return
    keyboard = []
    for cid in all_chats:
        try:
            chat = await context.bot.get_chat(cid)
            title = chat.title or str(cid)
        except:
            title = str(cid)
        keyboard.append([InlineKeyboardButton(title, callback_data=f"viewchat_{cid}")])
    await query.edit_message_text("请选择要查看的群组：", reply_markup=InlineKeyboardMarkup(keyboard))


async def handle_private_buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id in blacklist and update.effective_user.id not in ADMIN_IDS:
        return
    track_user(update.effective_user)

    text = update.message.text
    if text == "👤人工客服":
        user_sessions[update.effective_user.id] = True
        reply = (
            "✅ 已成功为您分配客服\n\n"
            "👤 您的专属客服：达利 @daIilzhuanqun 专群客服\n"
            "━━━━━━━━━━━━━━━\n"
            "💬 您现在可以直接输入您的问题\n"
            "⏰ 我们会尽快为您解答"
        )
        reply = replace_username(reply)
        sent = await update.message.reply_text(reply, parse_mode="HTML", reply_markup=MAIN_KEYBOARD)
        track_message_id(update.effective_user.id, sent.chat_id, sent.message_id)
    elif text == "✅防骗专区":
        reply = (
            "需要专群担保请联系 @daIilzhuanqun，打款之前请认真核对工作人员的用户名哦！谨防被骗！\n\n"
            "专群TRC20唯一地址\n"
            "TVJkYBVgJAX8wPNhxrrbt35EeGiQhKeaUc"
        )
        reply = replace_username(reply)
        sent = await update.message.reply_text(reply, parse_mode="HTML")
        track_message_id(update.effective_user.id, sent.chat_id, sent.message_id)
    elif text == "达利官方人员":
        premium_id = "6172210291770660776"
        official_list = (
            "😃 达利担保 😃\n\n"
            "以下是【官方名录】\n"
            "官方客服与群组频道一览公示\n\n"
            "😀😀😀😀😀\n\n"
            "😃 工作人员名单👤\n\n"
            "👤 公群负责人 @jiba\n"
            "👤 公群负责人 @Pigu\n"
            "👤 专群担保客服入口 @daIilzhuanqun\n"
            "👤 纠纷仲裁客服 @erzi\n"
            "👤 纠纷仲裁客服 @qing\n"
            "👤 发布供需客服 @mimi\n\n"
            "😃 官方频道 🏘\n\n"
            "➡️ 公群频道 @DLDB\n"
            "➡️ 供需频道 @yewu\n"
            "➡️ 钱包教程 @dbdb\n"
            "➡️ 高速代理 @daligaosu\n"
            "➡️ 官方频道 @ikun\n\n"
            "😀 达利担保 上押唯一 TRC20 地址\n\n"
            "TVJkYBVgJAX8wPNhxrrbt35EeGiQhKeaUc"
        )
        for emoji_char in ["😃", "😀"]:
            official_list = official_list.replace(
                emoji_char,
                f'<tg-emoji emoji-id="{premium_id}" alt="{emoji_char}">{emoji_char}</tg-emoji>'
            )
        official_list = replace_username(official_list)
        sent = await update.message.reply_text(official_list, parse_mode="HTML")
        track_message_id(update.effective_user.id, sent.chat_id, sent.message_id)
    elif text == "达利官方地址":
        caption = (
            "😀😃😀 达利担保 上押唯一 TRC20 地址😀：\n\n"
            "TVJkYBVgJAX8wPNhxrrbt35EeGiQhKeaUc\n\n"
            "其他地址的专群均为假冒 ❌！"
        )
        caption = replace_username(caption)
        sent = await update.message.reply_photo(
            photo="https://files.catbox.moe/a0eelv.png",
            caption=caption,
            parse_mode="HTML"
        )
        track_message_id(update.effective_user.id, sent.chat_id, sent.message_id)


async def user_forward_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if user.id in blacklist:
        return
    track_user(user)
    track_message_id(user.id, update.effective_chat.id, update.message.message_id)

    if user_sessions.get(user.id):
        username = f"@{user.username}" if user.username else "无用户名"
        admin_msg = (f"📩 来自用户 {user.full_name} {username} (ID: {user.id})\n"
                     f"消息：{update.message.text}")
        await context.bot.send_message(chat_id=PRIVATE_ADMIN_ID, text=admin_msg)


async def admin_reply_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        return
    admin_id = update.effective_user.id

    state = admin_action_state.get(admin_id)
    if state in ("delete_search", "blacklist_search"):
        q = update.message.text.strip()
        uid = find_user_by_query(q)
        if uid is None:
            await update.message.reply_text("❌ 未找到该用户，请确认 ID 或用户名是否正确。")
            return
        admin_action_state.pop(admin_id, None)
        if state == "delete_search":
            success, failed = await delete_all_user_messages(context, uid)
            await update.message.reply_text(
                f"🗑 删除完成\n"
                f"用户 ID：{uid}\n"
                f"✅ 成功删除：{success} 条\n"
                f"⚠️ 删除失败：{failed} 条\n\n"
                f"说明：Telegram Bot API 只能删除 48 小时内的消息，"
                f"且机器人只能删除自己发出的消息和用户在私聊中发给它的消息。"
            )
        else:
            await show_user_manage_menu(update.message, uid)
        return

    if update.message.reply_to_message and update.message.reply_to_message.text:
        match = re.search(r"ID: (\d+)", update.message.reply_to_message.text)
        if match:
            user_id = int(match.group(1))
            reply_text = f"📞 客服回复：\n{update.message.text}"
            sent = await context.bot.send_message(chat_id=user_id, text=reply_text)
            track_message_id(user_id, sent.chat_id, sent.message_id)
            return

    target = admin_target.get(admin_id)
    if target:
        reply_text = f"📞 客服回复：\n{update.message.text}"
        sent = await context.bot.send_message(chat_id=target, text=reply_text)
        track_message_id(target, sent.chat_id, sent.message_id)
    else:
        await update.message.reply_text("未选中任何用户，请先使用 /users 或管理面板选择用户。")


async def select_user_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if query.from_user.id not in ADMIN_IDS:
        return
    data = query.data
    if data.startswith("select_"):
        uid = int(data.split("_")[1])
        admin_target[query.from_user.id] = uid
        await query.edit_message_text(f"已切换到用户 ID {uid}，现在发送的任何消息都将转发给该用户。")


async def end_user_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if query.from_user.id not in ADMIN_IDS:
        return
    data = query.data
    if data.startswith("enduser_"):
        uid = int(data.split("_")[1])
        if uid in user_sessions:
            del user_sessions[uid]
            try:
                sent = await context.bot.send_message(
                    chat_id=uid,
                    text="⚠️ 管理员已结束您的客服会话，感谢您的咨询。"
                )
                track_message_id(uid, sent.chat_id, sent.message_id)
            except:
                pass
        await query.edit_message_text(f"已结束用户 {uid} 的会话。")


async def view_chat_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if query.from_user.id not in ADMIN_IDS:
        return
    data = query.data
    if data.startswith("viewchat_"):
        chat_id = int(data.split("_")[1])
        msgs = chat_messages.get(chat_id, [])
        if not msgs:
            await query.edit_message_text("该群暂无消息记录。")
            return
        history = ""
        for m in list(msgs)[-15:]:
            uname = f"@{m['username']}" if m['username'] else m['user']
            history += f"{uname}: {m['text']}\n"
        await query.edit_message_text(f"群组 {chat_id} 最近消息：\n\n{history}"[:4000])


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id in ADMIN_IDS and user_id in admin_action_state:
        admin_action_state.pop(user_id, None)
        await update.message.reply_text("✅ 已取消当前操作。", reply_markup=ADMIN_KEYBOARD)
        return

    if user_sessions.pop(user_id, None):
        sent = await update.message.reply_text(
            "✅ 会话已结束。\n\n感谢您的咨询！如需帮助，请随时发送 /start 重新开始。",
            reply_markup=MAIN_KEYBOARD,
        )
        track_message_id(user_id, sent.chat_id, sent.message_id)
    else:
        await update.message.reply_text("您当前没有进行中的会话。")


# ---------- 管理员新按钮 ----------
async def handle_admin_new_buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        return
    text = update.message.text
    admin_id = update.effective_user.id

    if text == "🗑删消息":
        admin_action_state[admin_id] = "delete_search"
        await update.message.reply_text(
            "🗑 请输入要删除聊天记录的用户 ID 或用户名（例如 8348578747 或 @username）：\n\n发送 /cancel 取消操作。"
        )
    elif text == "🚫黑名单管理":
        admin_action_state[admin_id] = "blacklist_search"
        await update.message.reply_text(
            "🚫 请输入要操作的用户 ID 或用户名（例如 8348578747 或 @username）：\n\n发送 /cancel 取消操作。"
        )


async def toggle_blacklist_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if query.from_user.id not in ADMIN_IDS:
        await query.answer()
        return
    uid = int(query.data.split("_")[1])
    if uid in blacklist:
        blacklist.discard(uid)
        tip = "✅ 已解除拉黑"
    else:
        blacklist.add(uid)
        tip = "🚫 已拉黑该用户，机器人将不再回复他"
    await query.answer(tip)

    info = known_users.get(uid, {"full_name": "未知", "username": ""})
    uname = f"@{info['username']}" if info.get("username") else "无用户名"
    is_bl = uid in blacklist
    status = "🚫 已拉黑" if is_bl else "✅ 正常"
    text = (
        f"👤 用户信息\n"
        f"━━━━━━━━━━━━━━━\n"
        f"ID：{uid}\n"
        f"昵称：{info.get('full_name', '未知')}\n"
        f"用户名：{uname}\n"
        f"状态：{status}\n\n"
        f"{tip}"
    )
    toggle_text = "✅ 解除拉黑" if is_bl else "🚫 拉黑该用户"
    keyboard = [
        [InlineKeyboardButton(toggle_text, callback_data=f"togglebl_{uid}")],
        [InlineKeyboardButton("🗑 删除该用户聊天记录", callback_data=f"delchat_{uid}")],
    ]
    try:
        await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))
    except:
        pass


async def delete_chat_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if query.from_user.id not in ADMIN_IDS:
        await query.answer()
        return
    uid = int(query.data.split("_")[1])
    success, failed = await delete_all_user_messages(context, uid)
    await query.answer(f"✅ 删除成功：{success} 条，失败：{failed} 条", show_alert=True)


# ================= 群组 =================
async def welcome_new_member(update: Update, context: ContextTypes.DEFAULT_TYPE):
    bot_id = context.bot.id
    chat_id = update.effective_chat.id
    for member in update.message.new_chat_members:
        if member.id == bot_id:
            continue
        try:
            chat_member = await context.bot.get_chat_member(chat_id, member.id)
            if chat_member.status in (ChatMember.ADMINISTRATOR, ChatMember.OWNER):
                continue
        except:
            pass
        caption = build_welcome_caption(member.full_name)
        caption = replace_username(caption)
        await context.bot.send_animation(
            chat_id=chat_id,
            animation="https://files.catbox.moe/urlp95.mp4",
            caption=caption,
            parse_mode="HTML"
        )


async def group_common_reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    chat_id = update.effective_chat.id
    if text == "汇率":
        await update.message.reply_text(f"今日 USDT/CNY 参考汇率：1 USDT ≈ {USDT_CNY_RATE} 元")
    elif text == "地址":
        caption = (
            "达利担保 上押唯一 TRC20 地址😀：\n\n"
            "TVJkYBVgJAX8wPNhxrrbt35EeGiQhKeaUc"
        )
        caption = replace_username(caption)
        msg = await context.bot.send_photo(
            chat_id=chat_id,
            photo="https://files.catbox.moe/a0eelv.png",
            caption=caption,
            parse_mode="HTML"
        )
        if chat_id in pinned_msg:
            try:
                await context.bot.unpin_chat_message(chat_id, pinned_msg[chat_id])
            except:
                pass
        await context.bot.pin_chat_message(chat_id, msg.message_id)
        pinned_msg[chat_id] = msg.message_id
    elif text == "验群":
        if chat_id in group_data and "base_name" in group_data[chat_id]:
            orig_name = group_data[chat_id]["base_name"]
        else:
            try:
                chat = await context.bot.get_chat(chat_id)
                title = chat.title
                for suffix in ["，已押", "开始营业，", "开始营业"]:
                    if suffix in title:
                        title = title.split(suffix)[0]
                        break
                orig_name = title.strip()
            except:
                orig_name = "未知"
        caption = f"达利官方担保专群可放心交易，{orig_name}"
        await context.bot.send_animation(
            chat_id=chat_id,
            animation="https://files.catbox.moe/urlp95.mp4",
            caption=caption
        )


async def group_admin_commands(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != GROUP_ADMIN_ID:
        return
    text = update.message.text.strip()
    chat_id = update.effective_chat.id

    if text == "开群":
        chat = await context.bot.get_chat(chat_id)
        base_name = chat.title
        group_data[chat_id] = {"base_name": base_name, "total_amount": 0, "open_msg_id": update.message.message_id}
        group_messages[chat_id] = [update.message.message_id]
        await update.message.reply_text(f"群已初始化，原始群名：{base_name}")

    elif text == "规则":
        rule_template = (
            "上押金额：填写纯数额\n"
            "上押方：填供方或需方或双方\n"
            "手续费承担方：填写供方或需方或各自承担\n"
            "供方负责人：@xxx\n"
            "需方负责人：@xxx\n"
            "交易内容：填写交易内容\n"
            "交易规则：填写交易规则"
        )
        full_text = (
            "👇请供需双方详细填写下方交易内容\n\n"
            f"{rule_template}\n\n"
            "1⃣方式一：专群负责人回复最终版本[入档]\n"
            "2⃣方式二：1，专群负责人复制并发送最终版本\n"
            "2⃣方式二：2，供需双方点击[确认]按钮进行入档\n\n"
            "交易准则：\n"
            "专群担保以双方规则为准，不看规则是否合理，如规则没有明说以合理的原则为准  请双方负责人确认。"
            "【恶意欺诈全责，不问原由，以官方对于实际情况判定是否是恶意欺诈】"
        )
        await update.message.reply_text(full_text)
        await update.message.reply_text(rule_template)

    elif re.match(r"^\+\d+$", text):
        amount = int(text[1:])
        if chat_id not in group_data:
            chat = await context.bot.get_chat(chat_id)
            base = chat.title.split("，已押")[0] if "，已押" in chat.title else chat.title
            group_data[chat_id] = {"base_name": base, "total_amount": 0}
        else:
            if "total_amount" not in group_data[chat_id]:
                group_data[chat_id]["total_amount"] = 0
        group_data[chat_id]["total_amount"] += amount
        new_total = group_data[chat_id]["total_amount"]
        new_title = f"{group_data[chat_id]['base_name']}，已押{new_total}"
        await context.bot.set_chat_title(chat_id, new_title)
        await update.message.reply_text(f"已记账 +{amount}，当前总押金 {new_total} 元")

    elif text == "开始营业":
        if chat_id not in group_data:
            chat = await context.bot.get_chat(chat_id)
            base = chat.title.split("，已押")[0] if "，已押" in chat.title else chat.title
            group_data[chat_id] = {"base_name": base, "total_amount": 0}
        total = group_data[chat_id].get("total_amount", 0)
        base_name = group_data[chat_id]["base_name"]
        if total > 0:
            new_title = f"开始营业，已押{total}"
        else:
            new_title = "开始营业"
        await context.bot.set_chat_title(chat_id, new_title)
        try:
            resp = requests.get("https://files.catbox.moe/orcguq.png")
            await context.bot.set_chat_photo(chat_id, resp.content)
        except:
            pass
        try:
            await update.message.delete()
        except:
            pass

    elif text == "清群":
        base = group_data.get(chat_id, {}).get("base_name", "")
        if not base:
            chat = await context.bot.get_chat(chat_id)
            base = chat.title.split("，已押")[0] if "，已押" in chat.title else chat.title
        await context.bot.set_chat_title(chat_id, base)
        try:
            resp = requests.get("https://files.catbox.moe/qp5yyj.jpg")
            await context.bot.set_chat_photo(chat_id, resp.content)
        except:
            pass
        try:
            await update.message.delete()
        except:
            pass
        open_msg_id = group_data.get(chat_id, {}).get("open_msg_id", None)
        msg_ids = group_messages.get(chat_id, [])
        for msg_id in msg_ids:
            if msg_id == open_msg_id:
                continue
            try:
                await context.bot.delete_message(chat_id, msg_id)
            except:
                pass
        group_data.pop(chat_id, None)
        group_messages.pop(chat_id, None)
        chat_messages.pop(chat_id, None)

    elif "供方负责人：" in text and "需方负责人：" in text:
        supply_match = re.search(r"供方负责人：\s*@(\w+)", text)
        demand_match = re.search(r"需方负责人：\s*@(\w+)", text)
        if not supply_match or not demand_match:
            await update.message.reply_text("规则格式错误，请确保包含“供方负责人：@用户名”和“需方负责人：@用户名”。")
            return
        supply_user = supply_match.group(1)
        demand_user = demand_match.group(1)
        trade_states[chat_id] = {
            "supply_confirmed": False,
            "demand_confirmed": False,
            "supply_user": supply_user,
            "demand_user": demand_user,
        }
        keyboard = [
            [InlineKeyboardButton("需方确认", callback_data="confirm_demand"),
             InlineKeyboardButton("供方确认", callback_data="confirm_supply")]
        ]
        await update.message.reply_text(
            text + "\n\n请双方确认以上规则：",
            reply_markup=InlineKeyboardMarkup(keyboard),
        )


async def confirm_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = query.from_user
    chat_id = query.message.chat_id
    if chat_id not in trade_states:
        await query.edit_message_text("当前没有待确认的交易规则。")
        return
    trade = trade_states[chat_id]

    # 只有源码里的 GROUP_ADMIN_ID（专群客服）可以无视身份直接确认
    is_group_admin = (user.id == GROUP_ADMIN_ID)

    if query.data == "confirm_demand":
        if not is_group_admin and user.username != trade["demand_user"]:
            await query.answer("您非交易用户无法确认您是需方", show_alert=True)
            return
        if trade["demand_confirmed"]:
            await query.answer("需方已经确认过了。", show_alert=True)
            return
        trade["demand_confirmed"] = True
        await query.answer("需方确认成功！")
    elif query.data == "confirm_supply":
        if not is_group_admin and user.username != trade["supply_user"]:
            await query.answer("您非交易用户无法确认您是供方", show_alert=True)
            return
        if trade["supply_confirmed"]:
            await query.answer("供方已经确认过了。", show_alert=True)
            return
        trade["supply_confirmed"] = True
        await query.answer("供方确认成功！")

    if trade["supply_confirmed"] and trade["demand_confirmed"]:
        trc20 = "TVJkYBVgJAX8wPNhxrrbt35EeGiQhKeaUc"
        caption = f"✅ 本专群开始交易！\n\n上押唯一 TRC20 地址：\n{trc20}"
        await context.bot.send_animation(
            chat_id=chat_id,
            animation="https://files.catbox.moe/urlp95.mp4",
            caption=caption
        )
        try:
            await query.message.delete()
        except:
            pass
        del trade_states[chat_id]
    else:
        status = (f"供方：{'已确认' if trade['supply_confirmed'] else '待确认'}\n"
                  f"需方：{'已确认' if trade['demand_confirmed'] else '待确认'}")
        await query.edit_message_text(
            query.message.text.split("\n\n请双方确认")[0] +
            f"\n\n确认状态：\n{status}\n请双方继续确认：",
            reply_markup=query.message.reply_markup,
        )


async def log_group_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    msg_id = update.message.message_id
    if chat_id not in chat_messages:
        chat_messages[chat_id] = deque(maxlen=50)
    user = update.effective_user
    chat_messages[chat_id].append({
        "user": user.full_name,
        "username": user.username,
        "text": update.message.text,
        "msg_id": msg_id,
    })
    if chat_id in group_messages:
        group_messages[chat_id].append(msg_id)


def main():
    app = Application.builder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start, filters=filters.ChatType.PRIVATE))
    app.add_handler(CommandHandler("help", help_command, filters=filters.ChatType.PRIVATE))
    app.add_handler(CommandHandler("cancel", cancel, filters=filters.ChatType.PRIVATE))
    app.add_handler(CallbackQueryHandler(online_users_callback, pattern="^online_users$"))
    app.add_handler(CallbackQueryHandler(admin_chats_callback, pattern="^admin_chats$"))
    app.add_handler(CallbackQueryHandler(select_user_callback, pattern="^select_"))
    app.add_handler(CallbackQueryHandler(end_user_callback, pattern="^enduser_"))
    app.add_handler(CallbackQueryHandler(view_chat_history, pattern="^viewchat_"))
    app.add_handler(CallbackQueryHandler(toggle_blacklist_callback, pattern="^togglebl_"))
    app.add_handler(CallbackQueryHandler(delete_chat_callback, pattern="^delchat_"))

    app.add_handler(MessageHandler(
        filters.ChatType.PRIVATE & filters.User(user_id=ADMIN_IDS) &
        filters.Regex(r"^(🗑删消息|🚫黑名单管理)$"),
        handle_admin_new_buttons
    ))

    app.add_handler(MessageHandler(
        filters.ChatType.PRIVATE & filters.Regex(r"^(👤人工客服|✅防骗专区|达利官方人员|达利官方地址)$"),
        handle_private_buttons
    ))
    app.add_handler(MessageHandler(
        filters.ChatType.PRIVATE & filters.TEXT & ~filters.COMMAND & filters.User(user_id=ADMIN_IDS),
        admin_reply_handler
    ))
    app.add_handler(MessageHandler(
        filters.ChatType.PRIVATE & filters.TEXT & ~filters.COMMAND & ~filters.User(user_id=ADMIN_IDS),
        user_forward_handler
    ))

    app.add_handler(MessageHandler(
        filters.ChatType.GROUPS & filters.Regex(r"^(汇率|地址|验群)$"),
        group_common_reply
    ))
    app.add_handler(MessageHandler(filters.StatusUpdate.NEW_CHAT_MEMBERS, welcome_new_member))
    app.add_handler(MessageHandler(
        filters.ChatType.GROUPS & filters.TEXT & ~filters.COMMAND,
        group_admin_commands
    ))
    app.add_handler(CallbackQueryHandler(confirm_callback, pattern="^(confirm_demand|confirm_supply)$"))
    app.add_handler(MessageHandler(
        filters.ChatType.GROUPS & filters.TEXT,
        log_group_message
    ))

    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()