import logging, sqlite3, uuid, html
from datetime import datetime
from telegram import (Update, InlineKeyboardButton, InlineKeyboardMarkup,
                       ReplyKeyboardMarkup, KeyboardButton)
from telegram.ext import (Application, CommandHandler, MessageHandler,
                           ConversationHandler, CallbackQueryHandler,
                           filters, ContextTypes)

# ------------------ 内置配置 ------------------
TOKEN = "8943097397:AAFyj-mERKNBFBmq94RX_WhR9ZvapIzmIGo"
ADMIN_ID = 8618953770
SUPPORT_USERNAME = "@imqbsupport"
WALLET_ADDRESS = "TVRZzmgK9fQv2wNKTtMx9ty3e34PgGeD9K"

# 会员自定义表情 ID
EMOJI_NICKNAME = "6235737947614743937"
EMOJI_ID      = "6237934454019461140"
EMOJI_USDT    = "6213220344614882714"
EMOJI_TRX     = "6213214271531126888"
EMOJI_CNY     = "6215350725703111290"

# 会话状态（19个）
(WITHDRAW_CURRENCY, WITHDRAW_AMOUNT, WITHDRAW_ADDRESS, WITHDRAW_CNY_QR,
 TRANSFER_TARGET, TRANSFER_AMOUNT, TRANSFER_NOTE,
 RECEIVE_TARGET, RECEIVE_AMOUNT, RECEIVE_NOTE,
 REDPACKET_CURRENCY, REDPACKET_TOTAL, REDPACKET_COUNT,
 SWAP_AMOUNT,
 ADMIN_BAL_USER, ADMIN_BAL_CURRENCY, ADMIN_BAL_AMOUNT,
 ADMIN_BAN_USER, ADMIN_REJECT_REASON) = range(19)

# ------------------ 数据库 ------------------
def init_db():
    conn = sqlite3.connect("wallet.db")
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS users(
        user_id INTEGER PRIMARY KEY, username TEXT, first_name TEXT,
        balance_usdt REAL DEFAULT 0, balance_trx REAL DEFAULT 0,
        balance_cny REAL DEFAULT 0, banned INTEGER DEFAULT 0, warned INTEGER DEFAULT 0)""")
    c.execute("""CREATE TABLE IF NOT EXISTS withdraw_orders(
        id TEXT PRIMARY KEY, user_id INTEGER, currency TEXT, amount REAL,
        fee REAL, address TEXT, status TEXT, reason TEXT, created_at TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS red_packets(
        id TEXT PRIMARY KEY, user_id INTEGER, currency TEXT, total_amount REAL,
        count INTEGER, per_amount REAL, grabbed INTEGER DEFAULT 0,
        grabbed_users TEXT DEFAULT '', link TEXT, active INTEGER DEFAULT 1,
        created_at TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS transfer_log(
        id TEXT PRIMARY KEY, from_id INTEGER, to_id INTEGER, currency TEXT,
        amount REAL, note TEXT, created_at TEXT)""")
    conn.commit()
    conn.close()

def get_user(user_id):
    conn = sqlite3.connect("wallet.db")
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE user_id=?", (user_id,))
    u = c.fetchone()
    conn.close()
    return u

def create_user(user_id, username, first_name):
    conn = sqlite3.connect("wallet.db")
    c = conn.cursor()
    c.execute("INSERT OR IGNORE INTO users(user_id,username,first_name) VALUES(?,?,?)",
              (user_id, username, first_name))
    conn.commit()
    conn.close()

def get_balance(user_id, currency):
    u = get_user(user_id)
    if not u: return 0.0
    if currency == "USDT": return u[3]
    if currency == "TRX": return u[4]
    if currency == "CNY": return u[5]
    return 0.0

def update_balance(user_id, currency, amount):
    conn = sqlite3.connect("wallet.db")
    c = conn.cursor()
    if currency == "USDT":
        c.execute("UPDATE users SET balance_usdt=balance_usdt+? WHERE user_id=?", (amount, user_id))
    elif currency == "TRX":
        c.execute("UPDATE users SET balance_trx=balance_trx+? WHERE user_id=?", (amount, user_id))
    elif currency == "CNY":
        c.execute("UPDATE users SET balance_cny=balance_cny+? WHERE user_id=?", (amount, user_id))
    conn.commit()
    conn.close()

def is_banned(user_id):
    u = get_user(user_id)
    return u and u[6] == 1

def ban_user(user_id, status=1):
    conn = sqlite3.connect("wallet.db")
    c = conn.cursor()
    c.execute("UPDATE users SET banned=? WHERE user_id=?", (status, user_id))
    conn.commit()
    conn.close()

def warn_user(user_id):
    conn = sqlite3.connect("wallet.db")
    c = conn.cursor()
    c.execute("UPDATE users SET warned=1 WHERE user_id=?", (user_id,))
    conn.commit()
    conn.close()

def e(id, fallback):
    return f'<tg-emoji emoji-id="{id}">{fallback}</tg-emoji>'

# ------------------ 键盘 ------------------
def user_reply_keyboard():
    return ReplyKeyboardMarkup([
        ["💰 充值", "💵 提币"],
        ["🔄 闪兑", "🧧 红包"],
        ["📤 转账", "📥 收钱"],
    ], resize_keyboard=True)

def admin_reply_keyboard():
    return ReplyKeyboardMarkup([
        ["🔍 待处理提现", "💲 修改余额"],
        ["🚫 封禁用户", "✅ 解封用户"],
        ["⚠️ 警告用户", "↩️ 返回用户面板"],
    ], resize_keyboard=True)

def withdraw_currency_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("USDT (TRC20)", callback_data="w_usdt")],
        [InlineKeyboardButton("TRX", callback_data="w_trx")],
        [InlineKeyboardButton("CNY (微信/支付宝)", callback_data="w_cny")],
    ])

def swap_direction_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("USDT → TRX", callback_data="swap_usdt_trx")],
        [InlineKeyboardButton("TRX → USDT", callback_data="swap_trx_usdt")],
        [InlineKeyboardButton("USDT → CNY", callback_data="swap_usdt_cny")],
        [InlineKeyboardButton("CNY → USDT", callback_data="swap_cny_usdt")],
    ])

def redpacket_currency_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("USDT", callback_data="rp_usdt")],
        [InlineKeyboardButton("TRX", callback_data="rp_trx")],
        [InlineKeyboardButton("CNY", callback_data="rp_cny")],
    ])

# ------------------ 取消操作 ------------------
async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("已取消当前操作。")
    return ConversationHandler.END

# ------------------ /start ------------------
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if is_banned(user.id):
        await update.message.reply_text(f"❌ Account Banned（账户封禁）{SUPPORT_USERNAME}")
        return
    create_user(user.id, user.username, user.first_name)

    if user.id == ADMIN_ID:
        await update.message.reply_text("🔐 管理员面板", reply_markup=admin_reply_keyboard())
        return

    usdt = get_balance(user.id, "USDT")
    trx = get_balance(user.id, "TRX")
    cny = get_balance(user.id, "CNY")
    text = (f"欢迎使用imtoken钱包\n\n"
            f"{e(EMOJI_NICKNAME, '🫠')} 昵称: {html.escape(user.first_name)}\n"
            f"{e(EMOJI_ID, '🧠')} ID: {user.id}\n"
            f"{e(EMOJI_USDT, '🐛')} USDT: {usdt}\n"
            f"{e(EMOJI_TRX, '🐛')} TRX: {trx}\n"
            f"{e(EMOJI_CNY, '🐛')} CNY: {cny}\n\n请选择操作：")
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=user_reply_keyboard())

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("联系管理员：",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("管理员", url=f"https://t.me/{SUPPORT_USERNAME[1:]}")]
        ]))

# ------------------ 底部轮盘触发 ------------------
async def user_reply_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    user_id = update.effective_user.id
    if is_banned(user_id):
        await update.message.reply_text("❌ 账户已封禁"); return

    if text == "💰 充值":
        await update.message.reply_text(
            f"👩‍💼 您正在使用 TRC20 付款\n\n至少 1 U\n支持: TRX💰, USDT💰\n\n"
            f"收款地址(TRC20):\n<code>{WALLET_ADDRESS}</code>\n\n点击复制，可重复充值\n充值成功后 Bot 会通知",
            parse_mode="HTML")
    elif text == "💵 提币":
        usdt = get_balance(user_id, "USDT"); trx = get_balance(user_id, "TRX")
        await update.message.reply_text(
            f"请选择提现方式\n\n💰 USDT : {usdt}\n💰 TRX : {trx}\n\n"
            "❌禁止直接提币到交易所！\n✔️请先提现至冷钱包！",
            reply_markup=withdraw_currency_keyboard())
    elif text == "📤 转账":
        await update.message.reply_text("请回复您要转给的用户名（@username）或用户ID：")
        return TRANSFER_TARGET
    elif text == "📥 收钱":
        await update.message.reply_text("请回复对方的用户名或用户ID：")
        return RECEIVE_TARGET
    elif text == "🧧 红包":
        await update.message.reply_text("请选择红包货币：", reply_markup=redpacket_currency_keyboard())
    elif text == "🔄 闪兑":
        await update.message.reply_text("请选择兑换方向：", reply_markup=swap_direction_keyboard())

# ------------------ 提币会话 ------------------
async def w_currency_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query; await query.answer()
    data = query.data
    currency = "USDT" if data == "w_usdt" else "TRX" if data == "w_trx" else "CNY"
    context.user_data["w_currency"] = currency
    balance = get_balance(query.from_user.id, currency)
    await query.edit_message_text(f"请回复要提现的金额\n\n💰 当前余额 : {balance} {currency}")
    return WITHDRAW_AMOUNT

async def w_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    currency = context.user_data["w_currency"]
    try:
        amount = float(update.message.text.strip())
    except:
        await update.message.reply_text("请输入数字金额"); return WITHDRAW_AMOUNT
    if amount <= 0:
        await update.message.reply_text("金额必须大于0"); return WITHDRAW_AMOUNT

    if currency == "CNY":
        fee = amount * 0.03 + 2
        actual = amount - fee
        if amount > get_balance(user_id, "CNY") or actual <= 0:
            await update.message.reply_text("⚠️ 余额不足"); return ConversationHandler.END
        context.user_data["w_amount"] = amount
        context.user_data["w_fee"] = fee
        await update.message.reply_text(
            f"手续费: {amount}*0.03+2={fee:.2f} CNY\n实际到账: {actual:.2f} CNY\n\n请上传收款码：")
        return WITHDRAW_CNY_QR
    else:
        if amount > get_balance(user_id, currency):
            await update.message.reply_text("⚠️ 余额不足"); return ConversationHandler.END
        context.user_data["w_amount"] = amount
        await update.message.reply_text("请回复您的 TRC20 地址：")
        return WITHDRAW_ADDRESS

async def w_address(update: Update, context: ContextTypes.DEFAULT_TYPE):
    address = update.message.text.strip()
    user_id = update.effective_user.id
    currency = context.user_data["w_currency"]
    amount = context.user_data["w_amount"]
    order_id = str(uuid.uuid4())[:8]
    now = datetime.now().isoformat()
    conn = sqlite3.connect("wallet.db")
    c = conn.cursor()
    c.execute("INSERT INTO withdraw_orders VALUES(?,?,?,?,?,?,?,?,?)",
              (order_id, user_id, currency, amount, 0, address, "pending", "", now))
    conn.commit(); conn.close()
    await update.message.reply_text(f"✅ 提现申请已提交\n订单号: {order_id}\n请耐心等待审核")
    admin_msg = f"🔔 新提现申请\n订单号: {order_id}\n用户: {user_id}\n货币: {currency}\n金额: {amount}\n地址: {address}"
    await context.bot.send_message(ADMIN_ID, admin_msg,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("✅ 通过", callback_data=f"approve_{order_id}"),
             InlineKeyboardButton("❌ 拒绝", callback_data=f"reject_{order_id}")]
        ]))
    return ConversationHandler.END

async def w_cny_qr(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    currency = "CNY"
    amount = context.user_data["w_amount"]
    fee = context.user_data["w_fee"]
    order_id = str(uuid.uuid4())[:8]
    now = datetime.now().isoformat()
    conn = sqlite3.connect("wallet.db")
    c = conn.cursor()
    c.execute("INSERT INTO withdraw_orders VALUES(?,?,?,?,?,?,?,?,?)",
              (order_id, user_id, currency, amount, fee, "qrcode", "pending", "", now))
    conn.commit(); conn.close()
    await update.message.reply_text(f"✅ 提现申请已提交\n订单号: {order_id}")
    admin_msg = f"🔔 新提现申请 (CNY)\n订单号: {order_id}\n用户: {user_id}\n金额: {amount}\n手续费: {fee}"
    await context.bot.send_message(ADMIN_ID, admin_msg,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("✅ 通过", callback_data=f"approve_{order_id}"),
             InlineKeyboardButton("❌ 拒绝", callback_data=f"reject_{order_id}")]
        ]))
    return ConversationHandler.END

# ------------------ 转账 ------------------
async def transfer_target(update: Update, context: ContextTypes.DEFAULT_TYPE):
    target = update.message.text.strip()
    if target.startswith("@"):
        conn = sqlite3.connect("wallet.db")
        c = conn.cursor()
        c.execute("SELECT user_id FROM users WHERE username=?", (target[1:],))
        row = c.fetchone(); conn.close()
        if not row: await update.message.reply_text("用户不存在，请重新输入"); return TRANSFER_TARGET
        to_id = row[0]
    else:
        try: to_id = int(target)
        except: await update.message.reply_text("格式错误，请输入用户名或数字ID"); return TRANSFER_TARGET
        if not get_user(to_id): await update.message.reply_text("该用户未使用机器人"); return TRANSFER_TARGET
    context.user_data["t_to"] = to_id
    await update.message.reply_text("请回复货币和金额（如 USDT 10）：")
    return TRANSFER_AMOUNT

async def transfer_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    parts = update.message.text.strip().split()
    if len(parts) != 2: await update.message.reply_text("格式错误，请按：货币 金额"); return TRANSFER_AMOUNT
    curr = parts[0].upper()
    if curr not in ("USDT","TRX","CNY"): await update.message.reply_text("货币不支持，可选 USDT/TRX/CNY"); return TRANSFER_AMOUNT
    try: amount = float(parts[1])
    except: await update.message.reply_text("金额无效，请输入数字"); return TRANSFER_AMOUNT
    if amount <= 0 or amount > get_balance(update.effective_user.id, curr):
        await update.message.reply_text("⚠️ 余额不足或金额无效"); return ConversationHandler.END
    context.user_data["t_curr"] = curr
    context.user_data["t_amount"] = amount
    await update.message.reply_text("请输入转账备注（发送 /skip 跳过）：")
    return TRANSFER_NOTE

async def transfer_note(update: Update, context: ContextTypes.DEFAULT_TYPE):
    from_id = update.effective_user.id
    to_id = context.user_data["t_to"]
    curr = context.user_data["t_curr"]
    amount = context.user_data["t_amount"]
    note = update.message.text if update.message.text != "/skip" else ""
    update_balance(from_id, curr, -amount)
    update_balance(to_id, curr, amount)
    log_id = str(uuid.uuid4())[:8]
    conn = sqlite3.connect("wallet.db")
    c = conn.cursor()
    c.execute("INSERT INTO transfer_log VALUES(?,?,?,?,?,?,?)",
              (log_id, from_id, to_id, curr, amount, note, datetime.now().isoformat()))
    conn.commit(); conn.close()
    await update.message.reply_text(f"✅ 已向 {to_id} 转账 {amount} {curr}")
    try:
        await context.bot.send_message(to_id,
            f"📩 收到来自 {html.escape(update.effective_user.first_name)} 的转账 {amount} {curr}" +
            (f"\n备注: {html.escape(note)}" if note else ""))
    except: pass
    return ConversationHandler.END

# ------------------ 收钱 ------------------
async def receive_target(update: Update, context: ContextTypes.DEFAULT_TYPE):
    target = update.message.text.strip()
    if target.startswith("@"):
        conn = sqlite3.connect("wallet.db"); c = conn.cursor()
        c.execute("SELECT user_id FROM users WHERE username=?", (target[1:],))
        row = c.fetchone(); conn.close()
        if not row: await update.message.reply_text("用户不存在，请重新输入"); return RECEIVE_TARGET
        to_id = row[0]
    else:
        try: to_id = int(target)
        except: await update.message.reply_text("格式错误，请输入用户名或数字ID"); return RECEIVE_TARGET
    context.user_data["r_from"] = to_id
    await update.message.reply_text("请输入请求金额和货币（如 USDT 10）：")
    return RECEIVE_AMOUNT

async def receive_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    parts = update.message.text.strip().split()
    if len(parts) != 2: await update.message.reply_text("格式错误，请按：货币 金额"); return RECEIVE_AMOUNT
    curr = parts[0].upper()
    if curr not in ("USDT","TRX","CNY"): await update.message.reply_text("货币不支持"); return RECEIVE_AMOUNT
    try: amount = float(parts[1])
    except: await update.message.reply_text("金额无效"); return RECEIVE_AMOUNT
    context.user_data["r_curr"] = curr
    context.user_data["r_amount"] = amount
    await update.message.reply_text("请输入备注（发送 /skip 跳过）：")
    return RECEIVE_NOTE

async def receive_note(update: Update, context: ContextTypes.DEFAULT_TYPE):
    requester = update.effective_user.id
    from_id = context.user_data["r_from"]
    curr = context.user_data["r_curr"]
    amount = context.user_data["r_amount"]
    note = update.message.text if update.message.text != "/skip" else ""
    keyboard = InlineKeyboardMarkup([[
        InlineKeyboardButton("✅ 确认付款", callback_data=f"payreq_{requester}_{curr}_{amount}")
    ]])
    name = html.escape(update.effective_user.first_name)
    await context.bot.send_message(from_id,
        f"📥 收款请求来自 {name} (ID:{requester})\n金额: {amount} {curr}" +
        (f"\n备注: {html.escape(note)}" if note else ""), reply_markup=keyboard)
    await update.message.reply_text("✅ 收款请求已发送")
    return ConversationHandler.END

async def pay_request(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query; await query.answer()
    _, requester, curr, amount_str = query.data.split("_")
    from_id = query.from_user.id
    amount = float(amount_str)
    if amount > get_balance(from_id, curr):
        await query.edit_message_text("⚠️ 余额不足，支付失败"); return
    update_balance(from_id, curr, -amount)
    update_balance(int(requester), curr, amount)
    await query.edit_message_text(f"✅ 已支付 {amount} {curr}")
    try: await context.bot.send_message(int(requester), f"💰 收到付款 {amount} {curr}")
    except: pass

# ------------------ 红包 ------------------
async def rp_currency_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query; await query.answer()
    curr = query.data.split("_")[1].upper()
    context.user_data["rp_curr"] = curr
    await query.edit_message_text(f"请输入红包总金额（{curr}）：")
    return REDPACKET_TOTAL

async def rp_total(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try: total = float(update.message.text)
    except: await update.message.reply_text("请输入数字金额"); return REDPACKET_TOTAL
    user_id = update.effective_user.id
    curr = context.user_data["rp_curr"]
    if total > get_balance(user_id, curr) or total <= 0:
        await update.message.reply_text("⚠️ 余额不足或金额无效"); return ConversationHandler.END
    context.user_data["rp_total"] = total
    await update.message.reply_text("请输入红包个数：")
    return REDPACKET_COUNT

async def rp_count(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try: count = int(update.message.text)
    except: await update.message.reply_text("请输入整数个数"); return REDPACKET_COUNT
    if count <= 0: await update.message.reply_text("个数必须大于0"); return REDPACKET_COUNT
    user_id = update.effective_user.id
    curr = context.user_data["rp_curr"]
    total = context.user_data["rp_total"]
    update_balance(user_id, curr, -total)
    rp_id = str(uuid.uuid4())[:8]
    link = f"https://t.me/{context.bot.username}?start=rp_{rp_id}"
    per = total / count
    conn = sqlite3.connect("wallet.db")
    c = conn.cursor()
    c.execute("INSERT INTO red_packets VALUES(?,?,?,?,?,?,?,?,?,?,?)",
              (rp_id, user_id, curr, total, count, per, 0, "", link, 1, datetime.now().isoformat()))
    conn.commit(); conn.close()
    await update.message.reply_text(f"🧧 红包已创建\n货币: {curr}\n总金额: {total}\n个数: {count}\n链接: {link}")
    return ConversationHandler.END

async def redpacket_grab(update: Update, context: ContextTypes.DEFAULT_TYPE):
    args = context.args
    if not args or not args[0].startswith("rp_"): return
    rp_id = args[0][3:]
    user_id = update.effective_user.id
    conn = sqlite3.connect("wallet.db"); c = conn.cursor()
    c.execute("SELECT * FROM red_packets WHERE id=? AND active=1", (rp_id,))
    rp = c.fetchone()
    if not rp: await update.message.reply_text("红包已失效"); conn.close(); return
    if rp[6] >= rp[4]: await update.message.reply_text("红包已被抢光"); conn.close(); return
    grabbed = (rp[7].split(",") if rp[7] else [])
    if str(user_id) in grabbed: await update.message.reply_text("你已经领过了"); conn.close(); return
    update_balance(user_id, rp[2], rp[5])
    grabbed.append(str(user_id))
    c.execute("UPDATE red_packets SET grabbed=?, grabbed_users=? WHERE id=?",
              (rp[6]+1, ",".join(grabbed), rp_id))
    conn.commit(); conn.close()
    await update.message.reply_text(f"🧧 你领取了 {rp[5]} {rp[2]}")

# ------------------ 闪兑（仅 USDT/TRX/CNY 双向，移除 TRX-CNY） ------------------
async def swap_dir_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query; await query.answer()
    data = query.data
    if data == "swap_usdt_trx":
        context.user_data["swap_from"] = "USDT"; context.user_data["swap_to"] = "TRX"
    elif data == "swap_trx_usdt":
        context.user_data["swap_from"] = "TRX"; context.user_data["swap_to"] = "USDT"
    elif data == "swap_usdt_cny":
        context.user_data["swap_from"] = "USDT"; context.user_data["swap_to"] = "CNY"
    elif data == "swap_cny_usdt":
        context.user_data["swap_from"] = "CNY"; context.user_data["swap_to"] = "USDT"
    await query.edit_message_text("请输入要兑换的数量：")
    return SWAP_AMOUNT

async def swap_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    try:
        amount = float(update.message.text)
    except:
        await update.message.reply_text("数字无效，请重新输入"); return SWAP_AMOUNT

    from_cur = context.user_data["swap_from"]
    to_cur = context.user_data["swap_to"]

    if amount > get_balance(user_id, from_cur):
        await update.message.reply_text("⚠️ 余额不足"); return ConversationHandler.END

    # 汇率: 1 USDT = 2.8 TRX = 6.8 CNY
    if from_cur == "USDT" and to_cur == "TRX":
        receive = amount * 2.8
    elif from_cur == "TRX" and to_cur == "USDT":
        receive = amount / 2.8
    elif from_cur == "USDT" and to_cur == "CNY":
        receive = amount * 6.8
    elif from_cur == "CNY" and to_cur == "USDT":
        receive = amount / 6.8
    else:
        receive = amount

    update_balance(user_id, from_cur, -amount)
    update_balance(user_id, to_cur, receive)
    await update.message.reply_text(
        f"✅ 兑换成功\n{amount} {from_cur} → {receive:.4f} {to_cur}\n汇率: 1 USDT = 2.8 TRX = 6.8 CNY"
    )
    return ConversationHandler.END

# ------------------ 管理员 ------------------
async def admin_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID: return
    text = update.message.text
    if text == "🔍 待处理提现":
        conn = sqlite3.connect("wallet.db"); c = conn.cursor()
        c.execute("SELECT * FROM withdraw_orders WHERE status='pending'")
        orders = c.fetchall(); conn.close()
        if not orders:
            await update.message.reply_text("暂无待处理提现")
        else:
            for o in orders:
                msg = f"订单号: {o[0]}\n用户: {o[1]}\n货币: {o[2]}\n金额: {o[3]}\n手续费: {o[4]}\n地址: {o[5]}"
                await update.message.reply_text(msg,
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton("✅ 通过", callback_data=f"approve_{o[0]}"),
                        InlineKeyboardButton("❌ 拒绝", callback_data=f"reject_{o[0]}")
                    ]]))
    elif text == "💲 修改余额":
        await update.message.reply_text("请输入用户ID：")
        return ADMIN_BAL_USER
    elif text == "🚫 封禁用户":
        await update.message.reply_text("请输入要封禁的用户ID：")
        context.user_data["admin_action"] = "ban"
        return ADMIN_BAN_USER
    elif text == "✅ 解封用户":
        await update.message.reply_text("请输入要解封的用户ID：")
        context.user_data["admin_action"] = "unban"
        return ADMIN_BAN_USER
    elif text == "⚠️ 警告用户":
        await update.message.reply_text("请输入要警告的用户ID：")
        context.user_data["admin_action"] = "warn"
        return ADMIN_BAN_USER
    elif text == "↩️ 返回用户面板":
        user = update.effective_user
        usdt = get_balance(user.id, "USDT"); trx = get_balance(user.id, "TRX"); cny = get_balance(user.id, "CNY")
        await update.message.reply_text(
            f"欢迎使用imtoken钱包\n\n昵称: {user.first_name}\nID: {user.id}\nUSDT: {usdt}\nTRX: {trx}\nCNY: {cny}",
            reply_markup=user_reply_keyboard())

async def admin_balance_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try: uid = int(update.message.text.strip())
    except: await update.message.reply_text("ID无效，请输入纯数字"); return ADMIN_BAL_USER
    context.user_data["admin_uid"] = uid
    await update.message.reply_text("请选择货币：USDT, TRX, CNY")
    return ADMIN_BAL_CURRENCY

async def admin_balance_currency(update: Update, context: ContextTypes.DEFAULT_TYPE):
    curr = update.message.text.strip().upper()
    if curr not in ("USDT","TRX","CNY"): await update.message.reply_text("货币无效，请重新输入"); return ADMIN_BAL_CURRENCY
    context.user_data["admin_curr"] = curr
    await update.message.reply_text("请输入新余额：")
    return ADMIN_BAL_AMOUNT

async def admin_balance_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try: new_bal = float(update.message.text)
    except: await update.message.reply_text("数字无效，请重新输入"); return ADMIN_BAL_AMOUNT
    uid = context.user_data["admin_uid"]
    curr = context.user_data["admin_curr"]
    conn = sqlite3.connect("wallet.db"); c = conn.cursor()
    if curr == "USDT": c.execute("UPDATE users SET balance_usdt=? WHERE user_id=?", (new_bal, uid))
    elif curr == "TRX": c.execute("UPDATE users SET balance_trx=? WHERE user_id=?", (new_bal, uid))
    else: c.execute("UPDATE users SET balance_cny=? WHERE user_id=?", (new_bal, uid))
    conn.commit(); conn.close()
    await update.message.reply_text(f"✅ 用户 {uid} 的 {curr} 余额已更新为 {new_bal}")
    return ConversationHandler.END

async def admin_ban_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    action = context.user_data.get("admin_action", "ban")
    try: uid = int(update.message.text.strip())
    except: await update.message.reply_text("ID无效，请输入纯数字"); return ADMIN_BAN_USER
    if action == "ban": ban_user(uid, 1); await update.message.reply_text("已封禁")
    elif action == "unban": ban_user(uid, 0); await update.message.reply_text("已解封")
    elif action == "warn": warn_user(uid); await update.message.reply_text("已警告")
    return ConversationHandler.END

async def admin_approve_reject(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query; await query.answer()
    if query.from_user.id != ADMIN_ID: return
    data = query.data
    if data.startswith("approve_"):
        order_id = data.split("_")[1]
        conn = sqlite3.connect("wallet.db"); c = conn.cursor()
        c.execute("SELECT * FROM withdraw_orders WHERE id=? AND status='pending'", (order_id,))
        order = c.fetchone()
        if not order: await query.edit_message_text("订单已处理"); conn.close(); return
        update_balance(order[1], order[2], -order[3])
        c.execute("UPDATE withdraw_orders SET status='approved' WHERE id=?", (order_id,))
        conn.commit(); conn.close()
        await query.edit_message_text(f"✅ 订单 {order_id} 已通过")
        try: await context.bot.send_message(order[1], f"✅ 提现申请 {order_id} 已通过")
        except: pass
    elif data.startswith("reject_"):
        order_id = data.split("_")[1]
        context.user_data["reject_oid"] = order_id
        await query.edit_message_text("请输入拒绝原因：")
        return ADMIN_REJECT_REASON

async def admin_reject_reason(update: Update, context: ContextTypes.DEFAULT_TYPE):
    reason = update.message.text
    order_id = context.user_data.get("reject_oid")
    if not order_id: return ConversationHandler.END
    conn = sqlite3.connect("wallet.db"); c = conn.cursor()
    c.execute("SELECT * FROM withdraw_orders WHERE id=? AND status='pending'", (order_id,))
    order = c.fetchone()
    if order:
        c.execute("UPDATE withdraw_orders SET status='rejected', reason=? WHERE id=?", (reason, order_id))
        conn.commit()
        try: await context.bot.send_message(order[1], f"❌ 提现申请 {order_id} 被拒绝，原因: {reason}")
        except: pass
    conn.close()
    await update.message.reply_text("已拒绝并通知用户")
    return ConversationHandler.END

# ------------------ 主函数 ------------------
def main():
    init_db()
    app = Application.builder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    # 红包领取也由 /start 触发
    app.add_handler(CommandHandler("start", redpacket_grab))

    # 提币会话
    w_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(w_currency_callback, pattern="^w_(usdt|trx|cny)$")],
        states={
            WITHDRAW_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, w_amount)],
            WITHDRAW_ADDRESS: [MessageHandler(filters.TEXT & ~filters.COMMAND, w_address)],
            WITHDRAW_CNY_QR: [MessageHandler(filters.PHOTO | (filters.TEXT & ~filters.COMMAND), w_cny_qr)],
        },
        fallbacks=[CommandHandler("cancel", cancel)]
    )
    app.add_handler(w_conv)

    # 转账会话
    t_conv = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^📤 转账$"), user_reply_handler)],
        states={
            TRANSFER_TARGET: [MessageHandler(filters.TEXT & ~filters.COMMAND, transfer_target)],
            TRANSFER_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, transfer_amount)],
            TRANSFER_NOTE: [MessageHandler(filters.TEXT & ~filters.COMMAND, transfer_note)],
        },
        fallbacks=[CommandHandler("cancel", cancel)]
    )
    app.add_handler(t_conv)

    # 收钱会话
    r_conv = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^📥 收钱$"), user_reply_handler)],
        states={
            RECEIVE_TARGET: [MessageHandler(filters.TEXT & ~filters.COMMAND, receive_target)],
            RECEIVE_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, receive_amount)],
            RECEIVE_NOTE: [MessageHandler(filters.TEXT & ~filters.COMMAND, receive_note)],
        },
        fallbacks=[CommandHandler("cancel", cancel)]
    )
    app.add_handler(r_conv)

    # 红包会话
    rp_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(rp_currency_callback, pattern="^rp_")],
        states={
            REDPACKET_TOTAL: [MessageHandler(filters.TEXT & ~filters.COMMAND, rp_total)],
            REDPACKET_COUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, rp_count)],
        },
        fallbacks=[CommandHandler("cancel", cancel)]
    )
    app.add_handler(rp_conv)

    # 闪兑会话
    swap_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(swap_dir_callback, pattern="^swap_")],
        states={
            SWAP_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, swap_amount)],
        },
        fallbacks=[CommandHandler("cancel", cancel)]
    )
    app.add_handler(swap_conv)

    # 管理员修改余额
    admin_bal_conv = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^💲 修改余额$"), admin_handler)],
        states={
            ADMIN_BAL_USER: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_balance_user)],
            ADMIN_BAL_CURRENCY: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_balance_currency)],
            ADMIN_BAL_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_balance_amount)],
        },
        fallbacks=[CommandHandler("cancel", cancel)]
    )
    app.add_handler(admin_bal_conv)

    # 管理员封禁/解封/警告
    admin_ban_conv = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^(🚫 封禁用户|✅ 解封用户|⚠️ 警告用户)$"), admin_handler)],
        states={
            ADMIN_BAN_USER: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_ban_user)],
        },
        fallbacks=[CommandHandler("cancel", cancel)]
    )
    app.add_handler(admin_ban_conv)

    # 管理员拒绝原因
    admin_reject_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(admin_approve_reject, pattern="^reject_")],
        states={
            ADMIN_REJECT_REASON: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_reject_reason)],
        },
        fallbacks=[CommandHandler("cancel", cancel)]
    )
    app.add_handler(admin_reject_conv)

    # 管理员审批通过
    app.add_handler(CallbackQueryHandler(admin_approve_reject, pattern="^approve_"))

    # 管理员面板其他文本
    app.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND & filters.User(user_id=ADMIN_ID),
        admin_handler))

    # 普通用户底部键盘（充值/提币/闪兑/红包/转账/收钱入口）
    app.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND & filters.Regex("^(💰 充值|💵 提币|🔄 闪兑|🧧 红包)$"),
        user_reply_handler))

    # 收款请求付款
    app.add_handler(CallbackQueryHandler(pay_request, pattern="^payreq_"))

    app.run_polling()

if __name__ == "__main__":
    main()