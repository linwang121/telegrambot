#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
防骗机器人启动模块
"""
import sys
import os

# 添加项目根目录到Python路径（确保能找到config.py）
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
# 插入到最前面，确保优先使用
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

# 清理可能的模块冲突
if 'bot' in sys.modules:
    del sys.modules['bot']
if 'handlers' in sys.modules:
    del sys.modules['handlers']
if 'utils' in sys.modules:
    del sys.modules['utils']

# 添加bbbb目录到Python路径
bbbb_path = os.path.join(parent_dir, 'bbbb')
sys.path.insert(0, bbbb_path)

def main():
    """启动防骗机器人"""
    # 导入bot模块
    from bot import main as bot_main
    
    # 导入handlers和utils模块（防骗机器人需要）
    import handlers
    import utils
    
    # 加载欢迎消息和分类消息ID（如果有这些函数）
    if hasattr(handlers, 'load_welcome_message_ids'):
        handlers.load_welcome_message_ids()
    if hasattr(utils, 'load_class_message_ids'):
        utils.load_class_message_ids()
    
    # 运行机器人
    bot_main()

if __name__ == '__main__':
    main()
