from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ChatPermissions
import config
import logging
import requests
import json
import os

# 设置日志
logger = logging.getLogger(__name__)

# 存储群组设置的字典（缓存，格式：{chat_id: {'settings': ..., 'cached_at': timestamp}}）
group_settings_cache = {}
# 存储每个群组的最后一条欢迎消息ID
last_welcome_messages = {}
# 存储每个群组的课程消息ID，格式为 {chat_id: [message_id1, message_id2, ...]}
last_class_messages = {}
# 缓存消息模板（字典格式：{template_key: {'data': ..., 'cached_at': timestamp}}）
message_templates_cache = {}
CACHE_EXPIRE_SECONDS = 30  # 消息模板缓存30秒后过期（原来5分钟）
SETTINGS_CACHE_EXPIRE_SECONDS = 10  # 群组设置缓存10秒后过期（原来1分钟）

def get_message_template(template_key):
    """从数据库获取消息模板（带缓存，5分钟过期）"""
    import time
    
    # 检查缓存是否存在且未过期
    if template_key in message_templates_cache:
        cache_entry = message_templates_cache[template_key]
        cached_time = cache_entry.get('cached_at', 0)
        current_time = time.time()
        
        # 如果缓存未过期（5分钟内），直接返回
        if current_time - cached_time < CACHE_EXPIRE_SECONDS:
            logger.debug(f"使用缓存的模板: {template_key}")
            return cache_entry['data']
        else:
            logger.debug(f"缓存已过期，重新获取: {template_key}")
    
    # 从API获取
    try:
        response = requests.get(f'http://localhost:3002/api/bot_template/{template_key}', timeout=5)
        if response.status_code == 200:
            data = response.json()
            if data.get('success'):
                template = {
                    'content': data.get('content', ''),
                    'buttons': data.get('buttons', [])
                }
                # 缓存结果（带时间戳）
                message_templates_cache[template_key] = {
                    'data': template,
                    'cached_at': time.time()
                }
                logger.debug(f"已缓存模板: {template_key}")
                return template
    except Exception as e:
        logger.error(f"获取消息模板 {template_key} 失败: {e}")
    
    # 如果获取失败，返回默认配置
    return get_default_template(template_key)

def get_default_template(template_key):
    """获取默认模板（fallback）"""
    defaults = {
        'welcome_message': {
            'content': config.DEFAULT_WELCOME_MESSAGE,
            'buttons': config.WELCOME_BUTTONS
        },
        'verification_message': {
            'content': "欢迎来到 {group_name}\n\n⚠️ 先报备再交易,无报备属于私下作业!\n⚠️ 私下作业不在担保范围内,出现纠纷不予处理!",
            'buttons': [
                {"text": "新币客服", "url": "https://t.me/xdfkbot"},
                {"text": "违规举报", "url": "https://t.me/xbwvvv"},
                {"text": "新币供需", "url": "https://t.me/xbgx"}
            ]
        },
        'class_start_message': {
            'content': config.CLASS_START_MESSAGE,
            'buttons': config.CLASS_BUTTONS
        },
        'class_end_message': {
            'content': config.CLASS_END_MESSAGE,
            'buttons': config.CLASS_BUTTONS
        },
        'start_message': {
            'content': config.START_MESSAGE,
            'buttons': config.START_BUTTONS
        }
    }
    return defaults.get(template_key, {'content': '', 'buttons': []})

def clear_template_cache():
    """清除模板缓存（用于更新后刷新）"""
    global message_templates_cache
    message_templates_cache = {}

# 导入待验证用户字典（需要从handlers模块导入）
def get_pending_verification():
    """获取待验证用户字典"""
    from handlers import pending_verification
    return pending_verification

def init_group_settings(chat_id):
    """初始化群组设置（从数据库获取并缓存）"""
    import time
    
    # 尝试从数据库获取设置
    settings = get_settings_from_db(chat_id)
    
    # 如果数据库中没有设置，则使用默认设置
    if not settings:
        settings = {
            "strict_mode": False,
            "forward_restriction": False,
            "message_restriction": False,
            "link_restriction": False,
            "anti_spam": False,
            "ad_restriction": False,
            "welcome_message": False,
            "welcome_vip_only": False,
            "verification": False,
            "bottom_button": False,
            "external_text": False,
            "auto_kick": False,
            "sync_blocked_users": False,
            "auto_delete_service": False,
            "global_mute": False,
            "auto_approve": True  # 默认启用自动批准加入请求
        }
    
    # 缓存设置（带时间戳）
    group_settings_cache[chat_id] = {
        'settings': settings,
        'cached_at': time.time()
    }
    logger.debug(f"已缓存群组 {chat_id} 的设置")
    
    return settings

def get_settings_from_db(chat_id):
    """从数据库获取群组设置"""
    try:
        response = requests.get(f'http://localhost:3002/api/get_group_settings/{chat_id}', timeout=5)
        if response.status_code == 200:
            data = response.json()
            if data.get('success', False) and data.get('settings'):
                return data['settings']
    except Exception as e:
        logger.error(f"从数据库获取设置失败: {e}")
    
    return None

def save_settings_to_db(chat_id, settings):
    """保存群组设置到数据库"""
    try:
        logger.info(f"正在保存群组 {chat_id} 的设置到数据库: {settings}")
        response = requests.post(
            f'http://localhost:3002/api/update_group_settings/{chat_id}',
            json={'settings': settings},
            headers={'Content-Type': 'application/json'},
            timeout=5
        )
        logger.info(f"保存设置API响应状态: {response.status_code}")
        if response.status_code == 200:
            data = response.json()
            if data.get('success', False):
                logger.info(f"群组 {chat_id} 设置保存成功")
                return True
            else:
                logger.error(f"保存设置失败: {data.get('error')}")
        else:
            logger.error(f"保存设置HTTP错误: {response.status_code}, 响应: {response.text}")
    except Exception as e:
        logger.error(f"保存设置到数据库失败: {e}")
        import traceback
        traceback.print_exc()
    
    return False

def get_settings(chat_id):
    """获取群组设置（带缓存，1分钟过期）"""
    import time
    
    # 检查缓存是否存在且未过期
    if chat_id in group_settings_cache:
        cache_entry = group_settings_cache[chat_id]
        cached_time = cache_entry.get('cached_at', 0)
        current_time = time.time()
        
        # 如果缓存未过期（1分钟内），直接返回
        if current_time - cached_time < SETTINGS_CACHE_EXPIRE_SECONDS:
            logger.debug(f"使用缓存的群组设置: {chat_id}")
            return cache_entry['settings']
        else:
            logger.debug(f"群组设置缓存已过期，重新获取: {chat_id}")
    
    # 缓存不存在或已过期，重新获取
    return init_group_settings(chat_id)

def update_setting(chat_id, setting_name, value):
    """更新群组设置"""
    import time
    
    settings = get_settings(chat_id)
    settings[setting_name] = value
    
    # 保存到缓存（带时间戳）
    group_settings_cache[chat_id] = {
        'settings': settings,
        'cached_at': time.time()
    }
    
    # 保存到数据库
    save_settings_to_db(chat_id, settings)
    
    logger.info(f"已更新群组 {chat_id} 的设置: {setting_name} = {value}")
    
    return settings

def clear_settings_cache(chat_id=None):
    """清除群组设置缓存"""
    global group_settings_cache
    if chat_id:
        # 清除特定群组的缓存
        if chat_id in group_settings_cache:
            del group_settings_cache[chat_id]
            logger.info(f"已清除群组 {chat_id} 的设置缓存")
    else:
        # 清除所有缓存
        group_settings_cache = {}
        logger.info("已清除所有群组设置缓存")

def get_strict_mode_keyboard(chat_id):
    """获取严格模式的键盘"""
    settings = get_settings(chat_id)
    
    # 创建按钮，根据当前设置显示勾选状态
    buttons = [
        [
            InlineKeyboardButton(
                f"{'✅' if settings['strict_mode'] else '🔲'} 严格模式", 
                callback_data="toggle_strict_mode"
            ),
        ],
        [
            InlineKeyboardButton(
                f"{'✅' if settings['forward_restriction'] else '🔲'} 转发限制", 
                callback_data="toggle_forward_restriction"
            ),
            InlineKeyboardButton(
                f"{'✅' if settings['message_restriction'] else '🔲'} 信息限制", 
                callback_data="toggle_message_restriction"
            ),
            InlineKeyboardButton(
                f"{'✅' if settings['link_restriction'] else '🔲'} 禁止链接", 
                callback_data="toggle_link_restriction"
            ),
        ],
        [
            InlineKeyboardButton(
                f"{'✅' if settings['anti_spam'] else '🔲'} 防骚扰强", 
                callback_data="toggle_anti_spam"
            ),
            InlineKeyboardButton(
                f"{'✅' if settings['ad_restriction'] else '🔲'} 广告限制", 
                callback_data="toggle_ad_restriction"
            ),
            InlineKeyboardButton(
                f"{'✅' if settings['welcome_message'] else '🔲'} 欢迎语", 
                callback_data="toggle_welcome_message"
            ),
        ],
        [
            InlineKeyboardButton(
                f"{'✅' if settings['welcome_vip_only'] else '🔲'} 仅欢迎重要人士", 
                callback_data="toggle_welcome_vip_only"
            ),
            InlineKeyboardButton(
                f"{'✅' if settings['verification'] else '🔲'} 进群验证", 
                callback_data="toggle_verification"
            ),
            InlineKeyboardButton(
                f"{'✅' if settings['bottom_button'] else '🔲'} 底部按钮", 
                callback_data="toggle_bottom_button"
            ),
        ],
        [
            InlineKeyboardButton(
                f"{'✅' if settings['external_text'] else '🔲'} 禁止外文", 
                callback_data="toggle_external_text"
            ),
            InlineKeyboardButton(
                f"{'✅' if settings['auto_kick'] else '🔲'} 踢出退群", 
                callback_data="toggle_auto_kick"
            ),
            InlineKeyboardButton(
                f"{'✅' if settings['sync_blocked_users'] else '🔲'} 拦截相同信息", 
                callback_data="toggle_sync_blocked_users"
            ),
        ],
        [
            InlineKeyboardButton(
                f"{'✅' if settings['auto_delete_service'] else '🔲'} 取消自动置顶", 
                callback_data="toggle_auto_delete_service"
            ),
            InlineKeyboardButton(
                f"{'✅' if settings['global_mute'] else '🔲'} 艾特全体成员", 
                callback_data="toggle_global_mute"
            ),
        ],
    ]
    
    return InlineKeyboardMarkup(buttons)

def is_admin(user_id):
    """检查用户是否为管理员"""
    return user_id in config.ADMIN_IDS

def check_message_restrictions(message):
    """检查消息是否符合限制条件"""
    text = message.text or message.caption or ""
    
    # 检查字符数
    if len(text) > config.MAX_CHARACTERS:
        return False, f"消息超过{config.MAX_CHARACTERS}个字符限制"
    
    # 检查行数
    lines = text.split('\n')
    if len(lines) > config.MAX_LINES:
        return False, f"消息超过{config.MAX_LINES}行限制"
    
    return True, ""

def contains_link(text):
    """检查文本是否包含链接"""
    if not text:
        return False
        
    link_indicators = ['http://', 'https://', 'www.', '.com', '.org', '.net', 't.me/', '@']
    return any(indicator in text.lower() for indicator in link_indicators)

def restrict_user(bot, chat_id, user_id, until_date=None):
    """限制用户权限"""
    permissions = ChatPermissions(
        can_send_messages=False,
        can_send_media_messages=False,
        can_send_polls=False,
        can_send_other_messages=False,
        can_add_web_page_previews=False,
        can_change_info=False,
        can_invite_users=False,
        can_pin_messages=False
    )
    
    bot.restrict_chat_member(chat_id, user_id, permissions, until_date=until_date)

def get_welcome_message(is_vip=False, is_staff=False):
    """获取欢迎消息"""
    if is_staff:
        return config.STAFF_WELCOME_MESSAGE
    elif is_vip:
        return config.VIP_WELCOME_MESSAGE
    else:
        return config.DEFAULT_WELCOME_MESSAGE

def get_verification_keyboard(user_id):
    """获取验证按钮键盘"""
    buttons = [
        [
            InlineKeyboardButton(
                "👆 点我恢复发言 👆",
                callback_data=f"verify_{user_id}"
            )
        ]
    ]
    return InlineKeyboardMarkup(buttons)

def delete_verification_message(context):
    """删除验证消息的回调函数"""
    job_context = context.job.context
    chat_id = job_context['chat_id']
    message_id = job_context['message_id']
    user_id = job_context['user_id']
    
    # 获取待验证用户字典
    pending_verification = get_pending_verification()
    
    try:
        # 检查用户是否还在待验证列表中
        if chat_id in pending_verification and user_id in pending_verification[chat_id]:
            # 用户未完成验证，尝试删除消息并踢出用户
            try:
                context.bot.delete_message(chat_id=chat_id, message_id=message_id)
            except Exception as e:
                # 消息可能已经被删除，记录但不报错
                logger.info(f"验证消息可能已被删除: {e}")
            
            # 踢出未验证用户
            try:
                context.bot.kick_chat_member(chat_id, user_id)
                # 立即解封，这样用户可以重新加入
                context.bot.unban_chat_member(chat_id, user_id)
                
                # 从待验证列表中移除
                del pending_verification[chat_id][user_id]
                
                # 移除踢出提示消息
                # context.bot.send_message(
                #     chat_id=chat_id,
                #     text="有用户未完成验证，已被移出群聊"
                # )
            except Exception as e:
                logger.error(f"踢出未验证用户失败: {e}")
        else:
            # 用户已完成验证，只需尝试删除消息（如果还存在的话）
            try:
                context.bot.delete_message(chat_id=chat_id, message_id=message_id)
            except Exception as e:
                # 消息可能已经在验证成功时被删除，这是正常情况
                logger.info(f"验证消息已被删除（用户可能已完成验证）: {e}")
                
    except Exception as e:
        logger.error(f"处理验证消息删除失败: {e}") 

def save_welcome_message_ids():
    """保存欢迎消息ID到文件"""
    try:
        with open('welcome_messages.json', 'w') as f:
            json.dump(last_welcome_messages, f)
    except Exception as e:
        logger.error(f"保存欢迎消息ID文件失败: {e}")

def load_welcome_message_ids():
    """从文件加载欢迎消息ID"""
    global last_welcome_messages
    try:
        if os.path.exists('welcome_messages.json'):
            with open('welcome_messages.json', 'r') as f:
                last_welcome_messages = json.load(f)
                # 将字符串键转换为整数
                last_welcome_messages = {int(k): v for k, v in last_welcome_messages.items()}
    except Exception as e:
        logger.error(f"加载欢迎消息ID文件失败: {e}")
        last_welcome_messages = {}

def save_class_message_ids():
    """保存课程消息ID到文件"""
    try:
        with open('class_messages.json', 'w') as f:
            json.dump(last_class_messages, f)
    except Exception as e:
        logger.error(f"保存课程消息ID文件失败: {e}")

def load_class_message_ids():
    """从文件加载课程消息ID"""
    global last_class_messages
    try:
        if os.path.exists('class_messages.json'):
            with open('class_messages.json', 'r') as f:
                data = json.load(f)
                # 将字符串键转换为整数，并确保每个值都是列表
                last_class_messages = {}
                for k, v in data.items():
                    chat_id = int(k)
                    if isinstance(v, list):
                        last_class_messages[chat_id] = v
                    else:
                        # 兼容旧格式：将单个消息ID转换为列表
                        last_class_messages[chat_id] = [v] if v is not None else []
    except Exception as e:
        logger.error(f"加载课程消息ID文件失败: {e}")
        last_class_messages = {}

# 在启动时加载欢迎消息ID
load_welcome_message_ids()
# 在启动时加载课程消息ID
load_class_message_ids() 