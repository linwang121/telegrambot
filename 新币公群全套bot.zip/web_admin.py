#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
统一Web管理后台
整合报备机器人和防骗机器人的所有管理功能
"""

from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, send_from_directory
from werkzeug.utils import secure_filename
from functools import wraps
from datetime import datetime, timedelta
import pymysql
from pymysql.cursors import DictCursor
import os
import sys
import logging
import re
import json

# 导入统一配置
import config

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = config.SECRET_KEY
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(__file__), 'static', 'uploads')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

def get_db_connection():
    """获取数据库连接"""
    return pymysql.connect(
        host=config.DB_HOST,
        port=config.DB_PORT,
        user=config.DB_USER,
        password=config.DB_PASSWORD,
        database=config.DB_NAME,
        charset='utf8mb4',
        cursorclass=DictCursor
    )

def login_required(f):
    """登录验证装饰器"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session:
            flash('请先登录', 'danger')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# ==================== 登录登出 ====================

@app.route('/')
def index():
    if 'logged_in' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if username == config.WEB_USERNAME and password == config.WEB_PASSWORD:
            session['logged_in'] = True
            session['username'] = username
            flash('登录成功', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('用户名或密码错误', 'danger')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('已退出登录', 'info')
    return redirect(url_for('login'))

# ==================== 仪表板 ====================

@app.route('/dashboard')
@login_required
def dashboard():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # 报备机器人统计
        cursor.execute("SELECT COUNT(*) as count FROM `groups` WHERE `is_active` = 1")
        report_groups_count = cursor.fetchone()['count']
        
        cursor.execute("SELECT COUNT(*) as count FROM `reports`")
        reports_count = cursor.fetchone()['count']
        
        cursor.execute("SELECT COUNT(*) as count FROM `reports` WHERE `status` = 'completed'")
        completed_reports_count = cursor.fetchone()['count']
        
        cursor.execute("SELECT COUNT(*) as count FROM `reports` WHERE `status` = 'cancelled'")
        cancelled_reports_count = cursor.fetchone()['count']
        
        cursor.execute("SELECT COUNT(*) as count FROM `admins`")
        admins_count = cursor.fetchone()['count']
        
        # 防骗机器人统计
        cursor.execute("SELECT COUNT(*) as count FROM `authorized_groups` WHERE `is_active` = 1")
        antifraud_groups_count = cursor.fetchone()['count']
        
        cursor.execute("SELECT COUNT(*) as count FROM `prohibited_words`")
        prohibited_words_count = cursor.fetchone()['count']
        
        cursor.execute("SELECT COUNT(*) as count FROM `group_verify_settings`")
        verify_settings_count = cursor.fetchone()['count']
        
        cursor.execute("SELECT COUNT(*) as count FROM `group_address_settings`")
        address_settings_count = cursor.fetchone()['count']
        
    finally:
        conn.close()
    
    return render_template('dashboard.html',
                         report_groups_count=report_groups_count,
                         reports_count=reports_count,
                         completed_reports_count=completed_reports_count,
                         cancelled_reports_count=cancelled_reports_count,
                         admins_count=admins_count,
                         antifraud_groups_count=antifraud_groups_count,
                         prohibited_words_count=prohibited_words_count,
                         verify_settings_count=verify_settings_count,
                         address_settings_count=address_settings_count)

# ==================== 报备机器人 - 群组管理 ====================

@app.route('/report/groups')
@login_required
def report_groups():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT * FROM `groups` ORDER BY `created_at` DESC")
        groups = cursor.fetchall()
        
        for group in groups:
            if 'used_deposit' not in group or group['used_deposit'] is None:
                group['used_deposit'] = 0.0
                
    finally:
        conn.close()
    
    return render_template('report/groups.html', groups=groups)

@app.route('/report/groups/add', methods=['POST'])
@login_required
def add_report_group():
    group_id = request.form.get('group_id')
    group_name = request.form.get('group_name')
    is_active = request.form.get('is_active') == 'on'
    
    if not group_id or not group_name:
        flash('群组ID和名称不能为空', 'danger')
        return redirect(url_for('report_groups'))
    
    # 解析群组名称
    group_code = ""
    deposit_amount = ""
    group_full_name = ""
    settlement_type = ""
    
    try:
        group_code_match = re.search(r'公群(\w+小组\d+)', group_name)
        if group_code_match:
            group_code = group_code_match.group(1)
        
        deposit_match = re.search(r'供押(\d+)U', group_name)
        if deposit_match:
            deposit_amount = deposit_match.group(1) + "U"
        
        name_match = re.search(r'U\s+(.+?)\s+（', group_name)
        if name_match:
            group_full_name = name_match.group(1)
        
        settlement_match = re.search(r'（(.+?)）', group_name)
        if settlement_match:
            settlement_type = settlement_match.group(1)
    except Exception as e:
        logger.error(f"解析群组名称失败: {str(e)}")
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute(
            """INSERT INTO `groups` 
            (`group_id`, `group_name`, `group_code`, `deposit_amount`, `group_full_name`, `settlement_type`, `is_active`) 
            VALUES (%s, %s, %s, %s, %s, %s, %s) 
            ON DUPLICATE KEY UPDATE 
            `group_name` = %s, `group_code` = %s, `deposit_amount` = %s, 
            `group_full_name` = %s, `settlement_type` = %s, `is_active` = %s""",
            (group_id, group_name, group_code, deposit_amount, group_full_name, settlement_type, is_active,
             group_name, group_code, deposit_amount, group_full_name, settlement_type, is_active)
        )
        conn.commit()
        flash('群组已添加/更新', 'success')
    except Exception as e:
        flash(f'添加群组失败: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('report_groups'))

@app.route('/report/groups/delete/<string:group_id>', methods=['POST'])
@login_required
def delete_report_group(group_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("DELETE FROM `groups` WHERE `group_id` = %s", (int(group_id),))
        conn.commit()
        flash('群组已删除', 'success')
    except Exception as e:
        flash(f'删除群组失败: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('report_groups'))

@app.route('/report/groups/activate/<string:group_id>', methods=['POST'])
@login_required
def activate_report_group(group_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("UPDATE `groups` SET `is_active` = 1 WHERE `group_id` = %s", (int(group_id),))
        conn.commit()
        flash('群组已激活', 'success')
    except Exception as e:
        flash(f'激活群组失败: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('report_groups'))

@app.route('/report/groups/deactivate/<string:group_id>', methods=['POST'])
@login_required
def deactivate_report_group(group_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("UPDATE `groups` SET `is_active` = 0 WHERE `group_id` = %s", (int(group_id),))
        conn.commit()
        flash('群组已停用', 'success')
    except Exception as e:
        flash(f'停用群组失败: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('report_groups'))

@app.route('/report/groups/reset_deposit/<string:group_id>', methods=['POST'])
@login_required
def reset_deposit(group_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("UPDATE `groups` SET `used_deposit` = 0 WHERE `group_id` = %s", (int(group_id),))
        conn.commit()
        flash('押金已重置', 'success')
    except Exception as e:
        flash(f'重置押金失败: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('report_groups'))

# ==================== 报备机器人 - 管理员管理 ====================

@app.route('/report/admins')
@login_required
def report_admins():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            SELECT a.*, g.group_name 
            FROM `admins` a 
            LEFT JOIN `groups` g ON a.group_id = g.group_id 
            ORDER BY a.created_at DESC
        """)
        admins = cursor.fetchall()
        
        cursor.execute("SELECT `group_id`, `group_name` FROM `groups` WHERE `is_active` = 1")
        groups = cursor.fetchall()
    finally:
        conn.close()
    
    return render_template('report/admins.html', admins=admins, groups=groups, 
                         super_admins=config.REPORT_SUPER_ADMIN_IDS)

@app.route('/report/admins/add', methods=['POST'])
@login_required
def add_report_admin():
    user_id = request.form.get('user_id')
    group_id = request.form.get('group_id')
    username = request.form.get('username', '')
    
    if not user_id or not group_id:
        flash('用户ID和群组ID不能为空', 'danger')
        return redirect(url_for('report_admins'))
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute(
            "INSERT INTO `admins` (`user_id`, `group_id`, `username`, `added_by`) VALUES (%s, %s, %s, %s)",
            (user_id, group_id, username, 0)
        )
        conn.commit()
        flash('管理员已添加', 'success')
    except pymysql.IntegrityError:
        flash('该用户已经是此群组的管理员', 'warning')
    except Exception as e:
        flash(f'添加管理员失败: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('report_admins'))

@app.route('/report/admins/delete/<int:admin_id>', methods=['POST'])
@login_required
def delete_report_admin(admin_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("DELETE FROM `admins` WHERE `id` = %s", (admin_id,))
        conn.commit()
        flash('管理员已删除', 'success')
    except Exception as e:
        flash(f'删除管理员失败: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('report_admins'))

# ==================== 报备机器人 - 报备记录 ====================

@app.route('/report/reports')
@login_required
def reports():
    filter_type = request.args.get('filter', 'all')
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        if filter_type == 'all':
            cursor.execute("SELECT * FROM `reports` ORDER BY `created_time` DESC")
        else:
            cursor.execute("SELECT * FROM `reports` WHERE `status` = %s ORDER BY `created_time` DESC", (filter_type,))
        
        reports = cursor.fetchall()
    finally:
        conn.close()
    
    return render_template('report/reports.html', reports=reports, filter_type=filter_type)

@app.route('/report/reports/delete/<report_id>', methods=['POST'])
@login_required
def delete_report(report_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("DELETE FROM `reports` WHERE `report_id` = %s", (report_id,))
        conn.commit()
        flash('报备已删除', 'success')
    except Exception as e:
        flash(f'删除报备失败: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('reports'))

# ==================== 防骗机器人 - 授权群组 ====================

@app.route('/antifraud/groups', methods=['GET', 'POST'])
@login_required
def antifraud_groups():
    if request.method == 'POST':
        chat_id = request.form.get('chat_id')
        group_name = request.form.get('group_name')
        expires_days = request.form.get('expires_days', type=int)
        
        if not chat_id or not group_name:
            flash('群组ID和名称不能为空', 'danger')
            return redirect(url_for('antifraud_groups'))
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        try:
            expires_at = None
            if expires_days:
                expires_at = datetime.now() + timedelta(days=expires_days)
            
            cursor.execute(
                """INSERT INTO `authorized_groups` 
                (`chat_id`, `group_name`, `authorized_by`, `expires_at`) 
                VALUES (%s, %s, %s, %s)
                ON DUPLICATE KEY UPDATE 
                `group_name` = %s, `is_active` = 1, `expires_at` = %s""",
                (chat_id, group_name, session['username'], expires_at, group_name, expires_at)
            )
            conn.commit()
            flash('群组已添加/更新', 'success')
        except Exception as e:
            flash(f'添加群组失败: {str(e)}', 'danger')
        finally:
            conn.close()
        
        return redirect(url_for('antifraud_groups'))
    
    # GET请求 - 显示列表
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT * FROM `authorized_groups` ORDER BY `created_at` DESC")
        groups = cursor.fetchall()
    finally:
        conn.close()
    
    return render_template('antifraud/groups.html', groups=groups)

@app.route('/antifraud/groups/delete/<int:group_id>', methods=['POST'])
@login_required
def delete_antifraud_group(group_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("DELETE FROM `authorized_groups` WHERE `id` = %s", (group_id,))
        conn.commit()
        flash('群组已删除', 'success')
    except Exception as e:
        flash(f'删除群组失败: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('antifraud_groups'))

@app.route('/antifraud/groups/toggle/<int:group_id>', methods=['POST'])
@login_required
def toggle_antifraud_group(group_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT `is_active` FROM `authorized_groups` WHERE `id` = %s", (group_id,))
        result = cursor.fetchone()
        if result:
            new_status = 0 if result['is_active'] else 1
            cursor.execute("UPDATE `authorized_groups` SET `is_active` = %s WHERE `id` = %s", (new_status, group_id))
            conn.commit()
            flash('群组状态已更新', 'success')
    except Exception as e:
        flash(f'更新群组状态失败: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('antifraud_groups'))

# ==================== 防骗机器人 - 违禁词 ====================

@app.route('/antifraud/prohibited_words', methods=['GET', 'POST'])
@login_required
def prohibited_words():
    if request.method == 'POST':
        word = request.form.get('word')
        is_exact_match = 'is_exact_match' in request.form
        action = request.form.get('action', 'mute')
        
        if not word:
            flash('违禁词不能为空', 'danger')
            return redirect(url_for('prohibited_words'))
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute(
                """INSERT INTO `prohibited_words` 
                (`word`, `is_exact_match`, `action`, `created_by`) 
                VALUES (%s, %s, %s, %s)""",
                (word, is_exact_match, action, session['username'])
            )
            conn.commit()
            flash('违禁词已添加', 'success')
        except Exception as e:
            flash(f'添加违禁词失败: {str(e)}', 'danger')
        finally:
            conn.close()
        
        return redirect(url_for('prohibited_words'))
    
    # GET请求 - 显示列表
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT * FROM `prohibited_words` ORDER BY `created_at` DESC")
        words = cursor.fetchall()
    finally:
        conn.close()
    
    return render_template('antifraud/prohibited_words.html', words=words)

@app.route('/antifraud/prohibited_words/delete/<int:word_id>', methods=['POST'])
@login_required
def delete_prohibited_word(word_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("DELETE FROM `prohibited_words` WHERE `id` = %s", (word_id,))
        conn.commit()
        flash('违禁词已删除', 'success')
    except Exception as e:
        flash(f'删除违禁词失败: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('prohibited_words'))

@app.route('/antifraud/prohibited_words/edit/<int:word_id>', methods=['GET', 'POST'])
@login_required
def edit_prohibited_word(word_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if request.method == 'POST':
        word = request.form.get('word')
        is_exact_match = 'is_exact_match' in request.form
        action = request.form.get('action', 'mute')
        
        if not word:
            flash('违禁词不能为空', 'danger')
            return redirect(url_for('edit_prohibited_word', word_id=word_id))
        
        try:
            cursor.execute(
                """UPDATE `prohibited_words` 
                SET `word` = %s, `is_exact_match` = %s, `action` = %s, `updated_at` = NOW()
                WHERE `id` = %s""",
                (word, is_exact_match, action, word_id)
            )
            conn.commit()
            flash('违禁词已更新', 'success')
            return redirect(url_for('prohibited_words'))
        except Exception as e:
            flash(f'更新违禁词失败: {str(e)}', 'danger')
        finally:
            conn.close()
    
    # GET请求 - 显示编辑表单
    try:
        cursor.execute("SELECT * FROM `prohibited_words` WHERE `id` = %s", (word_id,))
        word_data = cursor.fetchone()
        
        if not word_data:
            flash('违禁词不存在', 'danger')
            return redirect(url_for('prohibited_words'))
            
    finally:
        conn.close()
    
    return render_template('antifraud/edit_prohibited_word.html', word=word_data)

# ==================== 防骗机器人 - 验群设置 ====================

@app.route('/antifraud/verify_settings')
@login_required
def verify_settings():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            SELECT vs.*, ag.group_name 
            FROM `group_verify_settings` vs
            LEFT JOIN `authorized_groups` ag ON vs.chat_id = ag.chat_id
            ORDER BY vs.updated_at DESC
        """)
        settings = cursor.fetchall()
        
        cursor.execute("SELECT `chat_id`, `group_name` FROM `authorized_groups` WHERE `is_active` = 1")
        groups = cursor.fetchall()
    finally:
        conn.close()
    
    return render_template('antifraud/verify_settings.html', settings=settings, groups=groups)

@app.route('/antifraud/verify_settings/add', methods=['GET', 'POST'])
@login_required
def add_verify_setting():
    if request.method == 'POST':
        chat_id = request.form.get('chat_id')
        keyword = request.form.get('keyword', '验群')
        reply_message = request.form.get('reply_message')
        self_destruct_time = int(request.form.get('self_destruct_time', 100))
        
        if not chat_id or not reply_message:
            flash('群组ID和回复消息不能为空', 'danger')
            return redirect(url_for('add_verify_setting'))
        
        self_destruct_time = max(10, min(self_destruct_time, 600))
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute(
                """INSERT INTO `group_verify_settings` 
                (`chat_id`, `keyword`, `reply_message`, `self_destruct_time`, `created_by`) 
                VALUES (%s, %s, %s, %s, %s)
                ON DUPLICATE KEY UPDATE 
                `keyword` = %s, `reply_message` = %s, `self_destruct_time` = %s, `updated_at` = NOW()""",
                (chat_id, keyword, reply_message, self_destruct_time, session['username'],
                 keyword, reply_message, self_destruct_time)
            )
            conn.commit()
            flash('验群设置已添加/更新', 'success')
            return redirect(url_for('verify_settings'))
        except Exception as e:
            flash(f'添加验群设置失败: {str(e)}', 'danger')
        finally:
            conn.close()
    
    # GET请求 - 显示表单
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT `chat_id`, `group_name` FROM `authorized_groups` WHERE `is_active` = 1")
        groups = cursor.fetchall()
    finally:
        conn.close()
    
    return render_template('antifraud/add_verify_setting.html', groups=groups)

@app.route('/antifraud/verify_settings/edit/<int:setting_id>', methods=['GET', 'POST'])
@login_required
def edit_verify_setting(setting_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if request.method == 'POST':
        keyword = request.form.get('keyword', '验群')
        reply_message = request.form.get('reply_message')
        self_destruct_time = int(request.form.get('self_destruct_time', 100))
        
        if not reply_message:
            flash('回复消息不能为空', 'danger')
            return redirect(url_for('edit_verify_setting', setting_id=setting_id))
        
        self_destruct_time = max(10, min(self_destruct_time, 600))
        
        try:
            cursor.execute(
                """UPDATE `group_verify_settings` 
                SET `keyword` = %s, `reply_message` = %s, `self_destruct_time` = %s, `updated_at` = NOW()
                WHERE `id` = %s""",
                (keyword, reply_message, self_destruct_time, setting_id)
            )
            conn.commit()
            flash('验群设置已更新', 'success')
            return redirect(url_for('verify_settings'))
        except Exception as e:
            flash(f'更新验群设置失败: {str(e)}', 'danger')
        finally:
            conn.close()
    
    # GET请求 - 显示编辑表单
    try:
        cursor.execute("""
            SELECT vs.*, ag.group_name 
            FROM `group_verify_settings` vs
            LEFT JOIN `authorized_groups` ag ON vs.chat_id = ag.chat_id
            WHERE vs.id = %s
        """, (setting_id,))
        setting = cursor.fetchone()
        
        if not setting:
            flash('验群设置不存在', 'danger')
            return redirect(url_for('verify_settings'))
            
    finally:
        conn.close()
    
    return render_template('antifraud/edit_verify_setting.html', setting=setting)

@app.route('/antifraud/verify_settings/delete/<int:setting_id>', methods=['POST'])
@login_required
def delete_verify_setting(setting_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("DELETE FROM `group_verify_settings` WHERE `id` = %s", (setting_id,))
        conn.commit()
        flash('验群设置已删除', 'success')
    except Exception as e:
        flash(f'删除验群设置失败: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('verify_settings'))

# ==================== 防骗机器人 - 地址设置 ====================

@app.route('/antifraud/address_settings')
@login_required
def address_settings():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            SELECT ads.*, ag.group_name 
            FROM `group_address_settings` ads
            LEFT JOIN `authorized_groups` ag ON ads.chat_id = ag.chat_id
            ORDER BY ads.updated_at DESC
        """)
        settings = cursor.fetchall()
        
        cursor.execute("SELECT `chat_id`, `group_name` FROM `authorized_groups` WHERE `is_active` = 1")
        groups = cursor.fetchall()
    finally:
        conn.close()
    
    return render_template('antifraud/address_settings.html', settings=settings, groups=groups)

@app.route('/antifraud/address_settings/add', methods=['GET', 'POST'])
@login_required
def add_address_setting():
    if request.method == 'POST':
        chat_id = request.form.get('chat_id')
        enabled = 'enabled' in request.form
        reply_text = request.form.get('reply_text', '')
        reply_photo = request.form.get('reply_photo', '')
        is_exact_match = 'is_exact_match' in request.form
        self_destruct_time = int(request.form.get('self_destruct_time', 0))
        
        if not chat_id:
            flash('群组ID不能为空', 'danger')
            return redirect(url_for('add_address_setting'))
        
        if self_destruct_time > 0:
            self_destruct_time = max(10, min(self_destruct_time, 600))
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute(
                """INSERT INTO `group_address_settings` 
                (`chat_id`, `enabled`, `reply_text`, `reply_photo`, `is_exact_match`, `self_destruct_time`, `created_by`) 
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                ON DUPLICATE KEY UPDATE 
                `enabled` = %s, `reply_text` = %s, `reply_photo` = %s, `is_exact_match` = %s, 
                `self_destruct_time` = %s, `updated_at` = NOW()""",
                (chat_id, enabled, reply_text, reply_photo, is_exact_match, self_destruct_time, session['username'],
                 enabled, reply_text, reply_photo, is_exact_match, self_destruct_time)
            )
            conn.commit()
            flash('地址设置已添加/更新', 'success')
            return redirect(url_for('address_settings'))
        except Exception as e:
            flash(f'添加地址设置失败: {str(e)}', 'danger')
        finally:
            conn.close()
    
    # GET请求 - 显示表单
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT `chat_id`, `group_name` FROM `authorized_groups` WHERE `is_active` = 1")
        groups = cursor.fetchall()
    finally:
        conn.close()
    
    return render_template('antifraud/add_address_setting.html', groups=groups)

@app.route('/antifraud/address_settings/edit/<int:setting_id>', methods=['GET', 'POST'])
@login_required
def edit_address_setting(setting_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if request.method == 'POST':
        enabled = 'enabled' in request.form
        reply_text = request.form.get('reply_text', '')
        reply_photo = request.form.get('reply_photo', '')
        is_exact_match = 'is_exact_match' in request.form
        self_destruct_time = int(request.form.get('self_destruct_time', 0))
        
        if self_destruct_time > 0:
            self_destruct_time = max(10, min(self_destruct_time, 600))
        
        try:
            cursor.execute(
                """UPDATE `group_address_settings` 
                SET `enabled` = %s, `reply_text` = %s, `reply_photo` = %s, `is_exact_match` = %s,
                `self_destruct_time` = %s, `updated_at` = NOW()
                WHERE `id` = %s""",
                (enabled, reply_text, reply_photo, is_exact_match, self_destruct_time, setting_id)
            )
            conn.commit()
            flash('地址设置已更新', 'success')
            return redirect(url_for('address_settings'))
        except Exception as e:
            flash(f'更新地址设置失败: {str(e)}', 'danger')
        finally:
            conn.close()
    
    # GET请求 - 显示编辑表单
    try:
        cursor.execute("""
            SELECT ads.*, ag.group_name 
            FROM `group_address_settings` ads
            LEFT JOIN `authorized_groups` ag ON ads.chat_id = ag.chat_id
            WHERE ads.id = %s
        """, (setting_id,))
        setting = cursor.fetchone()
        
        if not setting:
            flash('地址设置不存在', 'danger')
            return redirect(url_for('address_settings'))
            
    finally:
        conn.close()
    
    return render_template('antifraud/edit_address_setting.html', setting=setting)

@app.route('/antifraud/address_settings/delete/<int:setting_id>', methods=['POST'])
@login_required
def delete_address_setting(setting_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("DELETE FROM `group_address_settings` WHERE `id` = %s", (setting_id,))
        conn.commit()
        flash('地址设置已删除', 'success')
    except Exception as e:
        flash(f'删除地址设置失败: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('address_settings'))

@app.route('/antifraud/address_settings/toggle/<int:setting_id>', methods=['POST'])
@login_required
def toggle_address_setting(setting_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT `enabled` FROM `group_address_settings` WHERE `id` = %s", (setting_id,))
        result = cursor.fetchone()
        if result:
            new_status = 0 if result['enabled'] else 1
            cursor.execute(
                "UPDATE `group_address_settings` SET `enabled` = %s, `updated_at` = NOW() WHERE `id` = %s", 
                (new_status, setting_id)
            )
            conn.commit()
            flash('地址设置状态已更新', 'success')
    except Exception as e:
        flash(f'更新地址设置状态失败: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('address_settings'))

# ==================== 文件上传 ====================

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/upload_image', methods=['POST'])
@login_required
def upload_image():
    if 'file' not in request.files:
        return jsonify({'success': False, 'error': '没有文件'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'success': False, 'error': '没有选择文件'}), 400
    
    if file:
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        url = url_for('uploaded_file', filename=filename, _external=True)
        return jsonify({'success': True, 'url': url})
    
    return jsonify({'success': False, 'error': '上传失败'}), 400

# ==================== 防骗机器人 - 机器人配置 ====================

@app.route('/antifraud/bot_config', methods=['GET'])
@login_required
def antifraud_bot_config():
    """机器人消息配置管理"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # 获取所有消息模板
        cursor.execute("SELECT * FROM `bot_message_templates` ORDER BY `id`")
        templates = cursor.fetchall()
        
        # 定义排序顺序
        order = ['welcome_message', 'verification_message', 'class_start_message', 'class_end_message', 'start_message']
        templates_sorted = sorted(templates, key=lambda x: order.index(x['template_key']) if x['template_key'] in order else 999)
        
        # 解析按钮JSON
        for template in templates_sorted:
            if template['buttons']:
                try:
                    template['buttons'] = json.loads(template['buttons'])
                except:
                    template['buttons'] = []
            else:
                template['buttons'] = []
        
        return render_template('antifraud/bot_config.html', templates=templates_sorted)
    finally:
        conn.close()

@app.route('/antifraud/keyword_matching', methods=['GET'])
@login_required
def antifraud_keyword_matching():
    """关键词匹配管理"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT * FROM `keyword_matching_settings` ORDER BY `created_at` DESC")
        keywords = cursor.fetchall()
        
        # 解析按钮JSON
        for kw in keywords:
            if kw['buttons']:
                try:
                    kw['buttons'] = json.loads(kw['buttons'])
                except:
                    kw['buttons'] = []
            else:
                kw['buttons'] = []
        
        return render_template('antifraud/keyword_matching.html', keywords=keywords)
    finally:
        conn.close()

@app.route('/antifraud/keyword_matching/add', methods=['GET', 'POST'])
@login_required
def add_keyword_matching():
    """添加关键词匹配"""
    if request.method == 'POST':
        keyword = request.form.get('keyword', '').strip()
        reply_text = request.form.get('reply_text', '').strip()
        enabled = 1 if request.form.get('enabled') == 'on' else 0
        
        # 处理按钮
        button_texts = request.form.getlist('button_text[]')
        button_urls = request.form.getlist('button_url[]')
        
        buttons = []
        for text, url in zip(button_texts, button_urls):
            if text.strip() and url.strip():
                buttons.append({"text": text.strip(), "url": url.strip()})
        
        buttons_json = json.dumps(buttons, ensure_ascii=False) if buttons else None
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute(
                "INSERT INTO `keyword_matching_settings` (`keyword`, `reply_text`, `buttons`, `enabled`) VALUES (%s, %s, %s, %s)",
                (keyword, reply_text, buttons_json, enabled)
            )
            conn.commit()
            flash('关键词匹配已添加', 'success')
            return redirect(url_for('antifraud_keyword_matching'))
        except Exception as e:
            flash(f'添加失败: {str(e)}', 'danger')
        finally:
            conn.close()
    
    return render_template('antifraud/add_keyword_matching.html')

@app.route('/antifraud/keyword_matching/edit/<int:keyword_id>', methods=['GET', 'POST'])
@login_required
def edit_keyword_matching(keyword_id):
    """编辑关键词匹配"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if request.method == 'POST':
        keyword = request.form.get('keyword', '').strip()
        reply_text = request.form.get('reply_text', '').strip()
        enabled = 1 if request.form.get('enabled') == 'on' else 0
        
        # 处理按钮
        button_texts = request.form.getlist('button_text[]')
        button_urls = request.form.getlist('button_url[]')
        
        buttons = []
        for text, url in zip(button_texts, button_urls):
            if text.strip() and url.strip():
                buttons.append({"text": text.strip(), "url": url.strip()})
        
        buttons_json = json.dumps(buttons, ensure_ascii=False) if buttons else None
        
        try:
            cursor.execute(
                "UPDATE `keyword_matching_settings` SET `keyword` = %s, `reply_text` = %s, `buttons` = %s, `enabled` = %s WHERE `id` = %s",
                (keyword, reply_text, buttons_json, enabled, keyword_id)
            )
            conn.commit()
            flash('关键词匹配已更新', 'success')
            return redirect(url_for('antifraud_keyword_matching'))
        except Exception as e:
            flash(f'更新失败: {str(e)}', 'danger')
        finally:
            conn.close()
    
    try:
        cursor.execute("SELECT * FROM `keyword_matching_settings` WHERE `id` = %s", (keyword_id,))
        keyword_data = cursor.fetchone()
        
        if not keyword_data:
            flash('关键词匹配不存在', 'danger')
            return redirect(url_for('antifraud_keyword_matching'))
        
        # 解析按钮
        buttons = []
        if keyword_data['buttons']:
            buttons = json.loads(keyword_data['buttons'])
        
        return render_template('antifraud/edit_keyword_matching.html', keyword=keyword_data, buttons=buttons)
    finally:
        conn.close()

@app.route('/antifraud/keyword_matching/delete/<int:keyword_id>', methods=['POST'])
@login_required
def delete_keyword_matching(keyword_id):
    """删除关键词匹配"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("DELETE FROM `keyword_matching_settings` WHERE `id` = %s", (keyword_id,))
        conn.commit()
        flash('关键词匹配已删除', 'success')
    except Exception as e:
        flash(f'删除失败: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('antifraud_keyword_matching'))

@app.route('/antifraud/keyword_matching/toggle/<int:keyword_id>', methods=['POST'])
@login_required
def toggle_keyword_matching(keyword_id):
    """切换关键词匹配启用状态"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("UPDATE `keyword_matching_settings` SET `enabled` = NOT `enabled` WHERE `id` = %s", (keyword_id,))
        conn.commit()
        flash('状态已更新', 'success')
    except Exception as e:
        flash(f'更新失败: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('antifraud_keyword_matching'))

@app.route('/antifraud/bot_config/edit/<int:template_id>', methods=['GET', 'POST'])
@login_required
def edit_bot_config(template_id):
    """编辑消息模板"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if request.method == 'POST':
        try:
            template_content = request.form.get('template_content')
            
            # 获取按钮数据
            button_texts = request.form.getlist('button_text[]')
            button_urls = request.form.getlist('button_url[]')
            
            # 构建按钮JSON
            buttons = []
            for text, url in zip(button_texts, button_urls):
                if text.strip() and url.strip():
                    buttons.append({
                        'text': text.strip(),
                        'url': url.strip()
                    })
            
            # 更新模板
            cursor.execute('''
                UPDATE bot_message_templates 
                SET template_content = %s, buttons = %s, updated_by = %s, updated_at = NOW()
                WHERE id = %s
            ''', (template_content, json.dumps(buttons, ensure_ascii=False), session.get('username', 'admin'), template_id))
            
            conn.commit()
            flash('模板更新成功！', 'success')
            return redirect(url_for('antifraud_bot_config'))
        except Exception as e:
            logger.error(f"更新模板失败: {e}")
            flash(f'更新失败: {str(e)}', 'danger')
            conn.rollback()
    
    # GET请求 - 显示编辑表单
    try:
        cursor.execute('SELECT * FROM bot_message_templates WHERE id = %s', (template_id,))
        template = cursor.fetchone()
        
        if not template:
            flash('模板不存在', 'danger')
            return redirect(url_for('antifraud_bot_config'))
        
        # 解析按钮JSON
        if template['buttons']:
            template['buttons'] = json.loads(template['buttons'])
        else:
            template['buttons'] = []
        
        return render_template('antifraud/edit_bot_config.html', template=template)
    except Exception as e:
        logger.error(f"获取模板失败: {e}")
        flash(f'获取模板失败: {str(e)}', 'danger')
        return redirect(url_for('antifraud_bot_config'))
    finally:
        conn.close()

# ==================== API接口 ====================

@app.route('/api/check_auth/<chat_id>')
def api_check_auth(chat_id):
    """检查群组授权API（供防骗机器人调用）"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute(
            "SELECT * FROM `authorized_groups` WHERE `chat_id` = %s AND `is_active` = 1",
            (str(chat_id),)
        )
        group = cursor.fetchone()
        
        if not group:
            return jsonify({'authorized': False})
        
        # 检查是否过期
        if group.get('expires_at') and group['expires_at'] < datetime.now():
            cursor.execute(
                "UPDATE `authorized_groups` SET `is_active` = 0 WHERE `chat_id` = %s",
                (str(chat_id),)
            )
            conn.commit()
            return jsonify({'authorized': False})
        
        return jsonify({'authorized': True})
    except:
        return jsonify({'authorized': True})  # 默认允许
    finally:
        conn.close()

@app.route('/api/bot_template/<template_key>')
def api_get_template(template_key):
    """获取消息模板API（供机器人调用）"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute(
            "SELECT template_content, buttons FROM bot_message_templates WHERE template_key = %s",
            (template_key,)
        )
        template = cursor.fetchone()
        
        if not template:
            return jsonify({'success': False, 'error': '模板不存在'})
        
        # 解析按钮
        buttons = []
        if template['buttons']:
            buttons = json.loads(template['buttons'])
        
        return jsonify({
            'success': True,
            'content': template['template_content'],
            'buttons': buttons
        })
    except Exception as e:
        logger.error(f"获取模板失败: {e}")
        return jsonify({'success': False, 'error': str(e)})
    finally:
        conn.close()

@app.route('/api/keyword_matching')
def api_get_keyword_matching():
    """获取所有启用的关键词匹配API（供机器人调用）"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT * FROM `keyword_matching_settings` WHERE `enabled` = 1")
        keywords = cursor.fetchall()
        
        result = {}
        for kw in keywords:
            buttons = []
            if kw['buttons']:
                buttons = json.loads(kw['buttons'])
            
            result[kw['keyword']] = {
                'reply_text': kw['reply_text'],
                'buttons': buttons
            }
        
        return jsonify({
            'success': True,
            'data': result
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})
    finally:
        conn.close()

@app.route('/api/get_prohibited_words')
def api_get_prohibited_words():
    """获取所有违禁词API"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT * FROM `prohibited_words`")
        words = cursor.fetchall()
        return jsonify({
            'success': True,
            'words': [{
                'id': word['id'],
                'word': word['word'],
                'is_exact_match': word['is_exact_match'],
                'action': word['action']
            } for word in words]
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        conn.close()

@app.route('/api/get_verify_setting/<chat_id>')
def api_get_verify_setting(chat_id):
    """获取群组验群设置API"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT * FROM `group_verify_settings` WHERE `chat_id` = %s", (str(chat_id),))
        setting = cursor.fetchone()
        
        if setting:
            return jsonify({
                'success': True,
                'setting': {
                    'keyword': setting['keyword'],
                    'reply_message': setting['reply_message'],
                    'self_destruct_time': setting['self_destruct_time']
                }
            })
        else:
            return jsonify({'success': False, 'error': '未找到设置'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        conn.close()

@app.route('/api/get_address_setting/<chat_id>')
def api_get_address_setting(chat_id):
    """获取群组地址设置API"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT * FROM `group_address_settings` WHERE `chat_id` = %s", (str(chat_id),))
        setting = cursor.fetchone()
        
        if setting:
            return jsonify({
                'success': True,
                'data': {
                    'enabled': setting['enabled'],
                    'reply_text': setting['reply_text'],
                    'reply_photo': setting['reply_photo'],
                    'is_exact_match': setting['is_exact_match'],
                    'self_destruct_time': setting['self_destruct_time']
                }
            })
        else:
            return jsonify({'success': False, 'error': '未找到设置'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        conn.close()

@app.route('/api/get_group_settings/<chat_id>')
def api_get_group_settings(chat_id):
    """获取群组设置API"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT * FROM `group_settings` WHERE `chat_id` = %s", (str(chat_id),))
        setting = cursor.fetchone()
        
        if setting:
            settings_data = setting['settings']
            # 如果是字符串，需要解析为字典
            if isinstance(settings_data, str):
                settings_data = json.loads(settings_data)
            
            return jsonify({
                'success': True,
                'settings': settings_data
            })
        else:
            return jsonify({'success': False, 'error': '未找到设置'})
    except Exception as e:
        logger.error(f"获取群组设置失败: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        conn.close()

@app.route('/api/update_group_settings/<chat_id>', methods=['POST'])
def api_update_group_settings(chat_id):
    """更新群组设置API"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        data = request.get_json()
        settings = data.get('settings')
        
        if not settings:
            return jsonify({'success': False, 'error': '缺少settings参数'}), 400
        
        # 检查记录是否存在
        cursor.execute("SELECT id FROM `group_settings` WHERE `chat_id` = %s", (str(chat_id),))
        existing = cursor.fetchone()
        
        if existing:
            # 更新
            cursor.execute("""
                UPDATE `group_settings` 
                SET `settings` = %s, `updated_at` = NOW() 
                WHERE `chat_id` = %s
            """, (json.dumps(settings), str(chat_id)))
        else:
            # 插入
            cursor.execute("""
                INSERT INTO `group_settings` (`chat_id`, `settings`) 
                VALUES (%s, %s)
            """, (str(chat_id), json.dumps(settings)))
        
        conn.commit()
        logger.info(f"已更新群组 {chat_id} 的设置")
        
        return jsonify({'success': True, 'message': '设置已更新'})
    except Exception as e:
        conn.rollback()
        logger.error(f"更新群组设置失败: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        conn.close()

# ==================== 客服机器人配置 ====================

@app.route('/xinbi/config')
@login_required
def xinbi_config():
    """客服机器人配置页面"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # 获取全局配置
        cursor.execute("SELECT * FROM `xinbi_bot_config` ORDER BY `config_key`")
        configs = cursor.fetchall()
        config_dict = {c['config_key']: c['config_value'] for c in configs}
        
        # 获取按钮配置
        cursor.execute("SELECT * FROM `xinbi_bot_buttons` ORDER BY `button_order`, `id`")
        buttons = cursor.fetchall()
        
        # 解析每个按钮的 config_data（从JSON字符串到字典）
        for button in buttons:
            if button.get('config_data'):
                if isinstance(button['config_data'], str):
                    try:
                        button['config_data'] = json.loads(button['config_data'])
                    except:
                        pass
        
        return render_template('xinbi/config.html',
                             configs=config_dict,
                             buttons=buttons)
    finally:
        conn.close()

@app.route('/xinbi/config/update', methods=['POST'])
@login_required
def xinbi_config_update():
    """更新客服机器人全局配置"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        admin_group_id = request.form.get('admin_group_id', '').strip()
        welcome_message = request.form.get('welcome_message', '').strip()
        
        # 更新管理员群组ID
        cursor.execute("""
            UPDATE `xinbi_bot_config` 
            SET `config_value` = %s 
            WHERE `config_key` = 'admin_group_id'
        """, (admin_group_id,))
        
        # 更新欢迎消息
        cursor.execute("""
            UPDATE `xinbi_bot_config` 
            SET `config_value` = %s 
            WHERE `config_key` = 'welcome_message'
        """, (welcome_message,))
        
        conn.commit()
        flash('全局配置已更新', 'success')
        
    except Exception as e:
        conn.rollback()
        flash(f'更新失败：{str(e)}', 'danger')
        logger.error(f"更新客服机器人配置失败: {e}")
    finally:
        conn.close()
    
    return redirect(url_for('xinbi_config'))

@app.route('/xinbi/button/<int:button_id>/edit', methods=['GET', 'POST'])
@login_required
def xinbi_button_edit(button_id):
    """编辑按钮配置"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if request.method == 'POST':
        try:
            button_text = request.form.get('button_text', '').strip()
            button_order = int(request.form.get('button_order', 0))
            is_enabled = 1 if request.form.get('is_enabled') == '1' else 0
            config_data = request.form.get('config_data', '').strip()
            
            # 验证JSON格式
            if config_data:
                try:
                    json.loads(config_data)
                except json.JSONDecodeError as e:
                    flash(f'配置JSON格式错误：{str(e)}', 'danger')
                    raise
            
            cursor.execute("""
                UPDATE `xinbi_bot_buttons` 
                SET `button_text` = %s,
                    `config_data` = %s,
                    `button_order` = %s,
                    `is_enabled` = %s
                WHERE `id` = %s
            """, (button_text, config_data if config_data else None, button_order, is_enabled, button_id))
            
            conn.commit()
            flash('按钮配置已更新', 'success')
            return redirect(url_for('xinbi_config'))
            
        except Exception as e:
            conn.rollback()
            flash(f'更新失败：{str(e)}', 'danger')
            logger.error(f"更新按钮配置失败: {e}")
    
    # GET请求，显示编辑表单
    try:
        cursor.execute("SELECT * FROM `xinbi_bot_buttons` WHERE `id` = %s", (button_id,))
        button = cursor.fetchone()
        
        if not button:
            flash('按钮不存在', 'danger')
            return redirect(url_for('xinbi_config'))
        
        # 解析JSON配置
        if button.get('config_data'):
            if isinstance(button['config_data'], str):
                try:
                    button['config_data'] = json.loads(button['config_data'])
                except:
                    pass
        
        return render_template('xinbi/edit_button.html', button=button)
    finally:
        conn.close()

def run():
    """运行Web管理后台"""
    app.run(
        host=config.WEB_HOST,
        port=config.WEB_PORT,
        debug=False,
        use_reloader=False
    )

if __name__ == '__main__':
    run()
