from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
import os
import pymysql
import config
from functools import wraps
import secrets
import logging
import sys  # 添加sys模块导入
import re  # 添加re模块导入

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('web_admin.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# 创建Flask应用
app = Flask(__name__)
web_config = config.get_web_admin_config()
app.secret_key = web_config.get('secret_key', secrets.token_hex(16))

# 登录所需的用户名和密码
ADMIN_USERNAME = web_config.get('username', 'admin')
ADMIN_PASSWORD = web_config.get('password', 'admin')

# 登录验证装饰器
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session:
            flash('请先登录', 'danger')
            return redirect(url_for('login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function

# 获取数据库连接
def get_db_connection():
    return pymysql.connect(**config.get_db_config())

@app.route('/')
def index():
    if 'logged_in' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session['logged_in'] = True
            flash('登录成功', 'success')
            next_page = request.args.get('next')
            return redirect(next_page or url_for('dashboard'))
        else:
            flash('用户名或密码错误', 'danger')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    flash('已退出登录', 'info')
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    # 获取统计数据
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # 获取群组数量
        cursor.execute("SELECT COUNT(*) as count FROM `groups`")
        groups_count = cursor.fetchone()['count']
        
        # 获取管理员数量
        cursor.execute("SELECT COUNT(*) as count FROM `admins`")
        admins_count = cursor.fetchone()['count']
        
        # 获取报备数量
        cursor.execute("SELECT COUNT(*) as count FROM `reports`")
        reports_count = cursor.fetchone()['count']
        
        # 获取已完成报备数量
        cursor.execute("SELECT COUNT(*) as count FROM `reports` WHERE `status` = 'completed'")
        completed_reports_count = cursor.fetchone()['count']
        
        # 获取已取消报备数量
        cursor.execute("SELECT COUNT(*) as count FROM `reports` WHERE `status` = 'cancelled'")
        cancelled_reports_count = cursor.fetchone()['count']
        
    finally:
        conn.close()
    
    return render_template(
        'dashboard.html',
        groups_count=groups_count,
        admins_count=admins_count,
        reports_count=reports_count,
        completed_reports_count=completed_reports_count,
        cancelled_reports_count=cancelled_reports_count
    )

@app.route('/config', methods=['GET', 'POST'])
@login_required
def config_page():
    if request.method == 'POST':
        # 更新机器人配置
        bot_token = request.form.get('bot_token')
        if bot_token:
            config.update_bot_token(bot_token)
        
        # 更新数据库配置
        db_host = request.form.get('db_host')
        db_user = request.form.get('db_user')
        db_password = request.form.get('db_password')
        db_name = request.form.get('db_name')
        
        if db_host and db_user and db_name:
            config.update_db_config(db_host, db_user, db_password, db_name)
        
        # 更新Web管理后台配置
        web_host = request.form.get('web_host')
        web_port = request.form.get('web_port')
        web_secret_key = request.form.get('web_secret_key')
        web_username = request.form.get('web_username')
        web_password = request.form.get('web_password')
        
        config.update_web_admin_config(
            host=web_host,
            port=int(web_port) if web_port else None,
            secret_key=web_secret_key,
            username=web_username,
            password=web_password
        )
        
        flash('配置已更新', 'success')
        return redirect(url_for('config_page'))
    
    # 获取当前配置
    current_config = {
        'bot_token': config.get_bot_token(),
        'super_admin_ids': config.get_super_admin_ids(),
        'database': config.config.get('database', {}),
        'web_admin': config.config.get('web_admin', {})
    }
    
    return render_template('config.html', config=current_config)

@app.route('/groups')
@login_required
def groups():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT * FROM `groups` ORDER BY `created_at` DESC")
        groups = cursor.fetchall()
        
        # 为每个群组添加格式化的显示信息
        for group in groups:
            group_info = []
            if group.get('group_code'):
                group_info.append(f"组名：公群{group['group_code']}")
            if group.get('deposit_amount'):
                group_info.append(f"供押：{group['deposit_amount']}")
            if group.get('group_full_name'):
                group_info.append(f"名称：{group['group_full_name']}")
            if group.get('settlement_type'):
                group_info.append(f"结算：{group['settlement_type']}")
            
            group['formatted_info'] = "\n".join(group_info) if group_info else ""
            
            # 确保used_deposit字段存在
            if 'used_deposit' not in group or group['used_deposit'] is None:
                group['used_deposit'] = 0.0
            
    finally:
        conn.close()
    
    return render_template('groups.html', groups=groups)

@app.route('/groups/add', methods=['POST'])
@login_required
def add_group():
    group_id = request.form.get('group_id')
    group_name = request.form.get('group_name')
    is_active = request.form.get('is_active') == 'on'
    
    if not group_id or not group_name:
        flash('群组ID和名称不能为空', 'danger')
        return redirect(url_for('groups'))
    
    # 尝试解析群组名称格式
    group_code = ""
    deposit_amount = ""
    group_full_name = ""
    settlement_type = ""
    
    try:
        # 尝试解析格式：公群H小组9555 -供押46666U 刘老根卡商公群 （月结）
        
        # 提取组名
        group_code_match = re.search(r'公群(\w+小组\d+)', group_name)
        if group_code_match:
            group_code = group_code_match.group(1)
        
        # 提取供押金额
        deposit_match = re.search(r'供押(\d+)U', group_name)
        if deposit_match:
            deposit_amount = deposit_match.group(1) + "U"
        
        # 提取名称（在供押和结算之间的部分）
        name_match = re.search(r'U\s+(.+?)\s+（', group_name)
        if name_match:
            group_full_name = name_match.group(1)
        
        # 提取结算方式
        settlement_match = re.search(r'（(.+?)）', group_name)
        if settlement_match:
            settlement_type = settlement_match.group(1)
    except Exception as e:
        logger.error(f"解析群组名称失败: {str(e)}")
        # 解析失败不影响添加群组
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute(
            "INSERT INTO `groups` (`group_id`, `group_name`, `group_code`, `deposit_amount`, `group_full_name`, `settlement_type`, `is_active`) VALUES (%s, %s, %s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE `group_name` = %s, `group_code` = %s, `deposit_amount` = %s, `group_full_name` = %s, `settlement_type` = %s, `is_active` = %s",
            (group_id, group_name, group_code, deposit_amount, group_full_name, settlement_type, is_active, group_name, group_code, deposit_amount, group_full_name, settlement_type, is_active)
        )
        conn.commit()
        flash('群组已添加/更新', 'success')
    except Exception as e:
        flash(f'添加群组失败: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('groups'))

@app.route('/groups/delete/<string:group_id>', methods=['POST'])
@login_required
def delete_group(group_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        group_id_int = int(group_id)
        cursor.execute("DELETE FROM `groups` WHERE `group_id` = %s", (group_id_int,))
        conn.commit()
        flash('群组已删除', 'success')
    except ValueError:
        flash('无效的群组ID', 'danger')
    except Exception as e:
        flash(f'删除群组失败: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('groups'))

@app.route('/groups/reset_deposit/<string:group_id>', methods=['POST'])
@login_required
def reset_group_deposit_route(group_id):
    try:
        group_id_int = int(group_id)
        
        # 直接在web_admin中实现重置押金逻辑，不再导入bot模块
        conn = get_db_connection()
        cursor = conn.cursor()
        
        try:
            # 更新数据库，将已使用押金重置为0
            cursor.execute(
                "UPDATE `groups` SET `used_deposit` = 0.0 WHERE `group_id` = %s",
                (group_id_int,)
            )
            conn.commit()
            
            # 更新所有该群组的报备记录，将deposit_updated标记为False
            cursor.execute(
                "UPDATE `reports` SET `deposit_updated` = 0 WHERE `group_chat_id` = %s",
                (group_id_int,)
            )
            conn.commit()
            
            flash('群组押金已重置为0', 'success')
            return redirect(url_for('groups'))
        except Exception as e:
            logger.error(f"重置押金使用情况失败: {str(e)}")
            flash(f'重置群组押金失败: {str(e)}', 'danger')
        finally:
            conn.close()
    except ValueError:
        flash('无效的群组ID', 'danger')
    
    return redirect(url_for('groups'))

@app.route('/groups/activate/<string:group_id>', methods=['POST'])
@login_required
def activate_group(group_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # 将字符串转换为整数
        group_id_int = int(group_id)
        cursor.execute("UPDATE `groups` SET `is_active` = 1 WHERE `group_id` = %s", (group_id_int,))
        conn.commit()
        flash('群组已激活', 'success')
    except ValueError:
        flash('无效的群组ID', 'danger')
    except Exception as e:
        flash(f'激活群组失败: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('groups'))

@app.route('/groups/deactivate/<string:group_id>', methods=['POST'])
@login_required
def deactivate_group(group_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # 将字符串转换为整数
        group_id_int = int(group_id)
        cursor.execute("UPDATE `groups` SET `is_active` = 0 WHERE `group_id` = %s", (group_id_int,))
        conn.commit()
        flash('群组已停用', 'success')
    except ValueError:
        flash('无效的群组ID', 'danger')
    except Exception as e:
        flash(f'停用群组失败: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('groups'))

@app.route('/admins')
@login_required
def admins():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            SELECT a.*, g.group_name 
            FROM `admins` a 
            LEFT JOIN `groups` g ON a.group_id = g.group_id 
            ORDER BY a.created_at DESC
        """)
        admins = cursor.fetchall()
        
        cursor.execute("SELECT `group_id`, `group_name` FROM `groups` WHERE `is_active` = 1")
        groups = cursor.fetchall()
    finally:
        conn.close()
    
    return render_template('admins.html', admins=admins, groups=groups, super_admins=config.get_super_admin_ids())

@app.route('/admins/add', methods=['POST'])
@login_required
def add_admin():
    user_id = request.form.get('user_id')
    group_id = request.form.get('group_id')
    username = request.form.get('username', '')
    
    if not user_id or not group_id:
        flash('用户ID和群组ID不能为空', 'danger')
        return redirect(url_for('admins'))
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute(
            "INSERT INTO `admins` (`user_id`, `group_id`, `username`, `added_by`) VALUES (%s, %s, %s, %s)",
            (user_id, group_id, username, 0)  # 0表示通过Web管理后台添加
        )
        conn.commit()
        flash('管理员已添加', 'success')
    except pymysql.IntegrityError:
        flash('该用户已经是此群组的管理员', 'warning')
    except Exception as e:
        flash(f'添加管理员失败: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('admins'))

@app.route('/admins/delete/<int:admin_id>', methods=['POST'])
@login_required
def delete_admin(admin_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("DELETE FROM `admins` WHERE `id` = %s", (admin_id,))
        conn.commit()
        flash('管理员已删除', 'success')
    except Exception as e:
        flash(f'删除管理员失败: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('admins'))

@app.route('/super_admins/add', methods=['POST'])
@login_required
def add_super_admin():
    user_id = request.form.get('user_id')
    
    if not user_id:
        flash('用户ID不能为空', 'danger')
        return redirect(url_for('admins'))
    
    try:
        user_id = int(user_id)
        config.add_super_admin(user_id)
        flash('超级管理员已添加', 'success')
    except ValueError:
        flash('用户ID必须是数字', 'danger')
    except Exception as e:
        flash(f'添加超级管理员失败: {str(e)}', 'danger')
    
    return redirect(url_for('admins'))

@app.route('/super_admins/delete/<int:user_id>', methods=['POST'])
@login_required
def delete_super_admin(user_id):
    try:
        config.remove_super_admin(user_id)
        flash('超级管理员已删除', 'success')
    except Exception as e:
        flash(f'删除超级管理员失败: {str(e)}', 'danger')
    
    return redirect(url_for('admins'))

@app.route('/reports')
@login_required
def reports():
    filter_type = request.args.get('filter', 'all')
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        if filter_type == 'all':
            cursor.execute("SELECT * FROM `reports` ORDER BY `created_time` DESC")
        else:
            cursor.execute("SELECT * FROM `reports` WHERE `status` = %s ORDER BY `created_time` DESC", (filter_type,))
        
        reports = cursor.fetchall()
    finally:
        conn.close()
    
    return render_template('reports.html', reports=reports, filter_type=filter_type)

@app.route('/reports/delete/<report_id>', methods=['POST'])
@login_required
def delete_report(report_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # 首先获取报备信息，特别是金额和群组ID
        cursor.execute("SELECT * FROM `reports` WHERE `report_id` = %s", (report_id,))
        report = cursor.fetchone()
        
        if report:
            # 如果报备已确认且押金已更新，则恢复押金
            if (report.get('status') == 'confirmed' or report.get('status') == 'completed') and report.get('deposit_updated'):
                group_id = report.get('group_chat_id')
                
                if group_id:
                    # 尝试从报备信息中提取交易金额
                    amount = 0.0
                    amount_match = re.search(r'交易总金额:(.*?)(?:\n|$)', report.get('info', ''))
                    if amount_match:
                        amount_text = amount_match.group(1).strip()
                        # 尝试提取数字
                        amount_num_match = re.search(r'(\d+(?:\.\d+)?)', amount_text)
                        if amount_num_match:
                            try:
                                amount = float(amount_num_match.group(1))
                            except ValueError:
                                pass
                    
                    if amount > 0:
                        # 直接更新押金使用情况，不再导入bot模块
                        try:
                            # 获取当前押金使用情况
                            cursor.execute("SELECT `used_deposit` FROM `groups` WHERE `group_id` = %s", (group_id,))
                            group = cursor.fetchone()
                            
                            if group:
                                current_used = float(group.get('used_deposit', 0.0))
                                
                                # 计算新的已使用押金（减少）
                                new_used = current_used - amount
                                if new_used < 0:
                                    new_used = 0  # 确保已使用押金不为负
                                
                                # 更新数据库
                                cursor.execute(
                                    "UPDATE `groups` SET `used_deposit` = %s WHERE `group_id` = %s",
                                    (new_used, group_id)
                                )
                                conn.commit()
                        except Exception as e:
                            logger.error(f"恢复押金失败: {str(e)}")
        
        # 删除报备
        cursor.execute("DELETE FROM `reports` WHERE `report_id` = %s", (report_id,))
        conn.commit()
        flash('报备已删除，相关押金已恢复', 'success')
    except Exception as e:
        flash(f'删除报备失败: {str(e)}', 'danger')
    finally:
        conn.close()
    
    return redirect(url_for('reports'))

@app.route('/api/stats')
@login_required
def api_stats():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # 获取最近7天的报备数量
        cursor.execute("""
            SELECT DATE(created_time) as date, COUNT(*) as count 
            FROM `reports` 
            WHERE created_time >= DATE_SUB(NOW(), INTERVAL 7 DAY)
            GROUP BY DATE(created_time)
            ORDER BY date
        """)
        daily_reports = cursor.fetchall()
        
        # 获取各状态的报备数量
        cursor.execute("""
            SELECT status, COUNT(*) as count 
            FROM `reports` 
            GROUP BY status
        """)
        status_counts = cursor.fetchall()
        
    except Exception as e:
        logger.error(f"获取统计数据失败: {str(e)}")
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()
    
    return jsonify({
        'daily_reports': [{'date': str(r['date']), 'count': r['count']} for r in daily_reports],
        'status_counts': [{'status': r['status'], 'count': r['count']} for r in status_counts]
    })

# 创建模板目录
os.makedirs('templates', exist_ok=True)
os.makedirs('static', exist_ok=True)

if __name__ == '__main__':
    # 确保配置已加载
    config.load_config()
    
    # 启动Web服务器
    app.run(
        host=web_config.get('host', '0.0.0.0'),
        port=web_config.get('port', 5000),
        debug=True
    ) 