#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
统一配置模块
从 .env 文件加载配置
"""

import os
from dotenv import load_dotenv
from pymysql.cursors import DictCursor

# 加载 .env 文件
load_dotenv()

# ========== 数据库配置 ==========
DB_HOST = os.getenv('DB_HOST', 'localhost')
DB_PORT = int(os.getenv('DB_PORT', 3306))
DB_USER = os.getenv('DB_USER', 'root')
DB_PASSWORD = os.getenv('DB_PASSWORD', '')
DB_NAME = os.getenv('DB_NAME', 'unified_bot_db')

# ========== Web管理后台配置 ==========
WEB_HOST = os.getenv('WEB_HOST', '0.0.0.0')
WEB_PORT = int(os.getenv('WEB_PORT', 3002))
WEB_USERNAME = os.getenv('WEB_USERNAME', 'admin')
WEB_PASSWORD = os.getenv('WEB_PASSWORD', 'admin123')
SECRET_KEY = os.getenv('SECRET_KEY', 'your-secret-key')

# ========== 报备机器人配置 ==========
REPORT_BOT_TOKEN = os.getenv('REPORT_BOT_TOKEN', '')
REPORT_BOT_ENABLED = os.getenv('REPORT_BOT_ENABLED', 'true').lower() == 'true'
REPORT_SUPER_ADMIN_IDS = [int(x) for x in os.getenv('REPORT_SUPER_ADMIN_IDS', '').split(',') if x]
REPORT_MENTION_USERNAME = os.getenv('REPORT_MENTION_USERNAME', '')
REPORT_MENTION_TEXT = os.getenv('REPORT_MENTION_TEXT', '')

# ========== 防骗机器人配置 ==========
ANTIFRAUD_BOT_TOKEN = os.getenv('ANTIFRAUD_BOT_TOKEN', '')
ANTIFRAUD_BOT_ENABLED = os.getenv('ANTIFRAUD_BOT_ENABLED', 'true').lower() == 'true'
ANTIFRAUD_ADMIN_IDS = [int(x) for x in os.getenv('ANTIFRAUD_ADMIN_IDS', '').split(',') if x]

# ========== 新币机器人配置 ==========
XINBI_BOT_TOKEN = os.getenv('XINBI_BOT_TOKEN', '')
XINBI_BOT_ENABLED = os.getenv('XINBI_BOT_ENABLED', 'true').lower() == 'true'
XINBI_ADMIN_GROUP_ID = int(os.getenv('XINBI_ADMIN_GROUP_ID', '0')) if os.getenv('XINBI_ADMIN_GROUP_ID') else None

# ========== 报备机器人兼容配置 ==========
def get_db_config():
    """获取数据库配置（报备机器人格式）"""
    return {
        'host': DB_HOST,
        'port': DB_PORT,
        'user': DB_USER,
        'password': DB_PASSWORD,
        'db': DB_NAME,
        'charset': 'utf8mb4',
        'cursorclass': DictCursor
    }

def get_bot_token():
    """获取报备机器人Token"""
    return REPORT_BOT_TOKEN

def get_super_admin_ids():
    """获取报备机器人超级管理员ID列表"""
    return REPORT_SUPER_ADMIN_IDS

def get_web_admin_config():
    """获取Web管理后台配置"""
    return {
        'host': WEB_HOST,
        'port': WEB_PORT,
        'secret_key': SECRET_KEY,
        'username': WEB_USERNAME,
        'password': WEB_PASSWORD
    }

def get_report_mention_config():
    """获取报备提及用户配置"""
    return {
        'username': REPORT_MENTION_USERNAME,
        'text': REPORT_MENTION_TEXT
    }

# ========== 防骗机器人兼容配置 ==========
BOT_TOKEN = ANTIFRAUD_BOT_TOKEN
ADMIN_IDS = ANTIFRAUD_ADMIN_IDS
MYSQL_HOST = DB_HOST
MYSQL_PORT = DB_PORT
MYSQL_USER = DB_USER
MYSQL_PASSWORD = DB_PASSWORD
MYSQL_DATABASE = DB_NAME

# 防骗机器人的其他配置（从原config.py）
MAX_CHARACTERS = 50
MAX_LINES = 3

KEYWORD_MATCHING = {
    "TAB2kKwPYiXq1qNxaQHhrxvFNPZ51hSzmR": {
        "reply_text": "此地址为新币更换的最新地址，请放心交易，望各位用户知悉，惠存。",
        "buttons": [
            {"text": "我要举报", "url": "https://t.me/xdfkbot"},
            {"text": "联系客服", "url": "https://t.me/xdfkbot"}
        ]
    }
}

DEFAULT_WELCOME_MESSAGE = """欢迎 {user_name} 来到 {group_name}
交易前请先关注担保流程 【<a href="https://t.me/gonggao">@gonggao</a>】
1.交易前认准群老板和业务员头衔，先看清楚置顶的群规则和报备模板；
2.交易前群老板方必须在公群内进行报备，客户确认报备内容，如客户没确认此报备视为无效报备；
3.交易过程中有任何变动需要在群内保留记录或者重新报备；
4.有任何问题可以联系新币24小时客服 <a href="https://t.me/xdfkbot">@xbkf</a>
⚠️注意: 主动私聊你的都是骗子！一切交易必须群内进行,切勿私下交易,请按照担保流程进行交易。"""

VIP_WELCOME_MESSAGE = DEFAULT_WELCOME_MESSAGE
STAFF_WELCOME_MESSAGE = DEFAULT_WELCOME_MESSAGE

WELCOME_BUTTONS = [
    {"text": "新币供需", "url": "https://t.me/abcd"},
    {"text": "新币客服", "url": "https://t.me/xdfkbot"}
]

CLASS_START_MESSAGE = """本群已开启发言，群内可以正常作业
认准群老板头衔 切勿私下交易。"""

CLASS_END_MESSAGE = """本公群已下课关闭发言
如需交易，请在该群恢复营业后在群内交易！ 切勿私下交易！！"""

CLASS_BUTTONS = [
    {"text": "新币供需", "url": "https://t.me/abcd"},
    {"text": "新币客服", "url": "https://t.me/xdfkbot"}
]

START_MESSAGE = """<a href="https://t.me/xdfkbot">点击此处可以添加机器人进群</a>

更多服务，请访问 <a href="https://t.me/xdfkbot/">https://t.me/xbkf/</a>"""

START_BUTTONS = [
    {"text": "新币红包(24小时发红包)", "url": "https://t.me/+9S5qHAIh24JmMjBk"},
    {"text": "新币客服", "url": "https://t.me/xdfkbot"}
]

# 全局配置对象（报备机器人需要）
config = {
    'bot_token': REPORT_BOT_TOKEN,
    'super_admin_ids': REPORT_SUPER_ADMIN_IDS,
    'database': get_db_config(),
    'web_admin': get_web_admin_config(),
    'report_mention': get_report_mention_config()
}
