#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
报备机器人启动模块
"""
import sys
import os
import asyncio

# 添加cccc目录到Python路径
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
cccc_path = os.path.join(parent_dir, 'cccc')
sys.path.insert(0, cccc_path)

def main():
    """启动报备机器人"""
    # 导入bot模块
    from bot import main as bot_main
    
    # 创建新的事件循环
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    
    # 运行机器人
    bot_main()

if __name__ == '__main__':
    main()
