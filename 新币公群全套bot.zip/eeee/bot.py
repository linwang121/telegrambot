#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
新币机器人 - 只在私聊中工作
"""

import logging
import asyncio
import json
import os
import pymysql
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters, ContextTypes
import config
import sys

# 设置日志
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO,
    force=True
)
logger = logging.getLogger(__name__)

# 视频file_id存储文件
VIDEO_CACHE_FILE = "video_cache.json"

def load_video_cache():
    """加载视频缓存"""
    if os.path.exists(VIDEO_CACHE_FILE):
        try:
            with open(VIDEO_CACHE_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"加载视频缓存失败: {e}")
    return {}

def save_video_cache(cache):
    """保存视频缓存"""
    try:
        with open(VIDEO_CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(cache, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"保存视频缓存失败: {e}")

# 加载视频缓存
video_cache = load_video_cache()

# 等待保存视频的管理员ID集合
waiting_video_admins = set()

# 消息映射：群组消息ID -> 用户信息
message_mapping = {}

# 用户按钮上下文：user_id -> 按钮名称
user_button_context = {}

def get_db_connection():
    """获取数据库连接"""
    return pymysql.connect(
        host=config.DB_HOST,
        port=config.DB_PORT,
        user=config.DB_USER,
        password=config.DB_PASSWORD,
        database=config.DB_NAME,
        charset='utf8mb4',
        cursorclass=pymysql.cursors.DictCursor
    )

def get_bot_config(config_key, default_value=''):
    """从数据库获取配置"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT `config_value` FROM `xinbi_bot_config` WHERE `config_key` = %s", (config_key,))
        result = cursor.fetchone()
        conn.close()
        
        if result and result['config_value']:
            return result['config_value']
        return default_value
    except Exception as e:
        logger.error(f"获取配置失败: {e}")
        return default_value

def update_bot_config(config_key, config_value):
    """更新配置到数据库"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE `xinbi_bot_config` 
            SET `config_value` = %s 
            WHERE `config_key` = %s
        """, (config_value, config_key))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        logger.error(f"更新配置失败: {e}")
        return False

def get_button_config(button_text):
    """获取按钮配置"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT * FROM `xinbi_bot_buttons` 
            WHERE `button_text` = %s AND `is_enabled` = 1
        """, (button_text,))
        result = cursor.fetchone()
        conn.close()
        
        # 解析config_data
        if result and result.get('config_data'):
            if isinstance(result['config_data'], str):
                try:
                    result['config_data'] = json.loads(result['config_data'])
                except:
                    pass
        
        return result
    except Exception as e:
        logger.error(f"获取按钮配置失败: {e}")
        return None

async def process_button_config(update: Update, config_data):
    """处理按钮配置（从数据库读取）"""
    if not config_data or not config_data.get('messages'):
        return False
    
    try:
        # 是否发送视频
        if config_data.get('send_video'):
            video_file_id = get_bot_config('video_file_id', '')
            if not video_file_id:
                video_file_id = video_cache.get("verification_video", '')
            
            if video_file_id:
                try:
                    await update.message.reply_video(video=video_file_id)
                    logger.info("视频发送成功")
                except Exception as e:
                    logger.error(f"发送视频失败: {e}")
        
        # 处理所有消息
        messages = config_data.get('messages', [])
        for msg_config in messages:
            text = msg_config.get('text', '')
            inline_buttons = msg_config.get('inline_buttons', [])
            reply_keyboard = msg_config.get('reply_keyboard', '')
            
            # 创建内联按钮
            reply_markup = None
            if inline_buttons:
                buttons = []
                for row in inline_buttons:
                    button_row = []
                    for btn in row:
                        if btn.get('url'):
                            button_row.append(InlineKeyboardButton(btn['text'], url=btn['url']))
                        elif btn.get('callback'):
                            button_row.append(InlineKeyboardButton(btn['text'], callback_data=btn['callback']))
                    if button_row:
                        buttons.append(button_row)
                if buttons:
                    reply_markup = InlineKeyboardMarkup(buttons)
            elif reply_keyboard == 'exit':
                reply_markup = ReplyKeyboardMarkup(
                    [[KeyboardButton("退出")]],
                    resize_keyboard=True,
                    one_time_keyboard=False
                )
            
            if text:
                await update.message.reply_text(text, reply_markup=reply_markup, parse_mode='HTML')
        
        return True
        
    except Exception as e:
        logger.error(f"处理按钮配置失败: {e}", exc_info=True)
        return False

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理/start命令 - 显示主菜单"""
    user_id = update.effective_user.id
    
    # 只在私聊中工作
    if update.effective_chat.type != 'private':
        return
    
    # 创建底部键盘（根据图片布局）
    keyboard = [
        [KeyboardButton("新手必读")],
        [KeyboardButton("购买广告/内部群门票"), KeyboardButton("人工/解封")],
        [KeyboardButton("进VIP精英群/资源交易群"), KeyboardButton("投诉建议")],
        [KeyboardButton("担保靓号"), KeyboardButton("违规举报")],
        [KeyboardButton("查验用户信息（骗子查询）"), KeyboardButton("查群/验群")],
        [KeyboardButton("解除封禁"), KeyboardButton("资源对接")]
    ]
    
    reply_markup = ReplyKeyboardMarkup(
        keyboard,
        resize_keyboard=True,
        one_time_keyboard=False
    )
    
    # 从数据库获取欢迎消息
    welcome_text = get_bot_config('welcome_message', """买会员/买广告/发供需
联系 @xbkf 发送指令 /start
点击👉购买广告/VIP精英群门票

您好，这里是新币担保在线人工客服！
真假群最简单的核实方式，只要担保靓号在群里的都是真群。
请问有什么可以帮助您？""")
    
    await update.message.reply_text(
        welcome_text,
        reply_markup=reply_markup,
        parse_mode='HTML'
    )
    
    logger.info(f"用户 {user_id} 启动了机器人")

async def handle_menu_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理底部菜单按钮"""
    # 只在私聊中工作
    if update.effective_chat.type != 'private':
        return
    
    text = update.message.text
    user_id = update.effective_user.id
    
    # 主菜单按钮列表（只有这些按钮才保存用户上下文）
    main_menu_buttons = [
        "新手必读",
        "购买广告/内部群门票",
        "人工/解封",
        "进VIP精英群/资源交易群",
        "投诉建议",
        "担保靓号",
        "违规举报",
        "查验用户信息（骗子查询）",
        "查群/验群",
        "解除封禁",
        "资源对接"
    ]
    
    # 只有主菜单按钮才保存用户上下文
    if text in main_menu_buttons:
        user_button_context[user_id] = text
    
    logger.info(f"用户 {user_id} 点击了菜单: {text}")
    
    # 优先从数据库获取按钮配置
    button_cfg = get_button_config(text)
    if button_cfg and button_cfg.get('config_data'):
        logger.info(f"使用数据库配置处理按钮: {text}")
        if await process_button_config(update, button_cfg['config_data']):
            return
    
    # 根据不同按钮显示不同内容
    if text == "新手必读":
        # 第一条消息：收费标准
        charging_text = """收费标准:
1、新币供需200/条;vip群门票500U/一张
2、专群上押500u起,担保费最低15u起
3、公群上押3000U起,最低100U起,(按业务类型收取)"""
        
        charging_keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("专群流程频道", url="https://t.me/your_exclusive_channel"),
                InlineKeyboardButton("公群流程频道", url="https://t.me/your_public_channel")
            ]
        ])
        
        await update.message.reply_text(
            charging_text,
            reply_markup=charging_keyboard
        )
        
        # 第二条消息：新手必读
        guide_text = """新手必读:
1、请务必核对以下三项信息:靓号用户名+888号码+唯一地址(注意:个人简介≠用户名,担保号三者俱全)
2、新币最简单的核实方式,只要4A担保靓号在群里的都是真群。
3、设置TG二步验证,加靓号好友改特殊备注,群邀请权限关闭。
4、不要随意点击文件或链接,使用正版TG,无毒中文包。防止账号被盗"""
        
        guide_keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("高手秘笈", url="https://t.me/your_master_guide"),
                InlineKeyboardButton("新币展示频道知识合集", url="https://t.me/your_knowledge_channel")
            ]
        ])
        
        await update.message.reply_text(
            guide_text,
            reply_markup=guide_keyboard
        )
        return
    elif text == "购买广告/内部群门票":
        # 第一条消息：群组和价格信息
        group_info = """✅优质社群开放招募｜精英联盟·资源互通·业务共赢

✅常规业务管理群：88U
✅一二通管理群：188U
✅卡商管理交流群：188U
✅新币资源交易群：188U
✅海外管理交流群：288U
✅VIP精英内部群：500U
《料属性讨论群》：新币有交易担保实际买后免费进群

加入方式：
1️⃣ 开设公群联系担保即可免费进入对应业务群。
2️⃣ 新币上推或者新币担保交易三次以上免费进新币资源交易群。
3️⃣ 开设VIP任选一个业务群免费进入（新币资源交易群除外）。
4️⃣ 俱乐部级资金｜优质生意对接｜跨领域资源｜深度合作机会

现全面对外开放，可购票加入，共享资源，选择适合的群组，与行动者同行，共创价值！"""
        
        await update.message.reply_text(group_info)
        
        # 第二条消息：收货标准和发布规则
        rules_info = """老板，先看下收货标准和发布规则：

1️⃣ 不得发布虚假诈骗广告，违者立即下架且不退款。
2️⃣ 【供需普通广告】@abcd
单价：200U/条，买10曝2，500u/30条，14000u/100条。
3️⃣ 【带公群链接广告】@abcd
单价：150U/条，买10曝1，4500u/35条，15000u/120条
直顶广告：周直顶1000U，月直顶3000U
4️⃣ 供方频道 @gongfang｜需方频道 @xufang
月费：200U 年费：200U（加'年'标识）
5️⃣ 【vip内部门票】门票50U
⚠️ 注：广告售出后不退不换，发布后无法撤销或重发"""
        
        await update.message.reply_text(rules_info)
        
        # 第三条消息：询问购买类型
        question = "老板，请问要购买什么样的广告呢？"
        
        # 创建退出按钮
        exit_keyboard = ReplyKeyboardMarkup(
            [[KeyboardButton("退出")]],
            resize_keyboard=True,
            one_time_keyboard=False
        )
        
        await update.message.reply_text(
            question,
            reply_markup=exit_keyboard
        )
        return
    elif text == "人工/解封":
        response = "你好，这里是新币担保人工客服，请问有什么可以帮助您？"
        await update.message.reply_text(response)
        return
    elif text == "进VIP精英群/资源交易群":
        # 完整消息，包含群组信息和购买方式
        message = """✅优质社群开放招募｜精英联盟·资源互通·业务共赢

✅常规业务管理群：88U
✅一二通管理群：188U
✅卡商管理交流群：188U
✅新币资源交易群：188U
✅海外管理交流群：288U
✅VIP精英内部群：500U
《料属性讨论群》：新币有交易担保实际买后免费进群

加入方式：
1️⃣ 开设公群联系担保即可免费进入对应业务群。
2️⃣ 新币上推或者新币担保交易三次以上免费进新币资源交易群。
3️⃣ 开设VIP任选一个业务群免费进入（新币资源交易群除外）。
4️⃣ 俱乐部级资金｜高质量业务对接｜跨领域资源｜深度合作机会。

现全面对外开放，可购票加入，共享资源，选择适合的群组，与行动者同行，共创价值！

购买方式：点击👉购买广告/内部群门票"""
        
        # 创建内联按钮（显示在消息底部）
        inline_keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("进VIP精英群", callback_data="enter_vip_group"),
                InlineKeyboardButton("进资源交易群", callback_data="enter_resource_group")
            ],
            [
                InlineKeyboardButton("SafeW登记VIP精英群信息", callback_data="register_vip_info")
            ]
        ])
        
        await update.message.reply_text(
            message,
            reply_markup=inline_keyboard
        )
        return
    elif text == "投诉建议":
        response = "您好，投诉/建议请联系担保负责人 @xbppp"
    elif text == "担保靓号":
        response = "点击查看担保靓号"
    elif text == "违规举报":
        response = "引导私下作业，偷税漏税，杀车点赞等有奖举报联系 @boss1"
    elif text == "查验用户信息（骗子查询）":
        message = """骗子曝光，拉假群，克隆群，杀车等等。举报核实联系各担保组。

骗子曝光联系 @bixin

输入ID+用户id数字 可以查询用户信息 包含VIP 客户认证 骗子信息"""
        
        # 创建内联按钮（跳转链接）
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("骗子曝光", url="https://t.me/your_scammer_report_channel")]
        ])
        
        await update.message.reply_text(
            message,
            reply_markup=keyboard
        )
        return
    elif text == "查群/验群":
        # 第一条消息：发送视频（使用file_id秒发）
        # 优先从数据库获取video_file_id，如果没有则从缓存文件获取
        video_file_id = get_bot_config('video_file_id', '')
        if not video_file_id:
            video_file_id = video_cache.get("verification_video", '')
        
        if video_file_id:
            try:
                logger.info(f"使用file_id发送视频")
                # 使用file_id发送视频（秒发）
                await update.message.reply_video(video=video_file_id)
                logger.info("视频发送成功")
            except Exception as e:
                logger.error(f"发送视频失败: {e}")
                # 如果file_id失效，清除缓存
                if "verification_video" in video_cache:
                    del video_cache["verification_video"]
                    save_video_cache(video_cache)
                update_bot_config('video_file_id', '')
        else:
            logger.warning("视频file_id不存在，请使用 /sp 命令保存视频")
        
        # 第二条消息：核实方式说明，带4个内联按钮
        verification_text = """①最简单的核实方式，只要以下担保靓号在群里的都是真群：
@aaaa @bbbb @cccc @dddd @eeee @vvvv @uuuu @yyyy @pppp
@qqqq @tttt @ssss @kkkk @nnnn @gggg @hhhh @ffff @iiii @oooo
@mmmm

②验证私聊机器人 @xbkf 发送"验群"输入 组别和群编号例如：Q60000
即可查询您是否在该群组"""
        
        # 创建4个内联按钮（跳转链接）
        inline_keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("公群导航", url="https://t.me/your_public_navigation"),
                InlineKeyboardButton("供需频道", url="https://t.me/your_supply_demand")
            ],
            [
                InlineKeyboardButton("新币招商", url="https://t.me/your_investment"),
                InlineKeyboardButton("中文搜索", url="https://t.me/your_chinese_search")
            ]
        ])
        
        await update.message.reply_text(
            verification_text,
            reply_markup=inline_keyboard
        )
        
        # 第三条消息：输入提示，带退出按钮
        input_prompt = """请输入要验证的群编号 格式为一担保组编号+群编号  例如 a1234 a组1234  b1234  g1234

发送 /start 或者退出，可以退出查询状态"""
        
        # 创建退出按钮
        exit_keyboard = ReplyKeyboardMarkup(
            [[KeyboardButton("退出")]],
            resize_keyboard=True,
            one_time_keyboard=False
        )
        
        await update.message.reply_text(
            input_prompt,
            reply_markup=exit_keyboard
        )
        return
    elif text == "解除封禁":
        response = "已解除封禁，请注意遵守群规"
    elif text == "资源对接":
        response = "资源对接请联系 @xinbiziyuanBot"
    elif text == "退出":
        # 返回主菜单
        await start(update, context)
        return
    else:
        response = "请使用底部菜单选择功能"
    
    await update.message.reply_text(response)

async def handle_text_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理文本消息"""
    # 处理管理员群组中的回复
    if update.effective_chat.type in ['group', 'supergroup']:
        await handle_admin_reply(update, context)
        return
    
    # 只在私聊中工作
    if update.effective_chat.type != 'private':
        return
    
    # 检查是否是菜单按钮
    menu_buttons = [
        "新手必读",
        "购买广告/内部群门票",
        "人工/解封",
        "进VIP精英群/资源交易群",
        "投诉建议",
        "担保靓号",
        "违规举报",
        "查验用户信息（骗子查询）",
        "查群/验群",
        "解除封禁",
        "资源对接",
        "退出"
    ]
    
    if update.message.text in menu_buttons:
        await handle_menu_button(update, context)
    else:
        # 其他文本消息 - 转发到管理员群组
        await forward_to_admin(update, context)

async def handle_callback_query(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理内联按钮回调"""
    query = update.callback_query
    await query.answer()
    
    if query.data == "enter_vip_group":
        response = """您还不是尊贵的新币VIP精英

发送指令 /start
点击👉购买广告/内部群门票"""
        await query.message.reply_text(response)
        
    elif query.data == "enter_resource_group":
        response = """您不是尊贵的新币资源交易群成员

1️⃣ 新币担保上推或交易三次以上
2️⃣ 联系当担保就告知取得权限获取进资源交易群权限

购买资格点击 /start 👉购买广告/内部群门票"""
        await query.message.reply_text(response)
        
    elif query.data == "register_vip_info":
        response = """您还不是尊贵的新币VIP精英

发送指令 /start
点击👉购买广告/内部群门票"""
        await query.message.reply_text(response)

async def save_video(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """管理员命令：等待接收视频"""
    user_id = update.effective_user.id
    
    # 检查是否是管理员
    admin_ids = config.REPORT_SUPER_ADMIN_IDS if config.REPORT_SUPER_ADMIN_IDS else config.get_super_admin_ids()
    if user_id not in admin_ids:
        # 非管理员：不做任何响应
        return
    
    # 将管理员ID加入等待列表
    waiting_video_admins.add(user_id)
    
    await update.message.reply_text(
        "✅ 请直接发送视频给我\n\n"
        "📹 视频要求：\n"
        "• 文件大小 < 50MB\n"
        "• 支持格式：MP4, MOV等\n"
        "• 建议分辨率：720p-1080p"
    )
    
    logger.info(f"管理员 {user_id} 准备保存视频")

async def handle_video_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理视频消息"""
    user_id = update.effective_user.id
    
    # 检查用户是否在等待发送视频的列表中
    if user_id not in waiting_video_admins:
        return
    
    # 检查是否是视频消息
    if not update.message.video:
        return
    
    try:
        # 获取视频的file_id
        video = update.message.video
        file_id = video.file_id
        
        # 保存到缓存文件
        video_cache["verification_video"] = file_id
        save_video_cache(video_cache)
        
        # 保存到数据库
        update_bot_config('video_file_id', file_id)
        
        # 从等待列表中移除
        waiting_video_admins.discard(user_id)
        
        logger.info(f"管理员 {user_id} 保存了视频file_id: {file_id}")
        
        await update.message.reply_text(
            f"✅ 视频已保存！\n\n"
            f"📹 File ID: `{file_id}`\n"
            f"📊 文件大小: {video.file_size / 1024 / 1024:.2f} MB\n"
            f"⏱ 时长: {video.duration}秒\n"
            f"📐 分辨率: {video.width}x{video.height}\n\n"
            f"用户点击「查群/验群」时将使用此视频",
            parse_mode='Markdown'
        )
        
    except Exception as e:
        logger.error(f"保存视频失败: {e}", exc_info=True)
        await update.message.reply_text(f"❌ 保存失败: {str(e)}")
        waiting_video_admins.discard(user_id)

async def forward_to_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """将用户消息转发到管理员群组"""
    # 从数据库获取管理员群组ID
    admin_group_id = get_bot_config('admin_group_id', '')
    
    if not admin_group_id or admin_group_id.strip() == '':
        logger.warning("未配置管理员群组ID，无法转发消息")
        # 不显示任何消息，静默处理
        return
    
    try:
        admin_group_id = int(admin_group_id)
    except ValueError:
        logger.error(f"管理员群组ID格式错误: {admin_group_id}")
        return
    
    try:
        user = update.effective_user
        user_id = user.id
        username = user.username
        first_name = user.first_name or ""
        message_text = update.message.text
        message_id = update.message.message_id
        message_time = update.message.date.strftime("%Y-%m-%d %H:%M:%S")
        
        # 获取用户点击的按钮文本
        button_text = user_button_context.get(user_id, "用户并未点击按钮")
        
        # 创建用户超链接
        if username:
            user_link = f'<a href="https://t.me/{username}">{first_name}</a>'
        else:
            user_link = first_name
        
        # 格式化消息（使用 bot.js 的格式）
        forward_text = (
            f"<pre>#{user_id}#{message_id}</pre>\n"
            f"姓名：{user_link}\n"
            f"时间：{message_time}\n"
            f"按钮文本：{button_text}\n"
            f"消息内容：{message_text}"
        )
        
        # 创建内联键盘
        if username:
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("私聊发送者", url=f"https://t.me/{username}")]
            ])
        else:
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("私聊发送者", url=f"tg://user?id={user_id}")]
            ])
        
        # 发送到管理员群组
        sent_message = await context.bot.send_message(
            chat_id=admin_group_id,
            text=forward_text,
            parse_mode='HTML',
            reply_markup=keyboard,
            disable_web_page_preview=True
        )
        
        # 保存消息映射
        message_mapping[sent_message.message_id] = {
            'user_id': user_id,
            'username': username,
            'first_name': first_name
        }
        
        logger.info(f"转发用户 {user_id} 的消息到管理员群组，按钮：{button_text}")
        
        # 不回复用户，静默转发
        
    except Exception as e:
        logger.error(f"转发消息到管理员群组失败: {e}", exc_info=True)
        # 发生错误时也不显示消息给用户

async def handle_admin_reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理管理员在群组中的回复"""
    # 检查是否是回复消息
    if not update.message.reply_to_message:
        return
    
    # 检查是否是回复机器人的消息
    if not update.message.reply_to_message.from_user.is_bot:
        return
    
    # 获取被回复的消息ID
    replied_message_id = update.message.reply_to_message.message_id
    
    # 检查消息映射
    if replied_message_id not in message_mapping:
        return
    
    try:
        # 获取原用户信息
        user_info = message_mapping[replied_message_id]
        user_id = user_info['user_id']
        reply_text = update.message.text
        
        # 发送回复给用户
        await context.bot.send_message(
            chat_id=user_id,
            text=reply_text
        )
        
        # 在群组中显示确认消息（不显示按钮）
        await update.message.reply_text("✅ 已发送")
        
        logger.info(f"管理员回复已发送给用户 {user_id}")
        
    except Exception as e:
        logger.error(f"发送管理员回复失败: {e}", exc_info=True)
        await update.message.reply_text("❌ 发送失败")

def main():
    """启动机器人"""
    # 使用新币机器人的Token（需要在config中配置）
    if not hasattr(config, 'XINBI_BOT_TOKEN') or not config.XINBI_BOT_TOKEN:
        logger.error("未设置XINBI_BOT_TOKEN。请在.env文件中设置XINBI_BOT_TOKEN。")
        sys.exit(1)
    
    # 如果在子线程中运行，需要创建新的事件循环
    try:
        loop = asyncio.get_event_loop()
        if loop.is_closed():
            raise RuntimeError("Event loop is closed")
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    
    # 创建Application
    application = Application.builder().token(config.XINBI_BOT_TOKEN).build()
    
    # 注册命令处理器
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("sp", save_video))  # 管理员保存视频命令
    
    # 注册回调查询处理器（处理内联按钮点击）
    application.add_handler(CallbackQueryHandler(handle_callback_query))
    
    # 注册视频消息处理器（用于管理员保存视频）
    application.add_handler(MessageHandler(
        filters.VIDEO & filters.ChatType.PRIVATE,
        handle_video_message
    ))
    
    # 注册文本消息处理器（处理私聊和群组，但排除命令）
    application.add_handler(MessageHandler(
        filters.TEXT & ~filters.COMMAND & (filters.ChatType.PRIVATE | filters.ChatType.GROUPS), 
        handle_text_message
    ))
    
    logger.info("新币机器人已启动（仅私聊模式）")
    logger.info("管理员可使用 /sp 命令保存视频file_id")
    
    # 使用轮询模式（禁用信号处理以支持在线程中运行）
    application.run_polling(stop_signals=None)

if __name__ == '__main__':
    main()
