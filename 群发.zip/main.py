import os
import sys
import asyncio
import logging
import sqlite3
import zipfile
import shutil
import json
import random
import time
from datetime import datetime
from typing import Optional, List, Dict, Any, Tuple

from telethon import TelegramClient, events, Button
from telethon.sessions import StringSession
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.functions.messages import ImportChatInviteRequest
from telethon.tl.functions.photos import UploadProfilePhotoRequest, DeletePhotosRequest
from telethon.tl.functions.account import UpdateProfileRequest
from telethon.errors import (
    SessionPasswordNeededError, FloodWaitError,
    UserAlreadyParticipantError, InviteHashExpiredError, InviteHashInvalidError,
    ChannelPrivateError
)
from telethon.tl.types import InputChatUploadedPhoto

# ==================== 配置 ====================
BOT_TOKEN = "8655874548:AAGMbkElDXCEW8SaMoMfDojpRocW68JC2X4"
API_ID = 33832620
API_HASH = "de64691ab4d40e276cf43629b32da20f"
ADMIN_IDS = [8348578747]

DATABASE_PATH = "bot_data.db"
UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(os.path.join(UPLOAD_DIR, "sessions"), exist_ok=True)
os.makedirs(os.path.join(UPLOAD_DIR, "tdata"), exist_ok=True)
os.makedirs(os.path.join(UPLOAD_DIR, "photos"), exist_ok=True)
os.makedirs(os.path.join(UPLOAD_DIR, "temp"), exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.FileHandler('bot.log', encoding='utf-8'), logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

# ==================== 用户状态管理 ====================
class UserState:
    def __init__(self):
        self.states = {}
    def set(self, uid, state, data=None):
        self.states[uid] = {'state': state, 'data': data or {}}
    def get(self, uid):
        return self.states.get(uid, {'state': 'main', 'data': {}})
    def clear(self, uid):
        self.states.pop(uid, None)

user_state = UserState()

# ==================== 数据库 ====================
class Database:
    def __init__(self, db_path=DATABASE_PATH):
        self.db_path = db_path
        self.init_db()

    def get_conn(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    def init_db(self):
        conn = self.get_conn()
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS accounts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            phone TEXT DEFAULT '',
            session_file TEXT DEFAULT '',
            tdata_path TEXT DEFAULT '',
            password TEXT DEFAULT '',
            proxy_type TEXT DEFAULT '',
            proxy_host TEXT DEFAULT '',
            proxy_port INTEGER DEFAULT 0,
            proxy_user TEXT DEFAULT '',
            proxy_pass TEXT DEFAULT '',
            first_name TEXT DEFAULT '',
            last_name TEXT DEFAULT '',
            username TEXT DEFAULT '',
            status TEXT DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
        c.execute('''CREATE TABLE IF NOT EXISTS account_groups (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
        c.execute('''CREATE TABLE IF NOT EXISTS account_group_members (
            account_id INTEGER,
            group_id INTEGER,
            FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE,
            FOREIGN KEY (group_id) REFERENCES account_groups(id) ON DELETE CASCADE,
            PRIMARY KEY (account_id, group_id))''')
        c.execute('''CREATE TABLE IF NOT EXISTS group_links (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            link TEXT NOT NULL UNIQUE,
            group_name TEXT DEFAULT '',
            status TEXT DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
        c.execute('''CREATE TABLE IF NOT EXISTS ad_templates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            text TEXT DEFAULT '',
            photo_path TEXT DEFAULT '',
            button_text TEXT DEFAULT '',
            button_url TEXT DEFAULT '',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
        c.execute('''CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_type TEXT NOT NULL,
            account_group_id INTEGER DEFAULT 0,
            group_link_ids TEXT DEFAULT '',
            ad_template_id INTEGER DEFAULT 0,
            start_time TIMESTAMP DEFAULT NULL,
            end_time TIMESTAMP DEFAULT NULL,
            delay_min INTEGER DEFAULT 30,
            delay_max INTEGER DEFAULT 120,
            status TEXT DEFAULT 'pending',
            progress TEXT DEFAULT '{}',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
        c.execute('''CREATE TABLE IF NOT EXISTS task_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id INTEGER,
            account_id INTEGER,
            group_link TEXT,
            status TEXT,
            message TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
        conn.commit()
        conn.close()

    # ========== 账号操作 ==========
    def add_account(self, phone='', session_file='', tdata_path='', password=''):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('INSERT INTO accounts (phone, session_file, tdata_path, password) VALUES (?,?,?,?)',
                  (phone, session_file, tdata_path, password))
        conn.commit(); aid = c.lastrowid; conn.close(); return aid

    def get_all_accounts(self):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('SELECT * FROM accounts ORDER BY id DESC')
        rows = [dict(r) for r in c.fetchall()]; conn.close(); return rows

    def get_account(self, account_id):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('SELECT * FROM accounts WHERE id=?', (account_id,))
        row = c.fetchone(); conn.close(); return dict(row) if row else None

    def update_account_password(self, account_id, password):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('UPDATE accounts SET password=? WHERE id=?', (password, account_id))
        conn.commit(); conn.close()

    def update_account_info(self, account_id, first_name='', last_name='', username=''):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('UPDATE accounts SET first_name=?, last_name=?, username=? WHERE id=?',
                  (first_name, last_name, username, account_id))
        conn.commit(); conn.close()

    def delete_account(self, account_id):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('DELETE FROM accounts WHERE id=?', (account_id,))
        conn.commit(); conn.close()

    def set_account_status(self, account_id, status):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('UPDATE accounts SET status=? WHERE id=?', (status, account_id))
        conn.commit(); conn.close()

    # ========== 分组操作 ==========
    def create_group(self, name):
        conn = self.get_conn(); c = conn.cursor()
        try:
            c.execute('INSERT INTO account_groups (name) VALUES (?)', (name,))
            conn.commit(); gid = c.lastrowid; conn.close(); return gid
        except sqlite3.IntegrityError:
            conn.close(); return -1

    def get_all_groups(self):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('SELECT * FROM account_groups ORDER BY id DESC')
        rows = [dict(r) for r in c.fetchall()]; conn.close(); return rows

    def get_group(self, group_id):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('SELECT * FROM account_groups WHERE id=?', (group_id,))
        row = c.fetchone(); conn.close(); return dict(row) if row else None

    def delete_group(self, group_id):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('DELETE FROM account_groups WHERE id=?', (group_id,))
        conn.commit(); conn.close()

    def add_account_to_group(self, account_id, group_id):
        conn = self.get_conn(); c = conn.cursor()
        try:
            c.execute('INSERT OR IGNORE INTO account_group_members (account_id, group_id) VALUES (?,?)',
                      (account_id, group_id))
            conn.commit(); conn.close(); return True
        except:
            conn.close(); return False

    def remove_account_from_group(self, account_id, group_id):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('DELETE FROM account_group_members WHERE account_id=? AND group_id=?',
                  (account_id, group_id))
        conn.commit(); conn.close()

    def get_group_accounts(self, group_id):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('''SELECT a.* FROM accounts a 
                     JOIN account_group_members agm ON a.id=agm.account_id 
                     WHERE agm.group_id=? AND a.status="active"''', (group_id,))
        rows = [dict(r) for r in c.fetchall()]; conn.close(); return rows

    def get_account_groups(self, account_id):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('''SELECT ag.* FROM account_groups ag 
                     JOIN account_group_members agm ON ag.id=agm.group_id 
                     WHERE agm.account_id=?''', (account_id,))
        rows = [dict(r) for r in c.fetchall()]; conn.close(); return rows

    # ========== 群链接操作 ==========
    def add_group_link(self, link, group_name=''):
        conn = self.get_conn(); c = conn.cursor()
        try:
            c.execute('INSERT OR IGNORE INTO group_links (link, group_name) VALUES (?,?)',
                      (link.strip(), group_name))
            conn.commit(); lid = c.lastrowid; conn.close()
            return lid if lid > 0 else -1
        except:
            conn.close(); return -1

    def add_group_links_batch(self, links):
        count = 0
        conn = self.get_conn(); c = conn.cursor()
        for link in links:
            link = link.strip()
            if link:
                try:
                    c.execute('INSERT OR IGNORE INTO group_links (link) VALUES (?)', (link,))
                    if c.rowcount > 0:
                        count += 1
                except:
                    pass
        conn.commit(); conn.close()
        return count

    def get_all_group_links(self):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('SELECT * FROM group_links WHERE status="active" ORDER BY id DESC')
        rows = [dict(r) for r in c.fetchall()]; conn.close(); return rows

    def get_group_link(self, link_id):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('SELECT * FROM group_links WHERE id=?', (link_id,))
        row = c.fetchone(); conn.close(); return dict(row) if row else None

    def delete_group_link(self, link_id):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('UPDATE group_links SET status="deleted" WHERE id=?', (link_id,))
        conn.commit(); conn.close()

    def delete_all_group_links(self):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('DELETE FROM group_links')
        conn.commit(); conn.close()

    def get_group_links_count(self):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('SELECT COUNT(*) as count FROM group_links WHERE status="active"')
        row = c.fetchone(); conn.close()
        return row['count'] if row else 0

    # ========== 广告模板操作 ==========
    def add_ad_template(self, name, text='', photo_path='', button_text='', button_url=''):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('INSERT INTO ad_templates (name, text, photo_path, button_text, button_url) VALUES (?,?,?,?,?)',
                  (name, text, photo_path, button_text, button_url))
        conn.commit(); aid = c.lastrowid; conn.close(); return aid

    def get_all_ad_templates(self):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('SELECT * FROM ad_templates ORDER BY id DESC')
        rows = [dict(r) for r in c.fetchall()]; conn.close(); return rows

    def get_ad_template(self, template_id):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('SELECT * FROM ad_templates WHERE id=?', (template_id,))
        row = c.fetchone(); conn.close(); return dict(row) if row else None

    def delete_ad_template(self, template_id):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('DELETE FROM ad_templates WHERE id=?', (template_id,))
        conn.commit(); conn.close()

    # ========== 任务操作 ==========
    def create_task(self, task_type, account_group_id=0, group_link_ids='', ad_template_id=0,
                    start_time=None, end_time=None, delay_min=30, delay_max=120):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('''INSERT INTO tasks (task_type, account_group_id, group_link_ids, ad_template_id,
                     start_time, end_time, delay_min, delay_max, status, progress)
                     VALUES (?,?,?,?,?,?,?,?,?,?)''',
                  (task_type, account_group_id, group_link_ids, ad_template_id,
                   start_time, end_time, delay_min, delay_max, 'pending', '{}'))
        conn.commit(); tid = c.lastrowid; conn.close(); return tid

    def get_all_tasks(self):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('SELECT * FROM tasks ORDER BY id DESC')
        rows = [dict(r) for r in c.fetchall()]; conn.close(); return rows

    def get_task(self, task_id):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('SELECT * FROM tasks WHERE id=?', (task_id,))
        row = c.fetchone(); conn.close(); return dict(row) if row else None

    def update_task_status(self, task_id, status):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('UPDATE tasks SET status=? WHERE id=?', (status, task_id))
        conn.commit(); conn.close()

    def update_task_progress(self, task_id, progress):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('UPDATE tasks SET progress=? WHERE id=?', (json.dumps(progress), task_id))
        conn.commit(); conn.close()

    def delete_task(self, task_id):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('DELETE FROM tasks WHERE id=?', (task_id,))
        conn.commit(); conn.close()

    def add_task_log(self, task_id, account_id, group_link, status, message):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('INSERT INTO task_logs (task_id, account_id, group_link, status, message) VALUES (?,?,?,?,?)',
                  (task_id, account_id, group_link, status, message))
        conn.commit(); conn.close()

    def get_task_logs(self, task_id):
        conn = self.get_conn(); c = conn.cursor()
        c.execute('SELECT * FROM task_logs WHERE task_id=? ORDER BY id DESC LIMIT 50', (task_id,))
        rows = [dict(r) for r in c.fetchall()]; conn.close(); return rows

# ==================== 账号管理器 ====================
class AccountManager:
    def __init__(self, db: Database):
        self.db = db

    async def create_client(self, account):
        proxy = None
        if account.get('proxy_host'):
            proxy = (account['proxy_type'], account['proxy_host'], account['proxy_port'],
                     account.get('proxy_user', ''), account.get('proxy_pass', ''))
        session = account.get('session_file', '')
        if session and os.path.exists(session):
            return TelegramClient(session, API_ID, API_HASH, proxy=proxy)
        return TelegramClient(StringSession(), API_ID, API_HASH, proxy=proxy)

    async def test_account(self, account_id):
        account = self.db.get_account(account_id)
        if not account:
            return False, "账号不存在"
        try:
            client = await self.create_client(account)
            await client.connect()
            if not await client.is_user_authorized():
                await client.disconnect()
                return False, "未登录"
            me = await client.get_me()
            await client.disconnect()
            self.db.update_account_info(account_id, me.first_name or '', me.last_name or '', me.username or '')
            return True, f"✅ 可用: {me.first_name} (@{me.username})"
        except Exception as e:
            return False, f"❌ 错误: {e}"

    async def change_photo(self, account_id, photo_path):
        account = self.db.get_account(account_id)
        if not account: return False, "账号不存在"
        client = None
        try:
            client = await self.create_client(account)
            await client.connect()
            if not await client.is_user_authorized():
                return False, "未登录"
            if not os.path.exists(photo_path):
                return False, "头像文件不存在"
            try:
                photos = await client.get_profile_photos('me', limit=1)
                if photos:
                    await client(DeletePhotosRequest([photos[0]]))
            except: pass
            uploaded = await client.upload_file(photo_path)
            await client(UploadProfilePhotoRequest(
                file=InputChatUploadedPhoto(file=uploaded)))
            await client.disconnect()
            return True, "头像更换成功"
        except FloodWaitError as e:
            return False, f"限制等待 {e.seconds}s"
        except Exception as e:
            return False, f"失败: {e}"
        finally:
            if client: await client.disconnect()

    async def change_info(self, account_id, first_name=None, last_name=None, bio=None):
        account = self.db.get_account(account_id)
        if not account: return False, "账号不存在"
        client = None
        try:
            client = await self.create_client(account)
            await client.connect()
            if not await client.is_user_authorized():
                return False, "未登录"
            await client(UpdateProfileRequest(
                first_name=first_name, last_name=last_name, about=bio))
            await client.disconnect()
            return True, "资料更新成功"
        except FloodWaitError as e:
            return False, f"限制等待 {e.seconds}s"
        except Exception as e:
            return False, f"失败: {e}"
        finally:
            if client: await client.disconnect()

    async def join_group(self, account_id, link):
        account = self.db.get_account(account_id)
        if not account: return False, "账号不存在"
        client = None
        try:
            client = await self.create_client(account)
            await client.connect()
            if not await client.is_user_authorized():
                return False, "未登录"
            if 't.me/' in link:
                if 'joinchat/' in link or 't.me/+' in link:
                    hash_part = link.split('/')[-1].replace('+', '')
                    try:
                        await client(ImportChatInviteRequest(hash_part))
                        return True, "加入成功"
                    except UserAlreadyParticipantError:
                        return True, "已在群中"
                    except (InviteHashExpiredError, InviteHashInvalidError) as e:
                        return False, str(e)
                else:
                    username = link.split('/')[-1]
                    try:
                        entity = await client.get_entity(username)
                        await client(JoinChannelRequest(entity))
                        return True, "加入成功"
                    except UserAlreadyParticipantError:
                        return True, "已在群中"
                    except Exception as e:
                        return False, f"失败: {e}"
            return False, "无效链接"
        except FloodWaitError as e:
            return False, f"限制等待 {e.seconds}s"
        except Exception as e:
            return False, f"失败: {e}"
        finally:
            if client: await client.disconnect()

    async def send_ad_to_group(self, account_id, link, text, photo='', btn_text='', btn_url=''):
        account = self.db.get_account(account_id)
        if not account: return False, "账号不存在"
        client = None
        try:
            client = await self.create_client(account)
            await client.connect()
            if not await client.is_user_authorized():
                return False, "未登录"
            if 't.me/' in link:
                username = link.split('/')[-1]
                entity = await client.get_entity(username)
            else:
                entity = await client.get_entity(link)
            buttons = [Button.url(btn_text, btn_url)] if btn_text and btn_url else None
            if photo and os.path.exists(photo):
                await client.send_file(entity, photo, caption=text, buttons=buttons)
            else:
                await client.send_message(entity, text, buttons=buttons)
            await client.disconnect()
            return True, "发送成功"
        except FloodWaitError as e:
            return False, f"限制等待 {e.seconds}s"
        except Exception as e:
            return False, f"失败: {e}"
        finally:
            if client: await client.disconnect()

# ==================== 任务执行器 ====================
class TaskExecutor:
    def __init__(self, db, account_manager):
        self.db = db
        self.am = account_manager
        self.running = {}

    async def execute_join_task(self, task_id):
        task = self.db.get_task(task_id)
        if not task: return
        self.db.update_task_status(task_id, 'running')
        link_ids = [int(x) for x in task['group_link_ids'].split(',') if x.strip()]
        accounts = self.db.get_group_accounts(task['account_group_id'])
        links = [self.db.get_group_link(lid)['link'] for lid in link_ids if self.db.get_group_link(lid)]
        if not accounts or not links:
            self.db.update_task_status(task_id, 'failed')
            self.db.add_task_log(task_id, 0, '', 'error', '缺少账号或链接')
            return
        total = len(accounts) * len(links)
        done = 0
        success = 0
        self.running[task_id] = True
        for acc in accounts:
            if not self.running.get(task_id): break
            for link in links:
                if not self.running.get(task_id): break
                ok, msg = await self.am.join_group(acc['id'], link)
                done += 1
                if ok: success += 1
                self.db.add_task_log(task_id, acc['id'], link, 'success' if ok else 'fail', msg)
                self.db.update_task_progress(task_id, {'total': total, 'completed': done, 'success': success, 'failed': done - success})
                await asyncio.sleep(random.randint(task['delay_min'], task['delay_max']))
        self.db.update_task_status(task_id, 'completed')
        self.running.pop(task_id, None)

    async def execute_send_task(self, task_id):
        task = self.db.get_task(task_id)
        if not task: return
        self.db.update_task_status(task_id, 'running')
        link_ids = [int(x) for x in task['group_link_ids'].split(',') if x.strip()]
        accounts = self.db.get_group_accounts(task['account_group_id'])
        tpl = self.db.get_ad_template(task['ad_template_id'])
        links = [self.db.get_group_link(lid)['link'] for lid in link_ids if self.db.get_group_link(lid)]
        if not accounts or not links or not tpl:
            self.db.update_task_status(task_id, 'failed')
            return
        total = len(accounts) * len(links)
        done = 0
        success = 0
        self.running[task_id] = True
        for acc in accounts:
            if not self.running.get(task_id): break
            for link in links:
                if not self.running.get(task_id): break
                ok, msg = await self.am.send_ad_to_group(acc['id'], link,
                                                         tpl.get('text', ''),
                                                         tpl.get('photo_path', ''),
                                                         tpl.get('button_text', ''),
                                                         tpl.get('button_url', ''))
                done += 1
                if ok: success += 1
                self.db.add_task_log(task_id, acc['id'], link, 'success' if ok else 'fail', msg)
                self.db.update_task_progress(task_id, {'total': total, 'completed': done, 'success': success, 'failed': done - success})
                await asyncio.sleep(random.randint(task['delay_min'], task['delay_max']))
        self.db.update_task_status(task_id, 'completed')
        self.running.pop(task_id, None)

    async def execute_profile_task(self, task_id):
        task = self.db.get_task(task_id)
        if not task: return
        self.db.update_task_status(task_id, 'running')
        accounts = self.db.get_group_accounts(task['account_group_id'])
        tpl = self.db.get_ad_template(task['ad_template_id'])
        if not accounts or not tpl:
            self.db.update_task_status(task_id, 'failed')
            return
        total = len(accounts)
        done = 0
        success = 0
        self.running[task_id] = True
        for acc in accounts:
            if not self.running.get(task_id): break
            ok = True
            msg = ""
            if tpl.get('photo_path'):
                r, m = await self.am.change_photo(acc['id'], tpl['photo_path'])
                if not r:
                    ok = False
                    msg += f"头像:{m}; "
            r, m = await self.am.change_info(acc['id'], first_name=tpl.get('name', ''), bio=tpl.get('text', ''))
            if not r:
                ok = False
                msg += f"资料:{m}; "
            if ok:
                msg = "全部更新成功"
            done += 1
            if ok: success += 1
            self.db.add_task_log(task_id, acc['id'], '', 'success' if ok else 'fail', msg)
            self.db.update_task_progress(task_id, {'total': total, 'completed': done, 'success': success, 'failed': done - success})
            await asyncio.sleep(random.randint(task['delay_min'], task['delay_max']))
        self.db.update_task_status(task_id, 'completed')
        self.running.pop(task_id, None)

    def stop_task(self, task_id):
        self.running[task_id] = False
        self.db.update_task_status(task_id, 'stopped')

# ==================== Bot 主程序 ====================
class GroupSenderBot:
    def __init__(self):
        self.db = Database()
        self.am = AccountManager(self.db)
        self.executor = TaskExecutor(self.db, self.am)
        self.bot = TelegramClient('bot_session', API_ID, API_HASH)

    def is_admin(self, uid):
        return uid in ADMIN_IDS

    async def start(self):
        await self.bot.start(bot_token=BOT_TOKEN)
        logger.info("Bot 已启动")

        @self.bot.on(events.NewMessage(pattern='/start'))
        async def start_handler(event):
            if not self.is_admin(event.sender_id):
                return await event.respond("⛔ 无权限")
            user_state.clear(event.sender_id)
            await self.show_main_menu(event)

        @self.bot.on(events.CallbackQuery())
        async def cb_handler(event):
            if not self.is_admin(event.sender_id):
                return await event.answer("⛔ 无权限", alert=True)
            await self.handle_callback(event, event.data.decode())

        @self.bot.on(events.NewMessage(func=lambda e: e.message.message and not e.message.message.startswith('/')))
        async def msg_handler(event):
            if not self.is_admin(event.sender_id):
                return
            state = user_state.get(event.sender_id)
            await self.handle_state_message(event, state)

        await self.bot.run_until_disconnected()

    async def show_main_menu(self, event):
        buttons = [
            [Button.inline("📁 上传账号", b"up_acc"), Button.inline("👤 手动添加账号", b"add_acc")],
            [Button.inline("📂 分组管理", b"grp"), Button.inline("📋 账号列表", b"list_acc")],
            [Button.inline("🔗 群链接管理", b"links"), Button.inline("📢 广告模板", b"tpl")],
            [Button.inline("🔄 批量换资料", b"chg_profile"), Button.inline("➕ 批量加群", b"join_groups")],
            [Button.inline("📨 批量群发", b"send_ads"), Button.inline("📊 任务管理", b"tasks")],
        ]
        await event.respond("📋 主菜单", buttons=buttons)

    # ==================== 回调分发 ====================
    async def handle_callback(self, event, data):
        uid = event.sender_id
        if data == "back_main":
            user_state.clear(uid)
            await self.show_main_menu(event)
        elif data == "up_acc":       await self.cmd_upload_accounts(event)
        elif data == "add_acc":      await self.cmd_add_account_phone(event)
        elif data == "grp":          await self.show_groups_menu(event)
        elif data == "list_acc":     await self.show_accounts_list(event)
        elif data == "links":        await self.show_group_links_menu(event)
        elif data == "tpl":          await self.show_ad_templates_menu(event)
        elif data == "chg_profile":  await self.cmd_change_profile_start(event)
        elif data == "join_groups":  await self.cmd_join_groups_start(event)
        elif data == "send_ads":     await self.cmd_send_ads_start(event)
        elif data == "tasks":        await self.show_tasks_menu(event)
        elif data.startswith("grp_"):       await self.handle_groups_callback(event, data)
        elif data.startswith("link_"):      await self.handle_group_links_callback(event, data)
        elif data.startswith("tpl_"):       await self.handle_ad_templates_callback(event, data)
        elif data.startswith("acc_"):       await self.handle_accounts_callback(event, data)
        elif data.startswith("task_"):      await self.handle_tasks_callback(event, data)
        elif data.startswith("chp_"):       await self.handle_change_profile_callback(event, data)
        elif data.startswith("join_"):      await self.handle_join_groups_callback(event, data)
        elif data.startswith("send_"):      await self.handle_send_ads_callback(event, data)

    # ==================== 状态消息处理 ====================
    async def handle_state_message(self, event, state):
        uid = event.sender_id
        text = event.message.text.strip() if event.message.text else ''
        sn = state.get('state', '')
        if sn == 'upload_accounts':         await self.process_upload_accounts(event)
        elif sn == 'add_account_phone':     await self.process_add_account_phone(event, text)
        elif sn == 'add_account_session':   await self.process_add_account_session(event)
        elif sn == 'add_account_password':  await self.process_add_account_password(event, text)
        elif sn == 'create_group':          await self.process_create_group(event, text)
        elif sn == 'add_group_links':       await self.process_add_group_links(event, text)
        elif sn == 'add_group_links_file':  await self.process_add_group_links_file(event)
        elif sn == 'create_ad_template_name':  await self.process_create_ad_template_name(event, text)
        elif sn == 'create_ad_template_text':  await self.process_create_ad_template_text(event, text)
        elif sn == 'create_ad_template_photo': await self.process_create_ad_template_photo(event)
        elif sn == 'create_ad_template_button': await self.process_create_ad_template_button(event, text)
        elif sn == 'chp_set_name':          await self.process_chp_name(event, text)
        elif sn == 'chp_set_bio':           await self.process_chp_bio(event, text)
        elif sn == 'chp_set_photo':         await self.process_chp_photo(event)
        elif sn == 'join_set_links':        await self.process_join_set_links(event, text)
        elif sn == 'join_set_delay':        await self.process_join_set_delay(event, text)
        elif sn == 'send_set_links':        await self.process_send_set_links(event, text)
        elif sn == 'send_set_delay':        await self.process_send_set_delay(event, text)
        elif sn == 'send_set_time':         await self.process_send_set_time(event, text)
        elif sn.startswith('set_password_'): await self.process_set_password(event, text)

    # ================== 上传账号 ==================
    async def cmd_upload_accounts(self, event):
        user_state.set(event.sender_id, 'upload_accounts')
        await event.edit("📁 请发送 zip 文件", buttons=[[Button.inline("🔙 返回", b"back_main")]])

    async def process_upload_accounts(self, event):
        if not event.message.file:
            return await event.respond("❌ 请发送 zip 文件")
        path = await event.message.download_media(file=os.path.join(UPLOAD_DIR, 'temp'))
        try:
            with zipfile.ZipFile(path, 'r') as zf:
                ext = os.path.join(UPLOAD_DIR, 'temp', f'extract_{int(time.time())}')
                zf.extractall(ext)
                sc, tc = 0, 0
                for root, dirs, files in os.walk(ext):
                    if os.path.basename(root) == 'tdata':
                        dest = os.path.join(UPLOAD_DIR, 'tdata', f'tdata_{int(time.time())}')
                        shutil.move(root, dest)
                        self.db.add_account(tdata_path=dest)
                        tc += 1
                        continue
                    for f in files:
                        if f.endswith('.session'):
                            src = os.path.join(root, f)
                            dst = os.path.join(UPLOAD_DIR, 'sessions', f)
                            shutil.copy2(src, dst)
                            self.db.add_account(session_file=dst)
                            sc += 1
                shutil.rmtree(ext, ignore_errors=True)
                os.remove(path)
                await event.respond(f"✅ 上传完成！Session: {sc}，Tdata: {tc}", buttons=[[Button.inline("🔙 返回", b"back_main")]])
        except Exception as e:
            await event.respond(f"❌ 失败: {e}")
        user_state.clear(event.sender_id)

    # ================== 手动添加账号 ==================
    async def cmd_add_account_phone(self, event):
        user_state.set(event.sender_id, 'add_account_phone')
        await event.edit("👤 请发送手机号（或发送 `跳过`）", buttons=[[Button.inline("🔙 返回", b"back_main")]])

    async def process_add_account_phone(self, event, text):
        uid = event.sender_id
        user_state.set(uid, 'add_account_session', {'phone': '' if text == '跳过' else text})
        await event.respond("📁 请上传 .session 文件", buttons=[[Button.inline("🔙 返回", b"back_main")]])

    async def process_add_account_session(self, event):
        uid = event.sender_id
        if not event.message.file:
            return await event.respond("❌ 请上传文件")
        data = user_state.get(uid)['data']
        fpath = await event.message.download_media(file=os.path.join(UPLOAD_DIR, 'sessions'))
        data['session_file'] = fpath
        user_state.set(uid, 'add_account_password', data)
        await event.respond("🔐 两步验证密码（若无发送 `跳过`）", buttons=[[Button.inline("🔙 返回", b"back_main")]])

    async def process_add_account_password(self, event, text):
        uid = event.sender_id
        data = user_state.get(uid)['data']
        pwd = '' if text == '跳过' else text
        aid = self.db.add_account(phone=data.get('phone', ''), session_file=data.get('session_file', ''), password=pwd)
        user_state.clear(uid)
        await event.respond(f"✅ 账号添加成功！ID: {aid}", buttons=[[Button.inline("🔙 返回", b"back_main")]])

    # ================== 分组管理 ==================
    async def show_groups_menu(self, event):
        groups = self.db.get_all_groups()
        txt = "📂 分组管理\n\n"
        for g in groups:
            cnt = len(self.db.get_group_accounts(g['id']))
            txt += f"• {g['name']} (ID:{g['id']}) - {cnt}个账号\n"
        buttons = [
            [Button.inline("➕ 新建", b"grp_create"), Button.inline("➕ 添加账号", b"grp_add")],
            [Button.inline("➖ 移除账号", b"grp_remove"), Button.inline("🗑 删除分组", b"grp_delete")],
            [Button.inline("👁 查看", b"grp_view"), Button.inline("🔙 返回", b"back_main")],
        ]
        await event.edit(txt, buttons=buttons)

    async def handle_groups_callback(self, event, data):
        uid = event.sender_id
        if data == "grp_create":
            user_state.set(uid, 'create_group')
            await event.edit("输入新分组名称：", buttons=[[Button.inline("🔙 返回", b"grp")]])
        elif data == "grp_add":
            groups = self.db.get_all_groups()
            if not groups: return await event.answer("没有分组", alert=True)
            btns = [[Button.inline(g['name'], f"grp_addto_{g['id']}")] for g in groups]
            btns.append([Button.inline("🔙 返回", b"grp")])
            await event.edit("选择目标分组：", buttons=btns)
        elif data.startswith("grp_addto_"):
            gid = int(data.split("_")[-1])
            accs = self.db.get_all_accounts()
            btns = [[Button.inline(a.get('first_name') or f"ID:{a['id']}", f"grp_addacc_{a['id']}_{gid}")] for a in accs]
            btns.append([Button.inline("🔙 返回", b"grp")])
            await event.edit("选择账号：", buttons=btns)
        elif data.startswith("grp_addacc_"):
            parts = data.replace("grp_addacc_", "").split("_")
            aid, gid = int(parts[0]), int(parts[1])
            self.db.add_account_to_group(aid, gid)
            await event.answer("✅ 添加成功")
            await self.show_groups_menu(event)
        elif data == "grp_remove":
            groups = self.db.get_all_groups()
            btns = [[Button.inline(g['name'], f"grp_rmfrom_{g['id']}")] for g in groups]
            btns.append([Button.inline("🔙 返回", b"grp")])
            await event.edit("选择分组：", buttons=btns)
        elif data.startswith("grp_rmfrom_"):
            gid = int(data.split("_")[-1])
            accs = self.db.get_group_accounts(gid)
            btns = [[Button.inline(a.get('first_name') or f"ID:{a['id']}", f"grp_rmacc_{a['id']}_{gid}")] for a in accs]
            btns.append([Button.inline("🔙 返回", b"grp")])
            await event.edit("选择移除账号：", buttons=btns)
        elif data.startswith("grp_rmacc_"):
            parts = data.replace("grp_rmacc_", "").split("_")
            aid, gid = int(parts[0]), int(parts[1])
            self.db.remove_account_from_group(aid, gid)
            await event.answer("✅ 已移除")
            await self.show_groups_menu(event)
        elif data == "grp_delete":
            groups = self.db.get_all_groups()
            btns = [[Button.inline(g['name'], f"grp_del_{g['id']}")] for g in groups]
            btns.append([Button.inline("🔙 返回", b"grp")])
            await event.edit("选择删除分组：", buttons=btns)
        elif data.startswith("grp_del_"):
            gid = int(data.split("_")[-1])
            self.db.delete_group(gid)
            await event.answer("✅ 已删除")
            await self.show_groups_menu(event)
        elif data == "grp_view":
            groups = self.db.get_all_groups()
            btns = [[Button.inline(g['name'], f"grp_show_{g['id']}")] for g in groups]
            btns.append([Button.inline("🔙 返回", b"grp")])
            await event.edit("选择查看分组：", buttons=btns)
        elif data.startswith("grp_show_"):
            gid = int(data.split("_")[-1])
            g = self.db.get_group(gid)
            accs = self.db.get_group_accounts(gid)
            lines = []
            for i, a in enumerate(accs, 1):
                name = a.get('first_name') or a.get('phone') or f"ID:{a['id']}"
                lines.append(f"{i}. {name}")
            txt = f"📂 {g['name']} 账号列表：\n" + ("\n".join(lines) if lines else "暂无")
            await event.edit(txt, buttons=[[Button.inline("🔙 返回", b"grp")]])

    async def process_create_group(self, event, text):
        uid = event.sender_id
        gid = self.db.create_group(text)
        user_state.clear(uid)
        if gid > 0:
            await event.respond(f"✅ 分组 '{text}' 创建成功", buttons=[[Button.inline("🔙 返回", b"grp")]])
        else:
            await event.respond("❌ 分组已存在", buttons=[[Button.inline("🔙 返回", b"grp")]])

    # ================== 账号列表 ==================
    async def show_accounts_list(self, event):
        accs = self.db.get_all_accounts()
        txt = "📋 账号列表\n\n"
        for a in accs:
            nm = a.get('first_name') or a.get('phone') or f"ID:{a['id']}"
            txt += f"{'✅' if a['status']=='active' else '❌'} #{a['id']} {nm}\n"
        buttons = [
            [Button.inline("🧪 测试", b"acc_test"), Button.inline("🗑 删除", b"acc_delete")],
            [Button.inline("🔐 设置密码", b"acc_pwd"), Button.inline("🔙 返回", b"back_main")],
        ]
        await event.edit(txt, buttons=buttons)

    async def handle_accounts_callback(self, event, data):
        uid = event.sender_id
        if data == "acc_test":
            accs = self.db.get_all_accounts()
            btns = [[Button.inline(a.get('first_name') or f"ID:{a['id']}", f"acc_test_{a['id']}")] for a in accs]
            btns.append([Button.inline("🔙 返回", b"list_acc")])
            await event.edit("选择测试账号：", buttons=btns)
        elif data.startswith("acc_test_"):
            aid = int(data.split("_")[-1])
            await event.answer("测试中...")
            ok, msg = await self.am.test_account(aid)
            await event.respond(msg, buttons=[[Button.inline("🔙 返回", b"list_acc")]])
        elif data == "acc_delete":
            accs = self.db.get_all_accounts()
            btns = [[Button.inline(a.get('first_name') or f"ID:{a['id']}", f"acc_del_{a['id']}")] for a in accs]
            btns.append([Button.inline("🔙 返回", b"list_acc")])
            await event.edit("选择删除账号：", buttons=btns)
        elif data.startswith("acc_del_"):
            aid = int(data.split("_")[-1])
            acc = self.db.get_account(aid)
            if acc and acc.get('session_file'):
                try: os.remove(acc['session_file'])
                except: pass
            self.db.delete_account(aid)
            await event.answer("✅ 已删除")
            await self.show_accounts_list(event)
        elif data == "acc_pwd":
            accs = self.db.get_all_accounts()
            btns = [[Button.inline(a.get('first_name') or f"ID:{a['id']}", f"acc_setpwd_{a['id']}")] for a in accs]
            btns.append([Button.inline("🔙 返回", b"list_acc")])
            await event.edit("选择账号：", buttons=btns)
        elif data.startswith("acc_setpwd_"):
            aid = int(data.split("_")[-1])
            user_state.set(uid, f'set_password_{aid}')
            await event.edit("请输入两步验证密码：", buttons=[[Button.inline("🔙 返回", b"list_acc")]])

    async def process_set_password(self, event, text):
        uid = event.sender_id
        aid = int(user_state.get(uid)['state'].split('_')[-1])
        self.db.update_account_password(aid, text)
        user_state.clear(uid)
        await event.respond("✅ 密码已设置", buttons=[[Button.inline("🔙 返回", b"list_acc")]])

    # ================== 群链接管理 ==================
    async def show_group_links_menu(self, event):
        cnt = self.db.get_group_links_count()
        buttons = [
            [Button.inline("➕ 添加", b"link_add"), Button.inline("📄 文件导入", b"link_file")],
            [Button.inline("📋 查看所有", b"link_view"), Button.inline("🗑 清空", b"link_clear")],
            [Button.inline("🔙 返回", b"back_main")],
        ]
        await event.edit(f"🔗 群链接管理 (共{cnt}个)", buttons=buttons)

    async def handle_group_links_callback(self, event, data):
        uid = event.sender_id
        if data == "link_add":
            user_state.set(uid, 'add_group_links')
            await event.edit("请发送群链接（每行一个）", buttons=[[Button.inline("🔙 返回", b"links")]])
        elif data == "link_file":
            user_state.set(uid, 'add_group_links_file')
            await event.edit("请发送包含链接的 txt 文件", buttons=[[Button.inline("🔙 返回", b"links")]])
        elif data == "link_view":
            links = self.db.get_all_group_links()
            if not links:
                return await event.edit("暂无链接", buttons=[[Button.inline("🔙 返回", b"links")]])
            txt = "群链接列表：\n" + "\n".join([f"{i+1}. {l['link']}" for i,l in enumerate(links[:50])])
            await event.edit(txt, buttons=[[Button.inline("🔙 返回", b"links")]])
        elif data == "link_clear":
            self.db.delete_all_group_links()
            await event.answer("已清空")
            await self.show_group_links_menu(event)

    async def process_add_group_links(self, event, text):
        links = [l.strip() for l in text.split('\n') if l.strip()]
        cnt = self.db.add_group_links_batch(links)
        user_state.clear(event.sender_id)
        await event.respond(f"✅ 成功添加 {cnt} 个链接", buttons=[[Button.inline("🔙 返回", b"links")]])

    async def process_add_group_links_file(self, event):
        if not event.message.file: return await event.respond("❌ 请发送文件")
        path = await event.message.download_media(file=os.path.join(UPLOAD_DIR, 'temp'))
        with open(path, 'r') as f:
            links = [l.strip() for l in f.read().split('\n') if l.strip()]
        cnt = self.db.add_group_links_batch(links)
        os.remove(path)
        user_state.clear(event.sender_id)
        await event.respond(f"✅ 从文件导入 {cnt} 个链接", buttons=[[Button.inline("🔙 返回", b"links")]])

    # ================== 广告模板管理 ==================
    async def show_ad_templates_menu(self, event):
        tpls = self.db.get_all_ad_templates()
        txt = "📢 广告模板\n\n" + "\n".join([f"• #{t['id']} {t['name']}" for t in tpls]) if tpls else "暂无模板"
        buttons = [
            [Button.inline("➕ 新建", b"tpl_create"), Button.inline("👁 查看", b"tpl_view")],
            [Button.inline("🗑 删除", b"tpl_delete"), Button.inline("🔙 返回", b"back_main")],
        ]
        await event.edit(txt, buttons=buttons)

    async def handle_ad_templates_callback(self, event, data):
        uid = event.sender_id
        if data == "tpl_create":
            user_state.set(uid, 'create_ad_template_name')
            await event.edit("请输入模板名称：", buttons=[[Button.inline("🔙 返回", b"tpl")]])
        elif data == "tpl_view":
            tpls = self.db.get_all_ad_templates()
            btns = [[Button.inline(t['name'], f"tpl_show_{t['id']}")] for t in tpls]
            btns.append([Button.inline("🔙 返回", b"tpl")])
            await event.edit("选择查看模板：", buttons=btns)
        elif data.startswith("tpl_show_"):
            tid = int(data.split("_")[-1])
            t = self.db.get_ad_template(tid)
            txt = f"📢 {t['name']}\n文本: {t['text'] or '无'}\n图片: {'有' if t['photo_path'] else '无'}\n按钮: {t['button_text'] or '无'} -> {t['button_url'] or '无'}"
            await event.edit(txt, buttons=[[Button.inline("🔙 返回", b"tpl")]])
        elif data == "tpl_delete":
            tpls = self.db.get_all_ad_templates()
            btns = [[Button.inline(t['name'], f"tpl_del_{t['id']}")] for t in tpls]
            btns.append([Button.inline("🔙 返回", b"tpl")])
            await event.edit("选择删除模板：", buttons=btns)
        elif data.startswith("tpl_del_"):
            tid = int(data.split("_")[-1])
            self.db.delete_ad_template(tid)
            await event.answer("✅ 已删除")
            await self.show_ad_templates_menu(event)

    async def process_create_ad_template_name(self, event, text):
        uid = event.sender_id
        user_state.set(uid, 'create_ad_template_text', {'name': text})
        await event.respond("请输入广告文本（发送 `跳过` 不添加）", buttons=[[Button.inline("🔙 返回", b"tpl")]])

    async def process_create_ad_template_text(self, event, text):
        uid = event.sender_id
        data = user_state.get(uid)['data']
        if text != '跳过': data['text'] = text
        user_state.set(uid, 'create_ad_template_photo', data)
        await event.respond("请发送图片（发送 `跳过` 不添加）", buttons=[[Button.inline("🔙 返回", b"tpl")]])

    async def process_create_ad_template_photo(self, event):
        uid = event.sender_id
        data = user_state.get(uid)['data']
        if event.message.text and event.message.text == '跳过':
            data['photo_path'] = ''
        elif event.message.file:
            data['photo_path'] = await event.message.download_media(file=os.path.join(UPLOAD_DIR, 'photos'))
        else:
            return await event.respond("❌ 请发送图片或输入 `跳过`")
        user_state.set(uid, 'create_ad_template_button', data)
        await event.respond("请输入按钮（格式：文本 | 链接，发送 `跳过` 不添加）", buttons=[[Button.inline("🔙 返回", b"tpl")]])

    async def process_create_ad_template_button(self, event, text):
        uid = event.sender_id
        data = user_state.get(uid)['data']
        if text == '跳过':
            bt, bu = '', ''
        else:
            parts = text.split('|')
            bt = parts[0].strip() if parts else ''
            bu = parts[1].strip() if len(parts) > 1 else ''
        self.db.add_ad_template(data.get('name', ''), data.get('text', ''), data.get('photo_path', ''), bt, bu)
        user_state.clear(uid)
        await event.respond("✅ 模板创建成功", buttons=[[Button.inline("🔙 返回", b"tpl")]])

    # ================== 批量换资料 ==================
    async def cmd_change_profile_start(self, event):
        groups = self.db.get_all_groups()
        if not groups: return await event.answer("请先创建分组", alert=True)
        btns = [[Button.inline(g['name'], f"chp_group_{g['id']}")] for g in groups]
        btns.append([Button.inline("🔙 返回", b"back_main")])
        await event.edit("🔄 选择要换资料的分组：", buttons=btns)

    async def handle_change_profile_callback(self, event, data):
        uid = event.sender_id
        if data.startswith("chp_group_"):
            gid = int(data.split("_")[-1])
            user_state.set(uid, 'chp_set_name', {'group_id': gid})
            await event.edit("请输入新昵称：", buttons=[[Button.inline("🔙 返回", b"chg_profile")]])

    async def process_chp_name(self, event, text):
        uid = event.sender_id
        data = user_state.get(uid)['data']
        data['name'] = text
        user_state.set(uid, 'chp_set_bio', data)
        await event.respond("请输入新简介（发送 `跳过` 不修改）：", buttons=[[Button.inline("🔙 返回", b"chg_profile")]])

    async def process_chp_bio(self, event, text):
        uid = event.sender_id
        data = user_state.get(uid)['data']
        if text != '跳过': data['bio'] = text
        user_state.set(uid, 'chp_set_photo', data)
        await event.respond("请发送新头像（发送 `跳过` 不修改）：", buttons=[[Button.inline("🔙 返回", b"chg_profile")]])

    async def process_chp_photo(self, event):
        uid = event.sender_id
        data = user_state.get(uid)['data']
        if event.message.text and event.message.text == '跳过':
            photo = ''
        elif event.message.file:
            photo = await event.message.download_media(file=os.path.join(UPLOAD_DIR, 'photos'))
        else:
            return await event.respond("❌ 请发送图片或输入 `跳过`")
        tpl_id = self.db.add_ad_template(name=data.get('name', ''), text=data.get('bio', ''), photo_path=photo)
        task_id = self.db.create_task('profile_change', account_group_id=data['group_id'], ad_template_id=tpl_id, delay_min=5, delay_max=15)
        user_state.clear(uid)
        await event.respond(f"✅ 换资料任务已创建！ID: {task_id}\n请在任务管理中启动", buttons=[[Button.inline("📊 任务管理", b"tasks"), Button.inline("🔙 返回", b"back_main")]])

    # ================== 批量加群 ==================
    async def cmd_join_groups_start(self, event):
        groups = self.db.get_all_groups()
        if not groups: return await event.answer("请先创建分组", alert=True)
        if not self.db.get_group_links_count(): return await event.answer("请先添加群链接", alert=True)
        btns = [[Button.inline(g['name'], f"join_group_{g['id']}")] for g in groups]
        btns.append([Button.inline("🔙 返回", b"back_main")])
        await event.edit("➕ 选择加群账号分组：", buttons=btns)

    async def handle_join_groups_callback(self, event, data):
        uid = event.sender_id
        if data.startswith("join_group_"):
            gid = int(data.split("_")[-1])
            user_state.set(uid, 'join_set_links', {'group_id': gid})
            await event.edit("请发送要加入的群链接ID（逗号分隔，或 `all`）", buttons=[[Button.inline("🔙 返回", b"join_groups")]])

    async def process_join_set_links(self, event, text):
        uid = event.sender_id
        data = user_state.get(uid)['data']
        if text.lower() == 'all':
            links = self.db.get_all_group_links()
            data['link_ids'] = ','.join([str(l['id']) for l in links])
        else:
            data['link_ids'] = text
        user_state.set(uid, 'join_set_delay', data)
        await event.respond("请设置延时（秒，最小-最大），例 30-120：", buttons=[[Button.inline("🔙 返回", b"join_groups")]])

    async def process_join_set_delay(self, event, text):
        uid = event.sender_id
        data = user_state.get(uid)['data']
        try:
            parts = text.split('-')
            dmin = int(parts[0])
            dmax = int(parts[1]) if len(parts) > 1 else dmin
        except:
            return await event.respond("❌ 格式错误")
        task_id = self.db.create_task('join_groups', account_group_id=data['group_id'], group_link_ids=data['link_ids'], delay_min=dmin, delay_max=dmax)
        user_state.clear(uid)
        await event.respond(f"✅ 加群任务已创建！ID: {task_id}\n请在任务管理中启动", buttons=[[Button.inline("📊 任务管理", b"tasks"), Button.inline("🔙 返回", b"back_main")]])

    # ================== 批量群发广告 ==================
    async def cmd_send_ads_start(self, event):
        groups = self.db.get_all_groups()
        if not groups: return await event.answer("请先创建分组", alert=True)
        if not self.db.get_group_links_count(): return await event.answer("请先添加群链接", alert=True)
        if not self.db.get_all_ad_templates(): return await event.answer("请先创建广告模板", alert=True)
        btns = [[Button.inline(g['name'], f"send_group_{g['id']}")] for g in groups]
        btns.append([Button.inline("🔙 返回", b"back_main")])
        await event.edit("📨 选择群发账号分组：", buttons=btns)

    async def handle_send_ads_callback(self, event, data):
        uid = event.sender_id
        if data.startswith("send_group_"):
            gid = int(data.split("_")[-1])
            user_state.set(uid, 'send_set_links', {'group_id': gid})
            await event.edit("请发送群链接ID（逗号分隔或 `all`）", buttons=[[Button.inline("🔙 返回", b"send_ads")]])
        elif data.startswith("send_tpl_"):
            tid = int(data.split("_")[-1])
            data_state = user_state.get(uid)['data']
            data_state['template_id'] = tid
            user_state.set(uid, 'send_set_delay', data_state)
            await event.respond("请设置延时（秒，最小-最大），例 60-180：", buttons=[[Button.inline("🔙 返回", b"send_ads")]])

    async def process_send_set_links(self, event, text):
        uid = event.sender_id
        data = user_state.get(uid)['data']
        if text.lower() == 'all':
            links = self.db.get_all_group_links()
            data['link_ids'] = ','.join([str(l['id']) for l in links])
        else:
            data['link_ids'] = text
        tpls = self.db.get_all_ad_templates()
        btns = [[Button.inline(t['name'], f"send_tpl_{t['id']}")] for t in tpls]
        btns.append([Button.inline("🔙 返回", b"send_ads")])
        user_state.set(uid, 'send_set_links', data)  # 保持状态
        await event.respond("选择广告模板：", buttons=btns)

    async def process_send_set_delay(self, event, text):
        uid = event.sender_id
        data = user_state.get(uid)['data']
        try:
            parts = text.split('-')
            dmin = int(parts[0])
            dmax = int(parts[1]) if len(parts) > 1 else dmin
        except:
            return await event.respond("❌ 格式错误")
        data['delay_min'] = dmin
        data['delay_max'] = dmax
        user_state.set(uid, 'send_set_time', data)
        await event.respond("请输入执行时间段（格式 YYYY-MM-DD HH:MM-YYYY-MM-DD HH:MM，或发送 `跳过` 立即执行）", buttons=[[Button.inline("🔙 返回", b"send_ads")]])

    async def process_send_set_time(self, event, text):
        uid = event.sender_id
        data = user_state.get(uid)['data']
        start = end = None
        if text != '跳过':
            try:
                parts = text.split('-')
                start = parts[0].strip()
                end = parts[1].strip() if len(parts) > 1 else None
            except:
                return await event.respond("❌ 格式错误")
        task_id = self.db.create_task('send_ads', account_group_id=data['group_id'], group_link_ids=data['link_ids'],
                                      ad_template_id=data['template_id'], start_time=start, end_time=end,
                                      delay_min=data['delay_min'], delay_max=data['delay_max'])
        user_state.clear(uid)
        await event.respond(f"✅ 群发任务已创建！ID: {task_id}\n请在任务管理中启动",
                            buttons=[[Button.inline("📊 任务管理", b"tasks"), Button.inline("🔙 返回", b"back_main")]])

    # ================== 任务管理 ==================
    async def show_tasks_menu(self, event):
        tasks = self.db.get_all_tasks()
        txt = "📊 任务管理\n"
        running = sum(1 for t in tasks if t['status'] == 'running')
        txt += f"运行中: {running}\n历史: {len(tasks)}\n\n"
        for t in tasks[:10]:
            emoji = {'pending':'⏳','running':'🔄','completed':'✅','failed':'❌','stopped':'⏹'}.get(t['status'],'❓')
            type_emoji = {'join_groups':'➕','send_ads':'📨','profile_change':'🔄'}.get(t['task_type'],'📋')
            txt += f"{emoji}{type_emoji} #{t['id']} {t['status']}\n"
        buttons = [
            [Button.inline("▶️ 启动", b"task_start"), Button.inline("⏹ 停止", b"task_stop")],
            [Button.inline("📋 详情", b"task_detail"), Button.inline("📝 日志", b"task_log")],
            [Button.inline("🔄 重新执行", b"task_rerun"), Button.inline("🗑 删除", b"task_delete")],
            [Button.inline("🔙 返回", b"back_main")],
        ]
        await event.edit(txt, buttons=buttons)

    async def handle_tasks_callback(self, event, data):
        uid = event.sender_id
        if data == "task_start":
            pending_tasks = [t for t in self.db.get_all_tasks() if t['status'] in ('pending','stopped')]
            if not pending_tasks: return await event.answer("没有可启动的任务", alert=True)
            btns = [[Button.inline(f"#{t['id']} {t['task_type']}", f"task_start_{t['id']}")] for t in pending_tasks]
            btns.append([Button.inline("🔙 返回", b"tasks")])
            await event.edit("选择启动任务：", buttons=btns)
        elif data.startswith("task_start_"):
            tid = int(data.split("_")[-1])
            task = self.db.get_task(tid)
            if not task: return
            await event.answer("任务已启动")
            if task['task_type'] == 'join_groups':
                asyncio.create_task(self.executor.execute_join_task(tid))
            elif task['task_type'] == 'send_ads':
                asyncio.create_task(self.executor.execute_send_task(tid))
            elif task['task_type'] == 'profile_change':
                asyncio.create_task(self.executor.execute_profile_task(tid))
            await self.show_tasks_menu(event)
        elif data == "task_stop":
            running_tasks = [t for t in self.db.get_all_tasks() if t['status'] == 'running']
            if not running_tasks: return await event.answer("没有运行中的任务")
            btns = [[Button.inline(f"#{t['id']}", f"task_stop_{t['id']}")] for t in running_tasks]
            btns.append([Button.inline("🔙 返回", b"tasks")])
            await event.edit("选择停止任务：", buttons=btns)
        elif data.startswith("task_stop_"):
            tid = int(data.split("_")[-1])
            self.executor.stop_task(tid)
            await event.answer("任务已停止")
            await self.show_tasks_menu(event)
        elif data == "task_detail":
            tasks = self.db.get_all_tasks()
            btns = [[Button.inline(f"#{t['id']}", f"task_detail_{t['id']}")] for t in tasks]
            btns.append([Button.inline("🔙 返回", b"tasks")])
            await event.edit("选择查看任务：", buttons=btns)
        elif data.startswith("task_detail_"):
            tid = int(data.split("_")[-1])
            task = self.db.get_task(tid)
            if not task: return
            p = json.loads(task.get('progress','{}'))
            txt = f"📊 任务 #{tid}\n类型: {task['task_type']}\n状态: {task['status']}\n延时: {task['delay_min']}-{task['delay_max']}s\n进度: {p.get('completed',0)}/{p.get('total',0)} 成功:{p.get('success',0)} 失败:{p.get('failed',0)}"
            await event.edit(txt, buttons=[[Button.inline("🔙 返回", b"tasks")]])
        elif data == "task_log":
            tasks = self.db.get_all_tasks()
            btns = [[Button.inline(f"#{t['id']}", f"task_log_{t['id']}")] for t in tasks]
            btns.append([Button.inline("🔙 返回", b"tasks")])
            await event.edit("选择查看日志：", buttons=btns)
        elif data.startswith("task_log_"):
            tid = int(data.split("_")[-1])
            logs = self.db.get_task_logs(tid)
            txt = f"📝 任务 #{tid} 日志\n"
            for log in logs[:20]:
                emj = '✅' if log['status'] == 'success' else '❌'
                txt += f"{emj} 账号{log['account_id']} -> {log['group_link'][:20]}... {log['message']}\n"
            if not logs: txt += "暂无日志"
            await event.edit(txt, buttons=[[Button.inline("🔙 返回", b"tasks")]])
        elif data == "task_rerun":
            history = [t for t in self.db.get_all_tasks() if t['status'] in ('completed','failed','stopped')]
            if not history: return await event.answer("没有可重新执行的任务")
            btns = [[Button.inline(f"#{t['id']}", f"task_rerun_{t['id']}")] for t in history]
            btns.append([Button.inline("🔙 返回", b"tasks")])
            await event.edit("选择重新执行：", buttons=btns)
        elif data.startswith("task_rerun_"):
            tid = int(data.split("_")[-1])
            old = self.db.get_task(tid)
            if not old: return
            new_id = self.db.create_task(old['task_type'], old['account_group_id'], old['group_link_ids'],
                                         old['ad_template_id'], old['start_time'], old['end_time'],
                                         old['delay_min'], old['delay_max'])
            await event.answer(f"已创建新任务 #{new_id}")
            await self.show_tasks_menu(event)
        elif data == "task_delete":
            tasks = self.db.get_all_tasks()
            btns = [[Button.inline(f"#{t['id']}", f"task_del_{t['id']}")] for t in tasks]
            btns.append([Button.inline("🔙 返回", b"tasks")])
            await event.edit("选择删除任务：", buttons=btns)
        elif data.startswith("task_del_"):
            tid = int(data.split("_")[-1])
            self.executor.stop_task(tid)
            self.db.delete_task(tid)
            await event.answer("已删除")
            await self.show_tasks_menu(event)

# ==================== 启动入口 ====================
async def main():
    db = Database()
    db.init_db()
    bot = GroupSenderBot()
    await bot.start()

if __name__ == "__main__":
    print("启动中...")
    asyncio.run(main())