#!/usr/bin/env python
# -*- coding: utf-8 -*-

import logging
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackQueryHandler, ChatMemberHandler, ChatJoinRequestHandler
import config
import handlers
import os
import sys
import utils

# 设置日志 - 添加更详细的日志输出
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', 
    level=logging.INFO,
    force=True  # 强制重新配置日志
)
logger = logging.getLogger(__name__)

# 确保telegram库的日志也显示
logging.getLogger('telegram').setLevel(logging.INFO)
logging.getLogger('telegram.ext').setLevel(logging.INFO)

def main():
    """启动机器人"""
    # 检查配置
    if not config.BOT_TOKEN:
        logger.error("未设置BOT_TOKEN。请在.env文件中设置BOT_TOKEN。")
        sys.exit(1)
    
    # 创建Updater
    updater = Updater(config.BOT_TOKEN)
    
    # 获取调度器
    dp = updater.dispatcher
    
    # 注册命令处理器
    dp.add_handler(CommandHandler("start", handlers.start))
    
    # 注册回调查询处理器
    dp.add_handler(CallbackQueryHandler(handlers.handle_callback_query))
    
    # 注册成员状态更新处理器 - 用于处理成员状态变化
    dp.add_handler(ChatMemberHandler(handlers.handle_chat_member_update, ChatMemberHandler.CHAT_MEMBER))
    
    # 注册新成员加入处理器 - 使用 new_chat_members 消息事件
    dp.add_handler(MessageHandler(Filters.status_update.new_chat_members, handlers.handle_new_member))
    
    # 注册消息处理器
    dp.add_handler(MessageHandler(Filters.status_update.left_chat_member, handlers.handle_left_member))
    dp.add_handler(MessageHandler(Filters.text | Filters.photo | Filters.video | Filters.document | Filters.animation, handlers.handle_message))
    
    # 添加错误处理器
    def error_handler(update, context):
        """处理错误"""
        logger.error(f"更新 {update} 导致错误 {context.error}")
    
    dp.add_error_handler(error_handler)
    
    # 使用轮询模式，确保接收所有类型的更新
    logger.info("开始启动轮询...")
    updater.start_polling(
        allowed_updates=['message', 'callback_query', 'chat_member'],
        drop_pending_updates=True,  # 启动时清除待处理的更新，避免处理旧消息
        timeout=10
    )
    logger.info("机器人已启动，正在监听消息...")
    logger.info(f"Bot Token: {config.BOT_TOKEN[:10]}...{config.BOT_TOKEN[-10:]}")
    logger.info(f"Admin IDs: {config.ADMIN_IDS}")
    
    # 获取机器人信息
    try:
        bot_info = updater.bot.get_me()
        logger.info(f"机器人用户名: @{bot_info.username}")
        logger.info(f"机器人名称: {bot_info.first_name}")
        logger.info(f"机器人ID: {bot_info.id}")
    except Exception as e:
        logger.error(f"无法获取机器人信息: {e}")
    
    logger.info("等待接收消息和更新...")
    logger.info("如果没有日志，请确保：")
    logger.info("1. 机器人已被添加到群组")
    logger.info("2. 机器人有管理员权限")
    logger.info("3. 在群组中发送消息测试")
    
    # 持续运行直到按Ctrl-C
    updater.idle()

if __name__ == '__main__':
    # 确保加载欢迎消息ID
    handlers.load_welcome_message_ids()
    # 确保加载课程消息ID
    utils.load_class_message_ids()
    main()